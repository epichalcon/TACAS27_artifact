{
  "language": "Vyper",
  "sources": {
    "src/oracles/interfaces/IYearnVault.vyi": {
      "content": "# @version 0.4.3\n\n\n@view\n@external\ndef pricePerShare() -> uint256:\n    ...",
      "sha256sum": "457b5668d317c744860a68e4e164cf108019f44698f568d08e87c88ea79df917"
    },
    "src/interfaces/IPriceOracle.vyi": {
      "content": "# @version 0.4.3\n\n\n# ============================================================================================\n# View functions\n# ============================================================================================\n\n\n@external\n@view\ndef get_price(scaled: bool = True) -> uint256:\n    ...",
      "sha256sum": "723e1c48020180e60951a0f8c8994c50218ed145f167d4b57c50ce95c0e80173"
    },
    "src/oracles/yvusd_to_usdc_oracle.vy": {
      "content": "# @version 0.4.3\n\n\"\"\"\n@title Price Oracle\n@license GNU AGPLv3\n@author Flex\n@notice Provides the price of yvUSD in terms of USDC\n\"\"\"\n\nfrom ethereum.ercs import IERC20Detailed\n\nfrom interfaces import IYearnVault\n\nfrom ..interfaces import IPriceOracle\n\n# ============================================================================================\n# Interfaces\n# ============================================================================================\n\n\nimplements: IPriceOracle\n\n\n# ============================================================================================\n# Constants\n# ============================================================================================\n\n\n# Decimals\n_ORACLE_SCALE_FACTOR: immutable(uint256)  # 10^(36 + borrow_decimals - collateral_decimals)\n_BORROW_TOKEN_DECIMALS: immutable(uint256)\n_COLLATERAL_TOKEN_DECIMALS: immutable(uint256)\n\n# Tokens\n_BORROW_TOKEN: constant(IERC20Detailed) = IERC20Detailed(0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48)  # USDC\n_COLLATERAL_TOKEN: constant(IERC20Detailed) = IERC20Detailed(0x696d02Db93291651ED510704c9b286841d506987)  # yvUSD\n\n# Internal constants\n_WAD: constant(uint256) = 10 ** 18\n_MAX_TOKEN_DECIMALS: constant(uint256) = 18\n_ORACLE_PRICE_SCALE_DECIMALS: constant(uint256) = 36\n\n\n# ============================================================================================\n# Constructor\n# ============================================================================================\n\n\n@deploy\ndef __init__():\n    \"\"\"\n    @notice Initialize the contract\n    \"\"\"\n    # Tokens cannot have more than 18 decimals\n    _BORROW_TOKEN_DECIMALS = convert(staticcall _BORROW_TOKEN.decimals(), uint256)\n    _COLLATERAL_TOKEN_DECIMALS = convert(staticcall _COLLATERAL_TOKEN.decimals(), uint256)\n    assert _COLLATERAL_TOKEN_DECIMALS <= _MAX_TOKEN_DECIMALS and _BORROW_TOKEN_DECIMALS <= _MAX_TOKEN_DECIMALS, \"!decimals\"\n\n    # Precompute scale factor\n    _ORACLE_SCALE_FACTOR = 10 ** (_ORACLE_PRICE_SCALE_DECIMALS + _BORROW_TOKEN_DECIMALS - _COLLATERAL_TOKEN_DECIMALS)\n\n\n# ============================================================================================\n# View functions\n# ============================================================================================\n\n\n@external\n@view\ndef get_price(scaled: bool = True) -> uint256:\n    \"\"\"\n    @notice Get the collateral price in terms of borrow tokens\n    @param scaled If True, returns 10^(36 + borrow_decimals - collateral_decimals) format,\n                  if False, returns WAD format\n    @return Price scaled to the required format\n    \"\"\"\n    # Fetch yvUSD price per share\n    pps: uint256 = staticcall IYearnVault(_COLLATERAL_TOKEN.address).pricePerShare()\n\n    # Scale price to WAD\n    price: uint256 = pps * _WAD // 10 ** _COLLATERAL_TOKEN_DECIMALS\n\n    # Scale price to the required format if needed and return\n    return price * _ORACLE_SCALE_FACTOR // _WAD if scaled else price",
      "sha256sum": "b8137c3abc297dbfababfe41303f2ca052d5eed0ec0bbd43c8652ca7e2c8351f"
    }
  },
  "settings": {
    "outputSelection": {
      "src/oracles/yvusd_to_usdc_oracle.vy": [
        "evm.bytecode",
        "evm.deployedBytecode",
        "abi"
      ]
    },
    "search_paths": [
      "."
    ]
  },
  "compiler_version": "v0.4.3+commit.bff19ea2",
  "integrity": "09b4e8d1485189a906943e6a022fffbd06015469b6d82efa689f669700212976"
}