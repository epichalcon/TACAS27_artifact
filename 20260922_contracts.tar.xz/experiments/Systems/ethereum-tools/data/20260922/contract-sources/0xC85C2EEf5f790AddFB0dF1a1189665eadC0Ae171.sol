{
  "language": "Solidity",
  "sources": {
    "src/Create2Factory.sol": {
      "content": "// SPDX-License-Identifier: MIT\n/*\n                         ________________________________\n                        / ______________________________ \\\n     .-----------------' /                              \\ `-----------------.\n    / .--------------. /              BANG              \\ .--------------. \\\n   / /  __________  / /                                  \\ \\  __________ \\ \\\n  | |  / ________ \\/ /                                    \\ \\/ ________ \\ | |\n  | | / /        \\__/                                      \\__/        \\ \\| |\n  | | |                                                                  | | |\n  | | |   ______      ___       _   __       ______                       | | |\n  | | |  / __ ) | /| / / |     / | / /      / ____/                       | | |\n  | | | / __  | |/ |/ /| | /| /  |/ /      / / __                         | | |\n  | | |/ /_/ /|__/|__/ | |/ |/ /|  /      / /_/ /                         | | |\n  | | /_____/          |__/|__/_/|_/       \\____/                         | | |\n   \\ \\                                                                    / /\n    \\ `----------------.   https://x.com/Bangv4hook       .------------' /\n     `-----------------`   https://bangv4hook.com/        `-------------'\n                  \\________________________________________________/\n                         \\__________________________________/\n*/\npragma solidity ^0.8.24;\n\ncontract Create2Factory {\n    event Deployed(address indexed deployed, bytes32 indexed salt);\n\n    error EmptyBytecode();\n    error DeployFailed();\n\n    function deploy(bytes32 salt, bytes calldata bytecode) external payable returns (address deployed) {\n        if (bytecode.length == 0) revert EmptyBytecode();\n\n        bytes memory initCode = bytecode;\n        assembly (\"memory-safe\") {\n            deployed := create2(callvalue(), add(initCode, 0x20), mload(initCode), salt)\n        }\n\n        if (deployed == address(0)) revert DeployFailed();\n        emit Deployed(deployed, salt);\n    }\n\n    function computeAddress(bytes32 salt, bytes32 initCodeHash) external view returns (address) {\n        return address(uint160(uint256(keccak256(abi.encodePacked(bytes1(0xff), address(this), salt, initCodeHash)))));\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "viaIR": true,
    "evmVersion": "cancun",
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    }
  }
}