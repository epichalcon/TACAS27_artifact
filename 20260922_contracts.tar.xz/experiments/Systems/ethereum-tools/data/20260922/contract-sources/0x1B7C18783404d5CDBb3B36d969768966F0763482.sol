// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title OTCAatomicSettlement
 * @dev OTC Atomic Settlement with Laser Digital as verified desk
 * @notice Enables secure OTC trades with USDT using atomic settlement
 */
contract OTCAatomicSettlement {
    // ==============================
    // CUSTOM ERRORS
    // ==============================
    
    error Unauthorized(address caller);
    error InvalidState(uint8 current, uint8 expected);
    error TradeNotFound(bytes32 id);
    error TradeInactive(bytes32 id);
    error InvalidAddress(address addr);
    error InvalidAmount(uint256 amount);
    error TradeExists(bytes32 id);
    error TradeExpired(uint256 deadline, uint256 now);
    error TransferFailed();
    error InsufficientAllowance(uint256 required, uint256 available);
    error InsufficientBalance(uint256 required, uint256 available);
    error InvalidPreimage(bytes32 provided, bytes32 expected);
    error AlreadyDone(string action);
    error NotExpired(uint256 deadline, uint256 now);
    
    // ==============================
    // ENUMS & STRUCTS
    // ==============================
    
    enum State { 
        PENDING, TEST_DONE, FINAL_DONE, SETTLED, CANCELLED, EXPIRED
    }

    struct Trade {
        address sender;
        address receiver;
        uint256 total;
        uint256 testAmt;
        uint256 finalAmt;
        bytes32 hashlock;
        bytes32 preimage;
        uint256 timelock;
        uint256 created;
        State state;
        bool testDone;
        bool finalDone;
        bool settled;
    }

    struct Desk {
        string name;
        string reg;
        bool verified;
    }

    // ==============================
    // CONSTANTS
    // ==============================
    
    address public constant USDT = 0xdAC17F958D2ee523a2206206994597C13D831ec7;
    address public constant LASER_DIGITAL = 0x5D1B9C80936d3D8f58A891608699532043BA40eD;

    // ==============================
    // STORAGE
    // ==============================
    
    mapping(bytes32 => Trade) public trades;
    mapping(address => bytes32[]) public userTrades;
    mapping(address => Desk) public desks;
    
    uint256 private _guardCounter = 1;
    bool private _paused = false;
    address public owner;
    uint256 public protocolFee = 0;
    address public feeCollector;

    // ==============================
    // EVENTS
    // ==============================
    
    event TradeCreated(bytes32 indexed id, address indexed sender, address indexed receiver, uint256 amount, uint256 testAmount, uint256 finalAmount, uint256 timelock, address desk);
    event TestDone(bytes32 indexed id, uint256 amount, address indexed sender);
    event FinalDone(bytes32 indexed id, uint256 amount, address indexed sender);
    event TradeSettled(bytes32 indexed id, bytes32 preimage, address indexed receiver, uint256 amount);
    event TradeCancelled(bytes32 indexed id, string reason, address indexed cancelledBy);
    event TradeRefunded(bytes32 indexed id, address indexed to, uint256 amount, string reason);
    event DeskAdded(address indexed deskAddress, string name, string reg);
    event DeskRemoved(address indexed deskAddress);
    event ProtocolFeeUpdated(uint256 newFee);
    event FeeCollectorUpdated(address newCollector);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event ContractPaused(address indexed pausedBy);
    event ContractUnpaused(address indexed unpausedBy);

    // ==============================
    // MODIFIERS
    // ==============================
    
    modifier onlyOwner() {
        if (msg.sender != owner) revert Unauthorized(msg.sender);
        _;
    }
    
    modifier nonReentrant() {
        if (_guardCounter != 1) revert Unauthorized(msg.sender);
        _guardCounter = 2;
        _;
        _guardCounter = 1;
    }
    
    modifier onlySender(bytes32 id) {
        if (trades[id].sender != msg.sender) revert Unauthorized(msg.sender);
        _;
    }
    
    modifier onlyReceiver(bytes32 id) {
        if (trades[id].receiver != msg.sender) revert Unauthorized(msg.sender);
        _;
    }
    
    modifier tradeExists(bytes32 id) {
        if (trades[id].sender == address(0)) revert TradeNotFound(id);
        _;
    }
    
    modifier tradeActive(bytes32 id) {
        Trade storage t = trades[id];
        if (t.state == State.CANCELLED || t.state == State.SETTLED || t.state == State.EXPIRED) {
            revert TradeInactive(id);
        }
        _;
    }
    
    modifier onlyVerifiedDesk(address desk) {
        if (!desks[desk].verified) revert Unauthorized(desk);
        _;
    }
    
    modifier whenNotPaused() {
        if (_paused) revert Unauthorized(address(0));
        _;
    }

    // ==============================
    // CONSTRUCTOR
    // ==============================
    
    constructor() {
        owner = msg.sender;
        desks[LASER_DIGITAL] = Desk("Laser Digital", "240029", true);
        feeCollector = LASER_DIGITAL;
    }

    // ==============================
    // INTERNAL HELPERS - Stack Optimized
    // ==============================
    
    /**
     * @dev Check if trade is expired - single variable to reduce stack
     */
    function _isExpired(Trade storage t) internal view returns (bool) {
        return block.timestamp > t.created + t.timelock;
    }
    
    /**
     * @dev Transfer USDT from sender with minimal variables
     */
    function _pullUSDT(address from, uint256 amount) internal {
        IUSDT token = IUSDT(USDT);
        if (token.allowance(from, address(this)) < amount) {
            revert InsufficientAllowance(amount, token.allowance(from, address(this)));
        }
        if (!token.transferFrom(from, address(this), amount)) revert TransferFailed();
    }
    
    /**
     * @dev Transfer USDT to recipient with balance check
     */
    function _pushUSDT(address to, uint256 amount) internal {
        if (amount == 0) return;
        IUSDT token = IUSDT(USDT);
        if (token.balanceOf(address(this)) < amount) {
            revert InsufficientBalance(amount, token.balanceOf(address(this)));
        }
        if (!token.transfer(to, amount)) revert TransferFailed();
    }
    
    /**
     * @dev Calculate fee - pure function to avoid storage reads
     */
    function _calcFee(uint256 amount) internal view returns (uint256) {
        return (amount * protocolFee) / 10000;
    }
    
    /**
     * @dev Validate trade creation - extracted to reduce stack
     */
    function _validateCreation(
        bytes32 id,
        address receiver,
        uint256 total,
        uint256 test,
        bytes32 hashlock,
        uint256 timelock
    ) internal view {
        if (id == bytes32(0)) revert InvalidAmount(0);
        if (receiver == address(0)) revert InvalidAddress(receiver);
        if (receiver == msg.sender) revert InvalidAddress(msg.sender);
        if (total == 0 || test == 0 || test >= total) revert InvalidAmount(0);
        if (hashlock == bytes32(0) || timelock == 0) revert InvalidAmount(0);
        if (trades[id].sender != address(0)) revert TradeExists(id);
    }

    // ==============================
    // CORE FUNCTIONS - Stack Optimized
    // ==============================
    
    function createTrade(
        bytes32 id,
        address receiver,
        uint256 total,
        uint256 test,
        bytes32 hashlock,
        uint256 timelock,
        address desk
    ) 
        external 
        whenNotPaused
        onlyVerifiedDesk(desk)
    {
        _validateCreation(id, receiver, total, test, hashlock, timelock);
        
        Trade storage t = trades[id];
        t.sender = msg.sender;
        t.receiver = receiver;
        t.total = total;
        t.testAmt = test;
        t.finalAmt = total - test;
        t.hashlock = hashlock;
        t.timelock = timelock;
        t.created = block.timestamp;
        t.state = State.PENDING;
        
        userTrades[msg.sender].push(id);
        userTrades[receiver].push(id);
        
        emit TradeCreated(id, msg.sender, receiver, total, test, total - test, timelock, desk);
    }

    function executeTest(bytes32 id) 
        external 
        nonReentrant
        whenNotPaused
        tradeExists(id) 
        tradeActive(id)
        onlySender(id) 
    {
        Trade storage t = trades[id];
        if (t.state != State.PENDING) revert InvalidState(uint8(t.state), 0);
        if (t.testDone) revert AlreadyDone("Test");
        if (_isExpired(t)) revert TradeExpired(t.created + t.timelock, block.timestamp);
        
        _pullUSDT(msg.sender, t.testAmt);
        
        t.testDone = true;
        t.state = State.TEST_DONE;
        
        emit TestDone(id, t.testAmt, msg.sender);
    }

    function executeFinal(bytes32 id) 
        external 
        nonReentrant
        whenNotPaused
        tradeExists(id) 
        tradeActive(id)
        onlySender(id) 
    {
        Trade storage t = trades[id];
        if (t.state != State.TEST_DONE) revert InvalidState(uint8(t.state), 1);
        if (t.finalDone) revert AlreadyDone("Final");
        if (_isExpired(t)) revert TradeExpired(t.created + t.timelock, block.timestamp);
        
        _pullUSDT(msg.sender, t.finalAmt);
        
        t.finalDone = true;
        t.state = State.FINAL_DONE;
        
        emit FinalDone(id, t.finalAmt, msg.sender);
    }

    /**
     * @dev Settle - COMPLETELY OPTIMIZED to avoid stack issues
     * Uses inline calculations and minimal variables
     */
    function settle(bytes32 id, bytes32 preimage) 
        external 
        nonReentrant
        whenNotPaused
        tradeExists(id) 
        tradeActive(id)
        onlyReceiver(id) 
    {
        Trade storage t = trades[id];
        
        // All validations with minimal stack usage
        if (t.state != State.FINAL_DONE) revert InvalidState(uint8(t.state), 2);
        if (t.settled) revert AlreadyDone("Settled");
        if (_isExpired(t)) revert TradeExpired(t.created + t.timelock, block.timestamp);
        if (keccak256(abi.encodePacked(preimage)) != t.hashlock) {
            revert InvalidPreimage(preimage, t.hashlock);
        }
        
        // Update state early
        t.settled = true;
        t.state = State.SETTLED;
        t.preimage = preimage;
        
        // Calculate amounts inline to avoid extra variables
        uint256 totalAmount = t.testAmt + t.finalAmt;
        uint256 fee = _calcFee(totalAmount);
        uint256 receiverAmount = totalAmount - fee;
        
        // Execute transfers
        _pushUSDT(t.receiver, receiverAmount);
        if (fee > 0) {
            _pushUSDT(feeCollector, fee);
        }
        
        emit TradeSettled(id, preimage, t.receiver, receiverAmount);
    }

    function cancelTrade(bytes32 id, string calldata reason) 
        external 
        nonReentrant
        whenNotPaused
        tradeExists(id) 
        tradeActive(id)
    {
        Trade storage t = trades[id];
        
        if (msg.sender != t.sender && msg.sender != t.receiver) {
            revert Unauthorized(msg.sender);
        }
        if (t.state != State.PENDING && t.state != State.TEST_DONE) {
            revert InvalidState(uint8(t.state), 0);
        }
        
        t.state = State.CANCELLED;
        
        // Refund balance
        IUSDT token = IUSDT(USDT);
        uint256 balance = token.balanceOf(address(this));
        if (balance > 0) {
            if (!token.transfer(t.sender, balance)) revert TransferFailed();
        }
        
        emit TradeCancelled(id, reason, msg.sender);
        emit TradeRefunded(id, t.sender, balance, "Cancelled");
    }

    function refundExpired(bytes32 id) 
        external 
        nonReentrant
        whenNotPaused
        tradeExists(id) 
    {
        Trade storage t = trades[id];
        
        if (t.state != State.TEST_DONE && t.state != State.FINAL_DONE) {
            revert InvalidState(uint8(t.state), 1);
        }
        if (!_isExpired(t)) revert NotExpired(t.created + t.timelock, block.timestamp);
        if (t.settled) revert AlreadyDone("Settled");
        
        t.state = State.EXPIRED;
        
        IUSDT token = IUSDT(USDT);
        uint256 balance = token.balanceOf(address(this));
        if (balance == 0) revert InsufficientBalance(0, 0);
        if (!token.transfer(t.sender, balance)) revert TransferFailed();
        
        emit TradeRefunded(id, t.sender, balance, "Expired");
    }

    // ==============================
    // VIEW FUNCTIONS
    // ==============================
    
    function getTrade(bytes32 id)
        external
        view
        returns (
            address sender,
            address receiver,
            uint256 total,
            uint256 test,
            uint256 finalAmt,
            bytes32 hashlock,
            uint256 timelock,
            State state
        )
    {
        Trade storage t = trades[id];
        sender = t.sender;
        receiver = t.receiver;
        total = t.total;
        test = t.testAmt;
        finalAmt = t.finalAmt;
        hashlock = t.hashlock;
        timelock = t.timelock;
        state = t.state;
    }

    function getStatus(bytes32 id)
        external
        view
        returns (
            bool testDone, 
            bool finalDone, 
            bool settled, 
            uint256 created, 
            bytes32 preimage
        )
    {
        Trade storage t = trades[id];
        testDone = t.testDone;
        finalDone = t.finalDone;
        settled = t.settled;
        created = t.created;
        preimage = t.preimage;
    }

    function getUserTrades(address user) external view returns (bytes32[] memory) {
        return userTrades[user];
    }

    function isDeskVerified(address desk) external view returns (bool) {
        return desks[desk].verified;
    }

    function getDesk(address desk) 
        external 
        view 
        returns (string memory name, string memory reg, bool verified) 
    {
        Desk storage d = desks[desk];
        name = d.name;
        reg = d.reg;
        verified = d.verified;
    }

    function getBalance() external view returns (uint256) {
        return IUSDT(USDT).balanceOf(address(this));
    }

    function getUserTradeCount(address user) external view returns (uint256) {
        return userTrades[user].length;
    }

    function isTradeActive(bytes32 id) external view returns (bool) {
        Trade storage t = trades[id];
        return t.sender != address(0) &&
               t.state != State.CANCELLED &&
               t.state != State.SETTLED &&
               t.state != State.EXPIRED;
    }

    function paused() external view returns (bool) {
        return _paused;
    }

    function version() external pure returns (string memory) {
        return "2.0.0";
    }

    // ==============================
    // ADMIN FUNCTIONS
    // ==============================
    
    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) revert InvalidAddress(newOwner);
        emit OwnershipTransferred(owner, newOwner);
        owner = newOwner;
    }

    function addDesk(address desk, string calldata name, string calldata reg) external onlyOwner {
        if (desk == address(0)) revert InvalidAddress(desk);
        if (desks[desk].verified) revert AlreadyDone("Verified");
        desks[desk] = Desk(name, reg, true);
        emit DeskAdded(desk, name, reg);
    }

    function removeDesk(address desk) external onlyOwner {
        if (!desks[desk].verified) revert Unauthorized(desk);
        delete desks[desk];
        emit DeskRemoved(desk);
    }

    function setProtocolFee(uint256 newFee) external onlyOwner {
        if (newFee > 1000) revert InvalidAmount(newFee);
        protocolFee = newFee;
        emit ProtocolFeeUpdated(newFee);
    }

    function setFeeCollector(address newCollector) external onlyOwner {
        if (newCollector == address(0)) revert InvalidAddress(newCollector);
        feeCollector = newCollector;
        emit FeeCollectorUpdated(newCollector);
    }

    function pause() external onlyOwner {
        _paused = true;
        emit ContractPaused(msg.sender);
    }

    function unpause() external onlyOwner {
        _paused = false;
        emit ContractUnpaused(msg.sender);
    }
}

// ==============================
// INTERFACE
// ==============================

interface IUSDT {
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function allowance(address owner, address spender) external view returns (uint256);
}