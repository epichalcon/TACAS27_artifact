// SPDX-License-Identifier: GPL-3.0
// Target network: Ethereum mainnet (production). Not Sepolia.
// File: contracts/production/FXDataNetwork.sol
//
// Production marketplace contract — no separate TDU token dependency.
// Matches current app flows: registerProvider, createDataUnit, buyDataUnit (ETH),
// and provider wallet management. TDUX rewards in the UI are platform-side (backend).
pragma solidity >=0.8.0 <0.9.0;

contract FXDataNetwork {
    /// @dev 100% = 10000 (0.01% precision). Example: 99.5% => 9950, 0.5% => 50.
    uint256 private constant SPLIT_PERCENT_SCALE = 10000;

    error NotOwner();
    error NotProvider();
    error WalletRegistered();
    error WalletNotRegistered();
    error MaxWalletsReached();
    error CannotRemovePrimary();
    error MustKeepOneWallet();
    error InvalidWallet();
    error DataUnitNotFound();
    error InvalidPayment();
    error CannotBuyOwnData();
    error InvalidSplit();
    error InvalidTokenizerAddress();
    error InvalidPrice();
    error InvalidDataUnitName();
    error InvalidDataUnitType();

    struct Provider {
        address payable primaryWallet;
        address payable[] walletAddresses;
        uint256 balance;
        string name;
        bool active;
        uint256 sales;
    }

    struct DataUnit {
        uint256 id;
        string dataUnitName;
        uint256 price; // WHOLE USD integer (10 means $10), NOT 1e18-scaled
        string dataUnitType;
        address payable provider;
        uint256 totalRevenue; // in wei
        uint256 purchaseCount;
        uint256 providerSplitPercent; // basis points on SPLIT_PERCENT_SCALE (9950 = 99.5%)
        uint256 ownerSplitPercent; // basis points on SPLIT_PERCENT_SCALE (50 = 0.5%)
        address tokenizerAddress;
    }

    address payable private owner;
    DataUnit[] private allDataUnits;
    Provider[] private allProviders;
    string[] private dataUnitTypes;
    uint256 private nextDataUnitId = 1;

    mapping(uint256 => DataUnit) private dataUnits;
    mapping(address => DataUnit[]) private dataUnitBuyers;
    mapping(address => Provider) private registeredProviders;
    mapping(address => address) private walletToProvider;

    event DataUnitCreated(
        uint256 indexed dataUnitId,
        address indexed provider,
        string dataUnitName,
        uint256 price,
        string dataUnitType,
        uint256 providerSplitPercent,
        uint256 ownerSplitPercent,
        address tokenizerAddress
    );

    event DataUnitPurchased(
        uint256 indexed dataUnitId,
        address indexed buyer,
        uint256 amountWei
    );

    modifier isOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier isProvider() {
        address primaryProvider = walletToProvider[msg.sender];
        if (primaryProvider == address(0) || !registeredProviders[primaryProvider].active) revert NotProvider();
        _;
    }

    constructor() {
        owner = payable(msg.sender);
    }

    function getOwner() external view returns (address) {
        return owner;
    }

    function registerProvider(string memory _name) public {
        if (walletToProvider[msg.sender] != address(0)) revert WalletRegistered();

        address payable[] memory wallets = new address payable[](1);
        wallets[0] = payable(msg.sender);

        Provider memory newProvider = Provider({
            primaryWallet: payable(msg.sender),
            walletAddresses: wallets,
            balance: 0,
            name: _name,
            active: true,
            sales: 0
        });

        registeredProviders[msg.sender] = newProvider;
        walletToProvider[msg.sender] = msg.sender;
        allProviders.push(newProvider);
    }

    function addProviderWallet(address payable _newWallet) public {
        address primaryProvider = walletToProvider[msg.sender];
        if (primaryProvider == address(0) || !registeredProviders[primaryProvider].active) revert NotProvider();
        if (_newWallet == address(0)) revert InvalidWallet();
        if (walletToProvider[_newWallet] != address(0)) revert WalletRegistered();
        if (registeredProviders[primaryProvider].walletAddresses.length >= 3) revert MaxWalletsReached();

        registeredProviders[primaryProvider].walletAddresses.push(_newWallet);
        walletToProvider[_newWallet] = primaryProvider;
    }

    function removeProviderWallet(address payable _walletToRemove) public {
        address primaryProvider = walletToProvider[msg.sender];
        if (primaryProvider == address(0) || !registeredProviders[primaryProvider].active) revert NotProvider();
        if (walletToProvider[_walletToRemove] != primaryProvider) revert InvalidWallet();
        if (_walletToRemove == registeredProviders[primaryProvider].primaryWallet) revert CannotRemovePrimary();
        if (registeredProviders[primaryProvider].walletAddresses.length <= 1) revert MustKeepOneWallet();

        address payable[] storage wallets = registeredProviders[primaryProvider].walletAddresses;
        for (uint256 i = 0; i < wallets.length; i++) {
            if (wallets[i] == _walletToRemove) {
                wallets[i] = wallets[wallets.length - 1];
                wallets.pop();
                break;
            }
        }

        walletToProvider[_walletToRemove] = address(0);
    }

    function getProviderWallets(address _primaryProvider) public view returns (address payable[] memory) {
        return registeredProviders[_primaryProvider].walletAddresses;
    }

    function getPrimaryProvider(address _wallet) public view returns (address) {
        return walletToProvider[_wallet];
    }

    function getAllProviders() public view isOwner returns (Provider[] memory) {
        return allProviders;
    }

    function getProviderDetails(address _primaryProviderAddress) public view isOwner returns (Provider memory) {
        return registeredProviders[_primaryProviderAddress];
    }

    function getProviderDetailsByWallet(address _walletAddress) public view returns (Provider memory) {
        address primaryProvider = walletToProvider[_walletAddress];
        if (primaryProvider == address(0)) revert WalletNotRegistered();
        return registeredProviders[primaryProvider];
    }

    function getProviderDataUnits(address _providerAddress) public view returns (DataUnit[] memory) {
        address primaryProvider = walletToProvider[_providerAddress];
        if (primaryProvider == address(0)) {
            primaryProvider = _providerAddress;
        }

        address payable[] memory wallets = registeredProviders[primaryProvider].walletAddresses;
        DataUnit[] memory providerDataUnits = new DataUnit[](allDataUnits.length);
        uint256 count = 0;

        for (uint256 i = 0; i < allDataUnits.length; i++) {
            for (uint256 j = 0; j < wallets.length; j++) {
                if (allDataUnits[i].provider == wallets[j]) {
                    providerDataUnits[count] = allDataUnits[i];
                    count++;
                    break;
                }
            }
        }

        assembly {
            mstore(providerDataUnits, count)
        }

        return providerDataUnits;
    }

    function getBuyerDataUnits() public view returns (DataUnit[] memory) {
        return dataUnitBuyers[msg.sender];
    }

    function getProviderSales(address _providerAddress) public view returns (uint256) {
        address primaryProvider = walletToProvider[_providerAddress];
        if (primaryProvider == address(0)) {
            primaryProvider = _providerAddress;
        }
        return registeredProviders[primaryProvider].sales;
    }

    // _price is WHOLE USD integer (10 means $10)
    // _providerSplitPercent / _ownerSplitPercent are basis points (10000 = 100%)
    // tokenizerAddress: use address(0) (hex 0x000...0) when ownerSplitPercent == 0
    function createDataUnit(
        string memory _dataUnitName,
        uint256 _price,
        string memory _dataUnitType,
        uint256 _providerSplitPercent,
        uint256 _ownerSplitPercent,
        address _tokenizerAddress
    ) public isProvider {
        if (bytes(_dataUnitName).length == 0) revert InvalidDataUnitName();
        if (bytes(_dataUnitType).length == 0) revert InvalidDataUnitType();

        // Whole-dollar rule
        if (_price == 0 || _price > 999_999_999) revert InvalidPrice();

        if (_providerSplitPercent + _ownerSplitPercent != SPLIT_PERCENT_SCALE) revert InvalidSplit();
        if (_providerSplitPercent > SPLIT_PERCENT_SCALE || _ownerSplitPercent > SPLIT_PERCENT_SCALE) revert InvalidSplit();

        // tokenizer required when owner split > 0
        if (_ownerSplitPercent > 0 && _tokenizerAddress == address(0)) revert InvalidTokenizerAddress();
        // if owner split is 0, tokenizer must be address(0)
        if (_ownerSplitPercent == 0 && _tokenizerAddress != address(0)) revert InvalidTokenizerAddress();

        uint256 newId = nextDataUnitId;
        nextDataUnitId++;

        DataUnit memory newDataUnit = DataUnit({
            id: newId,
            dataUnitName: _dataUnitName,
            price: _price,
            dataUnitType: _dataUnitType,
            provider: payable(msg.sender),
            totalRevenue: 0,
            purchaseCount: 0,
            providerSplitPercent: _providerSplitPercent,
            ownerSplitPercent: _ownerSplitPercent,
            tokenizerAddress: _tokenizerAddress
        });

        dataUnits[newDataUnit.id] = newDataUnit;
        allDataUnits.push(newDataUnit);

        bool exists = false;
        for (uint256 i = 0; i < dataUnitTypes.length; i++) {
            if (keccak256(bytes(dataUnitTypes[i])) == keccak256(bytes(_dataUnitType))) {
                exists = true;
                break;
            }
        }

        if (!exists) {
            dataUnitTypes.push(_dataUnitType);
        }

        emit DataUnitCreated(
            newDataUnit.id,
            msg.sender,
            _dataUnitName,
            _price,
            _dataUnitType,
            _providerSplitPercent,
            _ownerSplitPercent,
            _tokenizerAddress
        );
    }

    // msg.value is wei payment; price is stored as USD integer metadata
    function buyDataUnit(uint256 _dataUnitId) external payable {
        DataUnit memory dataUnit = dataUnits[_dataUnitId];
        address payable providerAddress = dataUnit.provider;

        if (dataUnit.id == 0) revert DataUnitNotFound();
        if (msg.value == 0) revert InvalidPayment();

        address primaryProvider = walletToProvider[providerAddress];
        if (primaryProvider == address(0)) {
            primaryProvider = providerAddress;
        }

        if (walletToProvider[msg.sender] == primaryProvider || msg.sender == providerAddress) {
            revert CannotBuyOwnData();
        }

        uint256 providerSplitPercent = dataUnit.providerSplitPercent;
        uint256 ownerSplitPercent = dataUnit.ownerSplitPercent;
        address tokenizerAddress = dataUnit.tokenizerAddress;

        if (providerSplitPercent + ownerSplitPercent != SPLIT_PERCENT_SCALE) revert InvalidSplit();
        if (providerSplitPercent > SPLIT_PERCENT_SCALE || ownerSplitPercent > SPLIT_PERCENT_SCALE) revert InvalidSplit();

        dataUnits[_dataUnitId].totalRevenue += msg.value;
        dataUnits[_dataUnitId].purchaseCount++;

        uint256 len = allDataUnits.length;
        for (uint256 i = 0; i < len; i++) {
            if (allDataUnits[i].id == _dataUnitId) {
                allDataUnits[i].totalRevenue += msg.value;
                allDataUnits[i].purchaseCount++;
                break;
            }
        }

        registeredProviders[primaryProvider].sales++;
        dataUnitBuyers[msg.sender].push(dataUnits[_dataUnitId]);

        uint256 providerAmount = (msg.value * providerSplitPercent) / SPLIT_PERCENT_SCALE;
        uint256 tokenizerAmount = (msg.value * ownerSplitPercent) / SPLIT_PERCENT_SCALE;

        if (providerAmount > 0) {
            providerAddress.transfer(providerAmount);
        }

        if (tokenizerAmount > 0 && tokenizerAddress != address(0)) {
            payable(tokenizerAddress).transfer(tokenizerAmount);
        }

        emit DataUnitPurchased(_dataUnitId, msg.sender, msg.value);
    }

    function getAllDataUnits() public view returns (DataUnit[] memory) {
        return allDataUnits;
    }

    function getAvailableDataUnitsById(uint256 _dataUnitId) public view returns (DataUnit memory) {
        return dataUnits[_dataUnitId];
    }

    function getAllDataUnitTypes() public view returns (string[] memory) {
        return dataUnitTypes;
    }

    function getDataUnitRevenue(uint256 _dataUnitId) public view returns (uint256) {
        return dataUnits[_dataUnitId].totalRevenue;
    }
}