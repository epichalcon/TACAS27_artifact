// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IWETH {
    function withdraw(uint256 amount) external;
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
}

interface IStETH {
    function submit(address referral) external payable returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
}

contract CowWethToStEth {
    IWETH constant WETH = IWETH(0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2);
    IStETH constant STETH = IStETH(0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84);

    address payable immutable beneficiary;
    bool public stakingPaused = false;


    constructor(address payable _beneficiary) {
        beneficiary = _beneficiary;
    }

    receive() external payable {
        if (stakingPaused) {
            beneficiary.call{value: address(this).balance}("");
        } else {
            STETH.submit{value: address(this).balance}(address(0));
            require(STETH.transfer(beneficiary, STETH.balanceOf(address(this))), "stETH transfer failed");
        }
    }

    function setStakingPaused(bool paused) external {
        require(msg.sender == beneficiary, "Not beneficiary");
        stakingPaused = paused;
    }


    // Intentionally permissionless: anyone can trigger it,
    // but every resulting stETH goes only to beneficiary.
    function stakeAll() external {
        require(!stakingPaused, "Staking paused");
        uint256 wethAmount = WETH.balanceOf(address(this));
        require(wethAmount != 0, "No WETH received");

        WETH.withdraw(wethAmount);
        STETH.submit{value: wethAmount}(address(0));

        require(STETH.transfer(beneficiary, STETH.balanceOf(address(this))), "stETH transfer failed");
    }

    // Lets you recover WETH if Lido is paused or the post-hook fails.
    function recover() external {
        require(msg.sender == beneficiary, "Not beneficiary");
        uint256 wethAmount = WETH.balanceOf(address(this));
        WETH.transfer(beneficiary, wethAmount);
        uint256 stethAmount = STETH.balanceOf(address(this));
        STETH.transfer(beneficiary, stethAmount);
        beneficiary.call{value: address(this).balance}("");
    }
}