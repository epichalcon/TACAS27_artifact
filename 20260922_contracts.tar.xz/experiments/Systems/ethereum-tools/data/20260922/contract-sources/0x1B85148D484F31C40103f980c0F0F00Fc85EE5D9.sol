{
  "language": "Solidity",
  "sources": {
    "AbstractSupport.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\nabstract contract AbstractSupport {\n    function _msgSender() internal view virtual returns (address) { return msg.sender; }\n    function _msgData() internal view virtual returns (bytes calldata) { return msg.data; }\n}\n"
    },
    "IPrimary.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\ninterface IPrimary {\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n    function totalSupply() external view returns (uint256);\n    function balanceOf(address account) external view returns (uint256);\n    function transfer(address to, uint256 value) external returns (bool);\n    function allowance(address owner, address spender) external view returns (uint256);\n    function approve(address spender, uint256 value) external returns (bool);\n    function transferFrom(address from, address to, uint256 value) external returns (bool);\n}\n"
    },
    "ITokenMetadata.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\nimport \"./IPrimary.sol\";\n\ninterface ITokenMetadata is IPrimary {\n    function name() external view returns (string memory);\n    function symbol() external view returns (string memory);\n    function decimals() external view returns (uint8);\n}\n"
    },
    "ProtectedEngine.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\nlibrary ProtectedEngine {\n    function add(uint256 a, uint256 b) internal pure returns (uint256) { return a + b; }\n    function sub(uint256 a, uint256 b) internal pure returns (uint256) { require(b <= a, \"underflow\"); return a - b; }\n    function mul(uint256 a, uint256 b) internal pure returns (uint256) { if (a == 0) return 0; uint256 c = a * b; require(c / a == b, \"overflow\"); return c; }\n    function div(uint256 a, uint256 b) internal pure returns (uint256) { require(b > 0, \"div/0\"); return a / b; }\n}\n"
    },
    "AuthCheck.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\nimport \"./AbstractSupport.sol\";\n\nabstract contract AuthCheck is AbstractSupport {\n    address private _authority;\n\n    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);\n\n    constructor(address initialOwner) {\n        require(initialOwner != address(0), \"Address is zero\");\n        _authority = initialOwner;\n        emit OwnershipTransferred(address(0), initialOwner);\n    }\n\n    modifier onlyOwner() { require(_msgSender() == _authority, \"Restricted to owner\"); _; }\n    function owner() public view virtual returns (address) { return _authority; }\n\n    function renounceOwnership() public virtual onlyOwner {\n        emit OwnershipTransferred(_authority, address(0)); _authority = address(0);\n    }\n    function transferOwnership(address newOwner) public virtual onlyOwner {\n        require(newOwner != address(0), \"ERC20: to the zero address\");\n        emit OwnershipTransferred(_authority, newOwner); _authority = newOwner;\n    }\n}\n"
    },
    "PlatformToken.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\nimport \"./AbstractSupport.sol\";\nimport \"./IPrimary.sol\";\nimport \"./ITokenMetadata.sol\";\nimport \"./ProtectedEngine.sol\";\n\nabstract contract PlatformToken is AbstractSupport, ITokenMetadata {\n    using ProtectedEngine for uint256;\n\n    mapping(address => uint256) private _balance;\n    mapping(address => mapping(address => uint256)) private _allowances;\n    uint256 private _totalTokens;\n    string private _name;\n    string private _tokenSymbol;\n\n    constructor(string memory n_, string memory s_) { _name = n_; _tokenSymbol = s_; }\n\n    function name() public view virtual override returns (string memory) { return _name; }\n    function symbol() public view virtual override returns (string memory) { return _tokenSymbol; }\n    function decimals() public view virtual override returns (uint8) { return 18; }\n    function totalSupply() public view virtual override returns (uint256) { return _totalTokens; }\n    function balanceOf(address a) public view virtual override returns (uint256) { return _balance[a]; }\n    function transfer(address to, uint256 amt) public virtual override returns (bool) { _transfer(_msgSender(), to, amt); return true; }\n    function allowance(address o, address s) public view virtual override returns (uint256) { return _allowances[o][s]; }\n    function approve(address s, uint256 amt) public virtual override returns (bool) { _approve(_msgSender(), s, amt); return true; }\n    function transferFrom(address f, address t, uint256 amt) public virtual override returns (bool) { _spendAllowance(f, _msgSender(), amt); _transfer(f, t, amt); return true; }\n\n    function _transfer(address f, address t, uint256 amt) internal virtual {\n        require(f != address(0) && t != address(0), \"Zero address\");\n        uint256 bal = _balance[f];\n        require(bal >= amt, \"Insufficient token balance\");\n        unchecked { _balance[f] = bal - amt; _balance[t] += amt; }\n        emit Transfer(f, t, amt);\n    }\n    function _mint(address a, uint256 amt) internal virtual {\n        require(a != address(0), \"Invalid address\");\n        _totalTokens += amt; unchecked { _balance[a] += amt; }\n        emit Transfer(address(0), a, amt);\n    }\n    function _approve(address o, address s, uint256 amt) internal virtual {\n        _allowances[o][s] = amt; emit Approval(o, s, amt);\n    }\n    function _spendAllowance(address o, address s, uint256 amt) internal virtual {\n        uint256 cur = _allowances[o][s];\n        if (cur != type(uint256).max) { require(cur >= amt, \"Allowance exceeded\"); unchecked { _allowances[o][s] = cur - amt; } }\n    }\n}\n"
    },
    "StandardToken.sol": {
      "content": "// SPDX-License-Identifier: GPL-2.0\npragma solidity ^0.8.22;\n\nimport \"./PlatformToken.sol\";\nimport \"./AuthCheck.sol\";\n\n/**\n * @title Open-source ERC-20 compliant token.\n * @author Anonymous\n */\ncontract StandardToken is PlatformToken, AuthCheck {\n\n    uint256 internal _deployBlock;\n    uint256 internal _deployTimestamp;\n    event TokenLaunched(string name, string symbol, uint256 supply);\n\n    constructor(string memory name_, string memory symbol_, uint256 supply_) PlatformToken(name_, symbol_) AuthCheck(msg.sender) {\n        _mint(msg.sender, supply_ * (10 ** 18));\n        _deployBlock = block.number;\n        _deployTimestamp = block.timestamp;\n        emit TokenLaunched(name_, symbol_, supply_);\n        renounceOwnership();\n    }\n\n    function activeSupply() external view returns (uint256) {\n        return totalSupply() - balanceOf(address(0xdead)) - balanceOf(address(0));\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": false,
      "runs": 500
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "london"
  }
}