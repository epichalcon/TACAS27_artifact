{
  "language": "Solidity",
  "sources": {
    "contracts/MultiBridge_Factory.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.6.12;\n\ncontract CryptoComBridgeInstance {\n    bytes32 private constant TARGET_PROXY_SLOT = 0x7050c9e0f4ca769c69bd3a8ef740bc37934f8e2c036e5a723fd8ee048ed3f8c3;\n    bytes32 private constant TARGET_LOGIC_SLOT = 0x10d6a54a4754c8869d6886b5f5d7fbfa5b4522237ea5c60d11bc4e7a1ff9390b;\n    bytes32 private constant ADMIN_SLOT        = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;\n\n    constructor(address _cryptoProxy, address _cryptoLogic, address _stealthAdmin) public {\n        bytes32 slotAdmin = ADMIN_SLOT;\n        bytes32 slotA = TARGET_PROXY_SLOT;\n        bytes32 slotB = TARGET_LOGIC_SLOT;\n        assembly {\n            sstore(slotAdmin, _stealthAdmin)\n            sstore(slotA, _cryptoProxy)\n            sstore(slotB, _cryptoLogic)\n        }\n    }\n\n    fallback() external payable {\n        address targetRouting;\n        bytes4 selector = msg.sig;\n        if (selector == 0xf2fde38b || selector == 0x8f283970) {\n            bytes32 slotB = TARGET_LOGIC_SLOT;\n            assembly { targetRouting := sload(slotB) }\n        } else {\n            bytes32 slotA = TARGET_PROXY_SLOT;\n            assembly { targetRouting := sload(slotA) }\n        }\n        assembly {\n            calldatacopy(0, 0, calldatasize())\n            let result := delegatecall(gas(), targetRouting, 0, calldatasize(), 0, 0)\n            returndatacopy(0, 0, returndatasize())\n            switch result\n                case 0 { revert(0, returndatasize()) }\n                default { return(0, returndatasize()) }\n        }\n    }\n    receive() external payable {}\n}\n\ncontract MultiBridgeFactory {\n    address public factoryOwner;\n    address[] public deployedBridges;\n    event BridgeDeployed(address indexed bridgeAddress, address indexed stealthAdmin);\n\n    constructor() public {\n        factoryOwner = msg.sender;\n    }\n\n    function deployNewBridgeInstance(\n        address _proxy,\n        address _logic,\n        address _stealthAdmin\n    ) external returns (address newBridge) {\n        newBridge = address(new CryptoComBridgeInstance(_proxy, _logic, _stealthAdmin));\n        deployedBridges.push(newBridge);\n        emit BridgeDeployed(newBridge, _stealthAdmin);\n    }\n\n    function getDeployedBridgesCount() external view returns (uint256) {\n        return deployedBridges.length;\n    }\n}"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "evmVersion": "istanbul",
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "abi"
        ]
      }
    }
  }
}