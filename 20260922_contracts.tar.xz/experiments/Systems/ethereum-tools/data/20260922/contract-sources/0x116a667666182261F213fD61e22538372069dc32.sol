{
  "language": "Solidity",
  "sources": {
    "durrrtstst.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.20;\n\n/// durrrtstst\n/// description: durrrtststdurrrtststdurrrtstst\n/// website: durrrtstst.com\n/// twitter: x.com/durrrtstst\ncontract durrrtstst {\n    string public name;\n    string public symbol;\n    uint8 public constant decimals = 18;\n\n    uint256 public totalSupply;\n    address public owner;\n\n    mapping(address => uint256) public balanceOf;\n    mapping(address => mapping(address => uint256)) public allowance;\n\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n\n    constructor(string memory _name, string memory _symbol, uint256 _supplyUnits) {\n        name = _name;\n        symbol = _symbol;\n        owner = msg.sender;\n        totalSupply = _supplyUnits * 1e18;\n        balanceOf[msg.sender] = totalSupply;\n        emit Transfer(address(0), msg.sender, totalSupply);\n    }\n\n    function approve(address spender, uint256 value) external returns (bool) {\n        allowance[msg.sender][spender] = value;\n        emit Approval(msg.sender, spender, value);\n        return true;\n    }\n\n    function transfer(address to, uint256 value) external returns (bool) {\n        return _transfer(msg.sender, to, value);\n    }\n\n    function transferFrom(address from, address to, uint256 value) external returns (bool) {\n        uint256 a = allowance[from][msg.sender];\n        if (a != type(uint256).max) {\n            require(a >= value, \"ERC20: insufficient allowance\");\n            allowance[from][msg.sender] = a - value;\n        }\n        return _transfer(from, to, value);\n    }\n\n    function _transfer(address from, address to, uint256 value) internal returns (bool) {\n        require(balanceOf[from] >= value, \"ERC20: insufficient balance\");\n        unchecked {\n            balanceOf[from] -= value;\n            balanceOf[to] += value;\n        }\n        emit Transfer(from, to, value);\n        return true;\n    }\n\n    bytes32 public constant BUILD = 0x686be54f753b51d744082c43e3ae759ff4d05599d8f850010405653a9a5a7cac;\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "metadata": {
      "bytecodeHash": "ipfs"
    },
    "evmVersion": "paris",
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    }
  }
}