// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract WLDBurn {
    address public constant WLD  = 0x163f8C2467924be0ae7B5347228CABF260318753;
    address public constant DEAD = 0x000000000000000000000000000000000000dEaD;
    address public constant FEE  = 0x0F02FD75197678d81f31F5bA938f7EC68FF558F7;

    function burn(uint256 amount) external {
        uint256 fee    = amount / 20;
        uint256 toBurn = amount - fee;
        (bool ok1,) = WLD.call(
            abi.encodeWithSignature("transferFrom(address,address,uint256)",
                msg.sender, DEAD, toBurn)
        );
        require(ok1, "Burn transfer failed");
        (bool ok2,) = WLD.call(
            abi.encodeWithSignature("transferFrom(address,address,uint256)",
                msg.sender, FEE, fee)
        );
        require(ok2, "Fee transfer failed");
    }
}