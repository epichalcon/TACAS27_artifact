// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
}

interface ILighter {
    /// @notice Deposit to Lighter
    /// @param _assetIndex Asset index
    /// @param _routeType Route type
    /// @param _amount Token amount
    /// @param _to The receiver L1 address
    function deposit(
        address _to,
        uint16 _assetIndex,
        uint8 _routeType,
        uint256 _amount
    ) external payable;
}

contract LighterDepositForwarder {
    // configurable at deploy
    address public immutable caller1; // only this address can trigger deposits/withdrawals
    address public immutable source2; // token source (must approve this contract)
    address public constant USDC   = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address public constant LIGHTER = 0x3B4D794a66304F130a4Db8F2551B0070dfCf5ca7;

    constructor(address _caller1, address _source2) {
        require(_caller1 != address(0) && _source2 != address(0), "zero");
        caller1 = _caller1;
        source2 = _source2;
    }

    modifier onlyCaller1() {
        require(msg.sender == caller1, "not caller1");
        _;
    }

    /// @notice Allow receiving ETH directly
    receive() external payable {}
    fallback() external payable {}

    /// @notice Withdraw any ERC20 stuck in this contract to source2
    function withdrawERC20(address _token) external onlyCaller1 {
        require(_token != address(0), "zero");
        uint256 bal = IERC20(_token).balanceOf(address(this));
        require(IERC20(_token).transfer(source2, bal), "transfer failed");
    }

    /// @notice Deposit to Lighter (pulls token from source2, approves, deposits)
    function depositToLighter(
        uint256 _amount
    ) external onlyCaller1 {
        // pull tokens from source2 -> this
        require(IERC20(USDC).transferFrom(source2, address(this), _amount), "pull failed");
        // approve Lighter (simple pattern)
        require(IERC20(USDC).approve(LIGHTER, _amount), "approve failed");

        // call Lighter deposit forwarding ETH if needed
        ILighter(LIGHTER).deposit(source2, 3, 0, _amount);

        // refund leftover ETH (if any)
        uint256 refund = address(this).balance;
        if (refund > 0) {
            (bool ok, ) = payable(msg.sender).call{value: refund}("");
            require(ok, "REFUND_FAILED");
        }
    }
}