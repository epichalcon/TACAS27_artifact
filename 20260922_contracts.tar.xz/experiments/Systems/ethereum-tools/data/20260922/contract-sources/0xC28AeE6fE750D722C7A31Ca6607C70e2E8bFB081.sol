// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

contract SecretCastle {
    string public constant name = "Secret Castle";
    string public constant symbol = "SCRT";
    uint8 public constant decimals = 18;

    uint256 public constant INITIAL_SUPPLY = 500_000 * 10 ** 18;

    // Clearly identified genesis allocations
    uint256 public constant CREATOR_ALLOCATION = 25_000 * 10 ** 18;
    uint256 public constant PUBLIC_ALLOCATION = 245_000 * 10 ** 18;

    uint256 private _totalSupply;

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;

    // EIP-2612
    mapping(address => uint256) public nonces;

    bytes32 public immutable DOMAIN_SEPARATOR;

    bytes32 private constant PERMIT_TYPEHASH =
        keccak256(
            "Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)"
        );

    event Transfer(
        address indexed from,
        address indexed to,
        uint256 value
    );

    event Approval(
        address indexed owner,
        address indexed spender,
        uint256 value
    );

    constructor(
        address creator,
        address treasury,
        address operations,
        address longTermReserve,
        address publicAuction
    ) {
        require(creator != address(0), "Invalid creator");
        require(treasury != address(0), "Invalid treasury");
        require(operations != address(0), "Invalid operations");
        require(longTermReserve != address(0), "Invalid reserve");
        require(publicAuction != address(0), "Invalid auction");

        /*
         * TOTAL SUPPLY
         * 500,000 SCRT
         *
         * CREATOR
         * 25,000 SCRT
         *
         * PUBLIC AUCTION
         * 245,000 SCRT
         *
         * COMPANY
         * 230,000 SCRT
         *
         * The creator allocation is removed equally
         * from the three company allocations.
         */

        // Creator: 25,000 SCRT
        uint256 creatorAmount =
            25_000_000_000_000_000_000_000;

        // Treasury:
        // 191,250 - 8,333.333333333333333333
        uint256 treasuryAmount =
            182_916_666_666_666_666_667_000;

        // Operations:
        // 31,875 - 8,333.333333333333333333
        uint256 operationsAmount =
            23_541_666_666_666_666_667_000;

        // Long-term reserve:
        // 31,875 - 8,333.333333333333333334
        uint256 reserveAmount =
            23_541_666_666_666_666_666_000;

        // Public auction: 245,000 SCRT
        uint256 publicAmount =
            245_000_000_000_000_000_000_000;

        _mint(creator, creatorAmount);
        _mint(treasury, treasuryAmount);
        _mint(operations, operationsAmount);
        _mint(longTermReserve, reserveAmount);
        _mint(publicAuction, publicAmount);

        require(
            _totalSupply == INITIAL_SUPPLY,
            "Supply allocation error"
        );

        DOMAIN_SEPARATOR = keccak256(
            abi.encode(
                keccak256(
                    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
                ),
                keccak256(bytes(name)),
                keccak256(bytes("1")),
                block.chainid,
                address(this)
            )
        );
    }

    // =============================================================
    // ERC-20
    // =============================================================

    function totalSupply() external view returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) external view returns (uint256) {
        return _balances[account];
    }

    function allowance(
        address owner,
        address spender
    ) external view returns (uint256) {
        return _allowances[owner][spender];
    }

    function transfer(
        address to,
        uint256 amount
    ) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function approve(
        address spender,
        uint256 amount
    ) external returns (bool) {
        _approve(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) external returns (bool) {
        uint256 currentAllowance = _allowances[from][msg.sender];

        require(
            currentAllowance >= amount,
            "ERC20: insufficient allowance"
        );

        if (currentAllowance != type(uint256).max) {
            _allowances[from][msg.sender] =
                currentAllowance -
                amount;
        }

        _transfer(from, to, amount);

        return true;
    }

    // =============================================================
    // VOLUNTARY BURN
    // =============================================================

    function burn(uint256 amount) external {
        require(
            _balances[msg.sender] >= amount,
            "ERC20: burn amount exceeds balance"
        );

        _balances[msg.sender] -= amount;
        _totalSupply -= amount;

        emit Transfer(msg.sender, address(0), amount);
    }

    // =============================================================
    // EIP-2612 PERMIT
    // =============================================================

    function permit(
        address owner,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external {
        require(
            block.timestamp <= deadline,
            "ERC20Permit: expired deadline"
        );

        uint256 nonce = nonces[owner];

        bytes32 structHash = keccak256(
            abi.encode(
                PERMIT_TYPEHASH,
                owner,
                spender,
                value,
                nonce,
                deadline
            )
        );

        bytes32 digest = keccak256(
            abi.encodePacked(
                "\x19\x01",
                DOMAIN_SEPARATOR,
                structHash
            )
        );

        address signer = ecrecover(digest, v, r, s);

        require(
            signer != address(0) && signer == owner,
            "ERC20Permit: invalid signature"
        );

        nonces[owner] = nonce + 1;

        _approve(owner, spender, value);
    }

    // =============================================================
    // INTERNAL FUNCTIONS
    // =============================================================

    function _mint(address account, uint256 amount) internal {
        require(
            account != address(0),
            "ERC20: mint to zero address"
        );

        _balances[account] += amount;
        _totalSupply += amount;

        emit Transfer(address(0), account, amount);
    }

    function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal {
        require(
            from != address(0),
            "ERC20: transfer from zero address"
        );

        require(
            to != address(0),
            "ERC20: transfer to zero address"
        );

        uint256 fromBalance = _balances[from];

        require(
            fromBalance >= amount,
            "ERC20: transfer amount exceeds balance"
        );

        _balances[from] = fromBalance - amount;
        _balances[to] += amount;

        emit Transfer(from, to, amount);
    }

    function _approve(
        address owner,
        address spender,
        uint256 amount
    ) internal {
        require(
            owner != address(0),
            "ERC20: approve from zero address"
        );

        require(
            spender != address(0),
            "ERC20: approve to zero address"
        );

        _allowances[owner][spender] = amount;

        emit Approval(owner, spender, amount);
    }
}