{
  "language": "Solidity",
  "sources": {
    "src/CallProxy.sol": {
      "content": "// SPDX-License-Identifier: BUSL-1.1\npragma solidity =0.8.19;\n\ninterface IRenounceRole {\n    function renounceRole(bytes32 role, address account) external;\n}\n\n/// @notice a contract which acts as a forwarder that forwards the input from\n/// any caller to a a target contract.\ncontract CallProxy {\n    event TargetSet(address target);\n\n    address immutable i_target;\n\n    constructor(address target) {\n        i_target = target;\n        emit TargetSet(target);\n    }\n\n    fallback() external payable {\n        require(\n            msg.data.length < 4 ||\n                bytes4(msg.data) != IRenounceRole.renounceRole.selector,\n            \"CallProxy: renounceRole is blocked\"\n        );\n        address target = i_target;\n        assembly {\n            // This code destroys Solidity's memory layout.\n            // That's fine, because we never return to Solidity anyways,\n            // we either return or revert out of the callframe at the end.\n            calldatacopy(0, 0, calldatasize())\n            let success := call(gas(), target, callvalue(), 0, calldatasize(), 0, 0)\n            returndatacopy(0, 0, returndatasize())\n            if success { return(0, returndatasize()) }\n            revert(0, returndatasize())\n        }\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": false,
      "runs": 200
    },
    "evmVersion": "paris",
    "metadata": {
      "bytecodeHash": "ipfs"
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "abi"
        ]
      }
    }
  }
}