{
  "language": "Solidity",
  "sources": {
    "src/zero/RgbPng32Encoder.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\nimport { IRgbPng32 } from \"./interfaces/IRgbPng32.sol\";\nimport { RgbPng32 } from \"./lib/RgbPng32.sol\";\n\ncontract RgbPng32Encoder is IRgbPng32 {\n    function encode(bytes calldata rgb) external pure returns (bytes memory png) {\n        return RgbPng32.encode(rgb);\n    }\n}\n"
    },
    "src/zero/interfaces/IRgbPng32.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\ninterface IRgbPng32 {\n    function encode(bytes calldata rgb) external pure returns (bytes memory png);\n}\n"
    },
    "src/zero/lib/RgbPng32.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\nlibrary RgbPng32 {\n    uint256 internal constant CANVAS = 32;\n    uint256 internal constant ROW_RGB_BYTES = CANVAS * 3;\n    uint256 internal constant RGB_BYTES = CANVAS * ROW_RGB_BYTES;\n    uint256 internal constant RAW_BYTES = CANVAS * (ROW_RGB_BYTES + 1);\n\n    error InvalidRgbLength(uint256 actual);\n\n    function encode(bytes memory rgb) internal pure returns (bytes memory) {\n        if (rgb.length != RGB_BYTES) revert InvalidRgbLength(rgb.length);\n\n        bytes memory raw = new bytes(RAW_BYTES);\n        uint256 source;\n        for (uint256 y; y < CANVAS; ++y) {\n            uint256 destination = y * (ROW_RGB_BYTES + 1) + 1;\n            for (uint256 i; i < ROW_RGB_BYTES; ++i) {\n                raw[destination + i] = rgb[source++];\n            }\n        }\n\n        uint256 length = raw.length;\n        uint256 inverseLength = ~length & 0xffff;\n        bytes memory zlibStream = abi.encodePacked(\n            hex\"7801\",\n            hex\"01\",\n            bytes1(uint8(length)),\n            bytes1(uint8(length >> 8)),\n            bytes1(uint8(inverseLength)),\n            bytes1(uint8(inverseLength >> 8)),\n            raw,\n            bytes4(_adler32(raw))\n        );\n\n        bytes memory ihdr = abi.encodePacked(\n            bytes4(uint32(CANVAS)), bytes4(uint32(CANVAS)), hex\"08\", hex\"02\", hex\"000000\"\n        );\n\n        return abi.encodePacked(\n            hex\"89504e470d0a1a0a\",\n            _chunk(\"IHDR\", ihdr),\n            _chunk(\"IDAT\", zlibStream),\n            _chunk(\"IEND\", new bytes(0))\n        );\n    }\n\n    function _chunk(bytes4 chunkType, bytes memory data) private pure returns (bytes memory) {\n        bytes memory typeAndData = abi.encodePacked(chunkType, data);\n        return\n            abi.encodePacked(bytes4(uint32(data.length)), typeAndData, bytes4(_crc32(typeAndData)));\n    }\n\n    function _crc32(bytes memory data) private pure returns (uint32) {\n        uint32 crc = 0xffffffff;\n        for (uint256 i; i < data.length; ++i) {\n            crc ^= uint8(data[i]);\n            crc = (crc >> 4) ^ _crcNibble(crc & 0x0f);\n            crc = (crc >> 4) ^ _crcNibble(crc & 0x0f);\n        }\n        return crc ^ 0xffffffff;\n    }\n\n    function _crcNibble(uint32 index) private pure returns (uint32 value) {\n        uint256 packed = index < 8\n            ? 0x000000001db710643b6e20c826d930ac76dc41906b6b51f44db261585005713c\n            : 0xedb88320f00f9344d6d6a3e8cb61b38c9b64c2b086d3d2d4a00ae278bdbdf21c;\n        unchecked {\n            value = uint32(packed >> ((7 - (uint256(index) & 7)) * 32));\n        }\n    }\n\n    function _adler32(bytes memory data) private pure returns (uint32) {\n        uint256 sum1 = 1;\n        uint256 sum2;\n        for (uint256 i; i < data.length; ++i) {\n            sum1 += uint8(data[i]);\n            sum2 += sum1;\n        }\n        sum1 %= 65521;\n        sum2 %= 65521;\n        return uint32((sum2 << 16) | sum1);\n    }\n}\n"
    }
  },
  "settings": {
    "remappings": [
      "@openzeppelin/contracts/=lib/openzeppelin-contracts/contracts/",
      "ds-test/=lib/openzeppelin-contracts/lib/forge-std/lib/ds-test/src/",
      "erc4626-tests/=lib/openzeppelin-contracts/lib/erc4626-tests/",
      "forge-std/=lib/forge-std/src/",
      "halmos-cheatcodes/=lib/openzeppelin-contracts/lib/halmos-cheatcodes/src/",
      "openzeppelin-contracts/=lib/openzeppelin-contracts/",
      "solady/=lib/solady/src/"
    ],
    "optimizer": {
      "enabled": true,
      "runs": 25
    },
    "metadata": {
      "bytecodeHash": "ipfs"
    },
    "evmVersion": "prague",
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    }
  }
}