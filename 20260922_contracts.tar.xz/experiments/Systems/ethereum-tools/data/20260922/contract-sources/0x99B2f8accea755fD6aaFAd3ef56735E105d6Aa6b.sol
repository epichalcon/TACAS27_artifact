// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Proxy {
    address public implementation;
    constructor(address _impl) {
        implementation = _impl;
    }
    fallback() external payable {
        (bool success,) = implementation.delegatecall(msg.data);
        require(success);
    }
    receive() external payable {} // ← ligne ajoutée pour étouffer le warning
}