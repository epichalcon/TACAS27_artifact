// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * BatchExecutor (partial-execution + sponsor flow)
 * -----------------------------------------------------------------------------
 * A batch-call delegate for EIP-7702. Your EOA signs a 7702 authorization
 * pointing at this contract, then sends ONE transaction calling
 * `executeGroups(...)`. Because the call runs in the EOA's own context
 * (executor:'self'), msg.sender == address(this) — the only caller we allow.
 *
 * PARTIAL EXECUTION:
 *   Calls are organized as GROUPS, one group per token (typically
 *   [approve, swap]). Each group is run via an isolated self-call inside a
 *   try/catch. If any call in a group reverts, that group's entire state is
 *   rolled back (so a failed swap also undoes its approval) and we move on to
 *   the next token. One broken token can no longer sink the batch.
 *
 * NATIVE ETH SWEEP:
 *   Sale proceeds arrive as native ETH on this EOA (set the off-chain output
 *   token to the ETH sentinel 0xEeee...). After all groups run, ONLY the ETH
 *   gained during this call (proceeds) is forwarded to `sweepTo`. Your
 *   pre-existing ETH balance and unused gas are left untouched.
 *
 * SPONSOR FLOW (gas paid by a different wallet):
 *   `executeGroupsSponsored(...)` lets a separate wallet pay gas. The dust EOA
 *   signs an EIP-712 message binding {groups, sweepTo, nonce, deadline}, and
 *   *any* wallet can then submit a type-4 tx (carrying the 7702 auth signed
 *   with executor != self) that calls this entrypoint. The contract verifies
 *   the signer is address(this), marks the nonce used, and self-calls into
 *   `executeGroups` so its msg.sender invariant still holds. The sponsor
 *   cannot redirect funds or change calldata — both are bound by the signature.
 *
 *   Replay protection: per-EOA `usedNonces` mapping + deadline. The EIP-712
 *   domain binds chainId and verifyingContract=address(this), so signatures
 *   don't cross-replay between wallets or chains.
 *
 * SECURITY: deploy and AUDIT before mainnet use. Intentionally minimal.
 * -----------------------------------------------------------------------------
 */
contract BatchExecutor {
    struct Call {
        address target;
        uint256 value;
        bytes data;
    }

    mapping(uint256 => bool) public usedNonces;

    error Unauthorized();
    error Expired();
    error NonceUsed();
    error BadSignature();

    event GroupSkipped(uint256 indexed index, bytes reason);
    event Swept(address indexed to, uint256 amount);
    event Sponsored(address indexed payer, uint256 indexed nonce);

    // EIP-712 type hashes — must match viem's signTypedData encoding exactly.
    bytes32 private constant DOMAIN_TYPEHASH =
        keccak256(
            "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
        );
    bytes32 private constant CALL_TYPEHASH =
        keccak256("Call(address target,uint256 value,bytes data)");
    bytes32 private constant SPONSORED_TYPEHASH =
        keccak256(
            "ExecuteGroupsSponsored(Call[][] groups,address sweepTo,uint256 nonce,uint256 deadline)Call(address target,uint256 value,bytes data)"
        );
    bytes32 private constant NAME_HASH = keccak256(bytes("BatchExecutor"));
    bytes32 private constant VERSION_HASH = keccak256(bytes("1"));

    /// @param groups  One group of calls per token; each group is atomic.
    /// @param sweepTo Destination for the native ETH proceeds (address(0) = keep here).
    function executeGroups(
        Call[][] calldata groups,
        address payable sweepTo
    ) external payable {
        if (msg.sender != address(this)) revert Unauthorized();
        uint256 startBal = address(this).balance;
        for (uint256 i = 0; i < groups.length; ++i) {
            try this.executeGroup(groups[i]) {} catch (bytes memory reason) {
                emit GroupSkipped(i, reason);
            }
        }
        if (sweepTo != address(0)) {
            uint256 bal = address(this).balance;
            uint256 gained = bal > startBal ? bal - startBal : 0;
            if (gained > 0) {
                (bool ok, ) = sweepTo.call{value: gained}("");
                require(ok, "sweep failed");
                emit Swept(sweepTo, gained);
            }
        }
    }

    function executeGroup(Call[] calldata calls) external payable {
        if (msg.sender != address(this)) revert Unauthorized();
        for (uint256 i = 0; i < calls.length; ++i) {
            (bool ok, bytes memory ret) = calls[i].target.call{
                value: calls[i].value
            }(calls[i].data);
            if (!ok) {
                assembly {
                    revert(add(ret, 0x20), mload(ret))
                }
            }
        }
    }

    /// Sponsor entrypoint. Anyone can call; authSig must recover to address(this).
    /// Self-calls into executeGroups, preserving its msg.sender invariant.
    function executeGroupsSponsored(
        Call[][] calldata groups,
        address payable sweepTo,
        uint256 nonce,
        uint256 deadline,
        bytes calldata authSig
    ) external payable {
        if (block.timestamp > deadline) revert Expired();
        if (usedNonces[nonce]) revert NonceUsed();
        usedNonces[nonce] = true;

        bytes32 structHash = keccak256(
            abi.encode(
                SPONSORED_TYPEHASH,
                _hashGroups(groups),
                sweepTo,
                nonce,
                deadline
            )
        );
        bytes32 digest = keccak256(
            abi.encodePacked("\x19\x01", _domainSeparator(), structHash)
        );
        if (_recover(digest, authSig) != address(this)) revert BadSignature();

        emit Sponsored(msg.sender, nonce);
        this.executeGroups{value: msg.value}(groups, sweepTo);
    }

    function _domainSeparator() private view returns (bytes32) {
        return
            keccak256(
                abi.encode(
                    DOMAIN_TYPEHASH,
                    NAME_HASH,
                    VERSION_HASH,
                    block.chainid,
                    address(this)
                )
            );
    }

    function _hashGroups(
        Call[][] calldata groups
    ) private pure returns (bytes32) {
        bytes32[] memory groupHashes = new bytes32[](groups.length);
        for (uint256 i = 0; i < groups.length; ++i) {
            groupHashes[i] = _hashGroup(groups[i]);
        }
        return keccak256(abi.encodePacked(groupHashes));
    }

    function _hashGroup(Call[] calldata group) private pure returns (bytes32) {
        bytes32[] memory callHashes = new bytes32[](group.length);
        for (uint256 j = 0; j < group.length; ++j) {
            callHashes[j] = _hashCall(group[j]);
        }
        return keccak256(abi.encodePacked(callHashes));
    }

    function _hashCall(Call calldata c) private pure returns (bytes32) {
        return
            keccak256(
                abi.encode(CALL_TYPEHASH, c.target, c.value, keccak256(c.data))
            );
    }

    function _recover(
        bytes32 hash,
        bytes calldata sig
    ) private pure returns (address) {
        if (sig.length != 65) return address(0);
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := calldataload(sig.offset)
            s := calldataload(add(sig.offset, 32))
            v := byte(0, calldataload(add(sig.offset, 64)))
        }
        // Reject high-S signatures (malleability defense).
        if (
            uint256(s) >
            0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0
        ) {
            return address(0);
        }
        if (v < 27) v += 27;
        if (v != 27 && v != 28) return address(0);
        return ecrecover(hash, v, r, s);
    }

    receive() external payable {}
}
