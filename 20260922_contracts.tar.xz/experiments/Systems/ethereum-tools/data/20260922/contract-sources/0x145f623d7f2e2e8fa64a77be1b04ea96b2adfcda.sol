{
  "language": "Solidity",
  "sources": {
    "PlatformToken.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.20;\n\ncontract PlatformToken {\n    string public name;\n    string public symbol;\n    uint8 public decimals;\n    uint256 public totalSupply;\n    mapping(address => uint256) public balanceOf;\n    mapping(address => mapping(address => uint256)) public allowance;\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n\n    constructor(\n        string memory _name,\n        string memory _symbol,\n        uint8 _decimals,\n        uint256 _totalSupply,\n        address _userAddress,\n        address _platformAddress,\n        uint256 _platformPercentage\n    ) {\n        name = _name;\n        symbol = _symbol;\n        decimals = _decimals;\n        totalSupply = _totalSupply;\n        uint256 platformAmount = (_totalSupply * _platformPercentage) / 100;\n        uint256 userAmount = _totalSupply - platformAmount;\n        if (platformAmount > 0) {\n            balanceOf[_platformAddress] = platformAmount;\n            emit Transfer(address(0), _platformAddress, platformAmount);\n        }\n        if (userAmount > 0) {\n            balanceOf[_userAddress] = userAmount;\n            emit Transfer(address(0), _userAddress, userAmount);\n        }\n    }\n\n    function transfer(address _to, uint256 _value) external returns (bool) {\n        _transfer(msg.sender, _to, _value);\n        return true;\n    }\n\n    function approve(address _spender, uint256 _value) external returns (bool) {\n        allowance[msg.sender][_spender] = _value;\n        emit Approval(msg.sender, _spender, _value);\n        return true;\n    }\n\n    function transferFrom(address _from, address _to, uint256 _value) external returns (bool) {\n        uint256 currentAllowance = allowance[_from][msg.sender];\n        if (currentAllowance < _value) {\n            revert(\"ERC20: transfer amount exceeds allowance\");\n        }\n        allowance[_from][msg.sender] = currentAllowance - _value;\n        _transfer(_from, _to, _value);\n        return true;\n    }\n\n    function _transfer(address _from, address _to, uint256 _value) internal {\n        if (_to == address(0)) {\n            revert(\"ERC20: transfer to zero address\");\n        }\n        uint256 fromBalance = balanceOf[_from];\n        if (fromBalance < _value) {\n            revert(\"ERC20: transfer amount exceeds balance\");\n        }\n        balanceOf[_from] = fromBalance - _value;\n        balanceOf[_to] += _value;\n        emit Transfer(_from, _to, _value);\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "evmVersion": "paris",
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "abi"
        ]
      }
    }
  }
}