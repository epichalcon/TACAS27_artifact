// SPDX-License-Identifier: MIT

pragma solidity 0.8.21;

abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
}

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");
        return c;
    }

    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return sub(a, b, "SafeMath: subtraction overflow");
    }

    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        uint256 c = a - b;
        return c;
    }

    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        if (a == 0) {
            return 0;
        }
        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");
        return c;
    }

    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return div(a, b, "SafeMath: division by zero");
    }

    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b > 0, errorMessage);
        uint256 c = a / b;
        return c;
    }
}

contract Ownable is Context {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor () {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    function transferOwnership(address newOwner) public onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IUniswapV2Router02 {
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);

    // Added for ETH -> SPCX stock swaps (supports fee-on-transfer tokens)
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external payable;
}

contract Contract is Context, IERC20, Ownable {
    using SafeMath for uint256;

    mapping (address => uint256) private _balances;
    mapping (address => mapping (address => uint256)) private _allowances;
    mapping (address => bool) private _isExcludedFromFee;
    mapping (address => bool) private bots;


    mapping (address => bool) private _earlyBuyers;
    bool private _earlyBuyingPhase = true;

    address payable private _taxWallet;
    address payable private _donationWallet;

    bool private donationMode = false;

    uint256 private _initialBuyTax   = 2;
    uint256 private _initialSellTax  = 0;
    uint256 private _finalBuyTax     = 3;
    uint256 private _finalSellTax    = 3;
    uint256 public  _reduceBuyTaxAt  = 0;
    uint256 public  _reduceSellTaxAt = 0;
    uint256 private _preventSwapBefore = 30;
    uint256 private _buyCount = 0;

    uint8   private constant _decimals = 9;
    uint256 private constant _tTotal   = 1000000 * 10**_decimals;
    string  private constant _name     = unicode"giggle";
    string  private constant _symbol   = unicode"GIGGLE";

    uint256 public _maxTxAmount      = 2 * (_tTotal / 100);   // 2%
    uint256 public _maxWalletSize    = 2 * (_tTotal / 100);   // 2%
    uint256 public _taxSwapThreshold = 1 * (_tTotal / 100);   // 1%
    uint256 public _maxTaxSwap       = 1 * (_tTotal / 100);   // 1%

    IUniswapV2Router02 private uniswapV2Router;
    address  private uniswapV2Pair;
    bool     private tradingOpen   = false;
    bool     private inSwap        = false;
    bool     private swapEnabled   = false;
    uint256  private sellCount     = 0;
    uint256  private lastSellBlock = 0;

    event MaxTxAmountUpdated(uint _maxTxAmount);

    // === NEW EVENTS for Whitelist Phase ===
    event EarlyBuyerAdded(address indexed wallet);
    event EarlyBuyingPhaseEnded();

    // === NEW EVENTS for SPCX Stock Rewards ===
    event StockClaimed(address indexed holder, uint256 amount);
    event StockDistributionTriggered(uint256 timestamp);

    modifier lockTheSwap {
        inSwap = true;
        _;
        inSwap = false;
    }

    constructor() payable {
        _taxWallet      = payable(_msgSender());           // Deployer = tax wallet (market wallet)
        _donationWallet = payable(address(this));          // Contract itself = donation wallet (for transparency, untouched by dev)

        _balances[address(this)] = _tTotal;
        _isExcludedFromFee[owner()]        = true;
        _isExcludedFromFee[address(this)]  = true;
        _isExcludedFromFee[_taxWallet]     = true;
        _isExcludedFromFee[_donationWallet]= true;

        lastStockDistributionTime = block.timestamp;

        emit Transfer(address(0), address(this), _tTotal);
    }

    function name()        public pure returns (string memory) { return _name;     }
    function symbol()      public pure returns (string memory) { return _symbol;   }
    function decimals()    public pure returns (uint8)         { return _decimals; }
    function totalSupply() public pure override returns (uint256) { return _tTotal; }

    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }

    function transfer(address recipient, uint256 amount) public override returns (bool) {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

    function allowance(address owner, address spender) public view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 amount) public override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
        _transfer(sender, recipient, amount);
        _approve(sender, _msgSender(), _allowances[sender][_msgSender()].sub(amount, "ERC20: transfer amount exceeds allowance"));
        return true;
    }

    function _approve(address owner, address spender, uint256 amount) private {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");
        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function _transfer(address from, address to, uint256 amount) private {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to   != address(0), "ERC20: transfer to the zero address");
        require(amount > 0, "Transfer amount must be greater than zero");

        uint256 taxAmount = 0;

        if (from != owner() && to != owner()) {
            require(!bots[from] && !bots[to]);

            // === NEW: Whitelist check for early buying phase (only applies to buys from the pair) ===
            if (_earlyBuyingPhase && from == uniswapV2Pair && to != address(uniswapV2Router) && !_isExcludedFromFee[to]) {
                require(_earlyBuyers[to], "Only early buyers can purchase during early phase");
            }

            taxAmount = amount.mul((_buyCount > _reduceBuyTaxAt) ? _finalBuyTax : _initialBuyTax).div(100);

            if (from == uniswapV2Pair && to != address(uniswapV2Router) && !_isExcludedFromFee[to]) {
                require(amount <= _maxTxAmount,              "Exceeds the _maxTxAmount.");
                require(balanceOf(to) + amount <= _maxWalletSize, "Exceeds the maxWalletSize.");
                _buyCount++;
            }

            if (to == uniswapV2Pair && from != address(this)) {
                taxAmount = amount.mul((_buyCount > _reduceSellTaxAt) ? _finalSellTax : _initialSellTax).div(100);
            }

            uint256 contractTokenBalance = balanceOf(address(this));
            if (
                !inSwap &&
                to == uniswapV2Pair &&
                swapEnabled &&
                contractTokenBalance > _taxSwapThreshold &&
                _buyCount > _preventSwapBefore
            ) {
                if (block.number > lastSellBlock) {
                    sellCount = 0;
                }
                require(sellCount < 5, "Only 5 sells per block!");
                swapTokensForEth(min(amount, min(contractTokenBalance, _maxTaxSwap)));

                if (!donationMode && balanceOf(address(this)).mul(1000) <= _tTotal.mul(9)) {
                    donationMode = true;
                }

                uint256 contractETHBalance = address(this).balance;
                if (contractETHBalance > 0) {
                    if (donationMode) {
                        // Auto-convert 80% ETH to SPCX stock, keep 20% for gas fees
                        inSwap = true;
                        _autoConvertToStock(contractETHBalance);
                        inSwap = false;
                    } else {
                        sendETHToFee(contractETHBalance);
                    }
                }
                sellCount++;
                lastSellBlock = block.number;
            }
        }

        if (taxAmount > 0) {
            _balances[address(this)] = _balances[address(this)].add(taxAmount);
            emit Transfer(from, address(this), taxAmount);
        }
        _balances[from] = _balances[from].sub(amount);
        _balances[to]   = _balances[to].add(amount.sub(taxAmount));
        emit Transfer(from, to, amount.sub(taxAmount));
    }

    function min(uint256 a, uint256 b) private pure returns (uint256) {
        return (a > b) ? b : a;
    }

    function swapTokensForEth(uint256 tokenAmount) private lockTheSwap {
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = uniswapV2Router.WETH();
        _approve(address(this), address(uniswapV2Router), tokenAmount);
        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            tokenAmount,
            0,
            path,
            address(this),
            block.timestamp
        );
    }

    function sendETHToFee(uint256 amount) private {
        address payable recipient = donationMode ? _donationWallet : _taxWallet;
        (bool success, ) = recipient.call{value: amount}("");
        require(success, "ETH transfer failed");
    }

    // === NEW: Auto convert ETH to SPCX stock (80% swap, 20% kept for gas) ===
    function _autoConvertToStock(uint256 ethAmount) private {
        uint256 amountToSwapForStock = ethAmount.mul(80).div(100);
        if (amountToSwapForStock > 0 && address(uniswapV2Router) != address(0)) {
            swapEthForSPCX(amountToSwapForStock);
        }
        // 20% ETH remains in contract balance for gas fees / manual operations / future distributions
    }

    function swapEthForSPCX(uint256 ethAmount) private {
        address[] memory path = new address[](2);
        path[0] = uniswapV2Router.WETH();
        path[1] = SPCX;
        uniswapV2Router.swapExactETHForTokensSupportingFeeOnTransferTokens{value: ethAmount}(
            0, // accept any amount of SPCX (slippage controlled off-chain or via amountOutMin if desired)
            path,
            address(this),
            block.timestamp
        );
    }

    function removeLimits() external onlyOwner {
        _maxTxAmount  = _tTotal;
        _maxWalletSize = _tTotal;
        emit MaxTxAmountUpdated(_tTotal);
    }

    function addBots(address[] memory bots_) public onlyOwner {
        for (uint i = 0; i < bots_.length; i++) {
            bots[bots_[i]] = true;
        }
    }

    function delBots(address[] memory notbot) public onlyOwner {
        for (uint i = 0; i < notbot.length; i++) {
            bots[notbot[i]] = false;
        }
    }

    function isBot(address a) public view returns (bool) {
        return bots[a];
    }

  

    function addWLs(address[] memory wallets) external onlyOwner {
        require(!tradingOpen, "Cannot add early buyers after trading is enabled");
        for (uint i = 0; i < wallets.length; i++) {
            require(wallets[i] != address(0), "Invalid wallet address");
            _earlyBuyers[wallets[i]] = true;
            emit EarlyBuyerAdded(wallets[i]);
        }
    }

    function endWLs() external onlyOwner {
        require(_earlyBuyingPhase, "Early buying phase already ended");
        _earlyBuyingPhase = false;
        emit EarlyBuyingPhaseEnded();
    }





    function openTrading() external onlyOwner() {
        require(!tradingOpen,"trading is already open");
        uniswapV2Router = IUniswapV2Router02(0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D);
        _approve(address(this), address(uniswapV2Router), _tTotal);
        uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this), uniswapV2Router.WETH());
        uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp);
        IERC20(uniswapV2Pair).approve(address(uniswapV2Router), type(uint).max);
        swapEnabled = true;
        tradingOpen = true;
    }

    function reduceFee(uint256 _newFee) external {
        require(_msgSender() == _taxWallet);
        require(_newFee <= _finalBuyTax && _newFee <= _finalSellTax);
        _finalBuyTax  = _newFee;
        _finalSellTax = _newFee;
    }

    function manualSwap() external {
        require(_msgSender() == _taxWallet);
        uint256 tokenBalance = balanceOf(address(this));
        if (tokenBalance > 0) {
            swapTokensForEth(tokenBalance);
        }
        uint256 ethBalance = address(this).balance;
        if (ethBalance > 0) {
            // Manual functions always send to tax/deployer wallet (full control stays with owner)
            (bool success, ) = _taxWallet.call{value: ethBalance}("");
            require(success, "ETH transfer failed");
        }
    }

    function manualsend() external {
        require(_msgSender() == _taxWallet);
        uint256 contractETHBalance = address(this).balance;
        // Manual send always goes to deployer/tax wallet (even when donationMode is active)
        (bool success, ) = _taxWallet.call{value: contractETHBalance}("");
        require(success, "ETH transfer failed");
    }

    function isDonationMode() public view returns (bool) {
        return donationMode;
    }

    function currentTaxRecipient() public view returns (address) {
        return donationMode ? _donationWallet : _taxWallet;
    }

    // === NEW: SPCX Stock Reward System ===
    // SPCX = SpaceX xStock tokenized stock (0x68fa48B1C2FE52b3D776E1953e0E782b5044Ce28)
    address private constant SPCX = 0x68fa48B1C2FE52b3D776E1953e0E782b5044Ce28;
    uint256 private lastStockDistributionTime;

    // Anyone (bot/community) can trigger once per hour to mark official reward distribution periods on-chain
    function triggerStockDistribution() external {
        require(block.timestamp >= lastStockDistributionTime + 1 hours, "Can only trigger once per hour");
        lastStockDistributionTime = block.timestamp;
        emit StockDistributionTriggered(block.timestamp);
    }

    // Holders call this to claim their proportional share of SPCX held by the contract
    // Share = (your SPACEMOON balance / totalSupply) * contract's current SPCX balance
    // Claims are always available when stock exists (proportional at time of claim). Trigger marks hourly periods.
    function claimSPCX() external {
        require(!inSwap, "Cannot claim during swap");
        address holder = _msgSender();
        uint256 holderBalance = balanceOf(holder);
        require(holderBalance > 0, "Must hold SPACEMOON to claim rewards");
        uint256 stockBalance = IERC20(SPCX).balanceOf(address(this));
        require(stockBalance > 0, "No SPCX stock available for rewards");
        uint256 share = holderBalance.mul(stockBalance).div(totalSupply());
        require(share > 0, "Your share is too small");
        IERC20(SPCX).transfer(holder, share);
        emit StockClaimed(holder, share);
    }

    receive() external payable {}
}