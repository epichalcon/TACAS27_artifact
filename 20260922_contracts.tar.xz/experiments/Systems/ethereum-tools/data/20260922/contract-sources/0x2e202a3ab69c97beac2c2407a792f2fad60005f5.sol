{
  "language": "Solidity",
  "sources": {
    "SimpleLPLocker.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.20;\n\ninterface IERC20 {\n    function transferFrom(address from, address to, uint256 amount) external returns (bool);\n    function transfer(address to, uint256 amount) external returns (bool);\n    function balanceOf(address account) external view returns (uint256);\n}\n\ncontract SimpleLPLocker {\n\n    address public immutable owner;\n\n    address public constant LP_TOKEN = 0x3345C1eEd6B12854c0C603a9970EF967d3e89C4D;\n    uint256 public constant UNLOCK_TIME = 25846031;\n\n    bool public locked;\n\n    constructor() {\n        owner = msg.sender;\n    }\n\n    function lock() external {\n        require(msg.sender == owner, \"not owner\");\n        require(!locked, \"already locked\");\n\n        uint256 amount = IERC20(LP_TOKEN).balanceOf(owner);\n        require(amount > 0, \"zero balance\");\n\n        locked = true;\n\n        require(\n            IERC20(LP_TOKEN).transferFrom(owner, address(this), amount),\n            \"transferFrom failed\"\n        );\n    }\n\n    function unlock() external {\n        require(msg.sender == owner, \"not owner\");\n        require(block.timestamp >= UNLOCK_TIME, \"still locked\");\n\n        uint256 amount = IERC20(LP_TOKEN).balanceOf(address(this));\n        require(amount > 0, \"zero balance\");\n\n        require(\n            IERC20(LP_TOKEN).transfer(owner, amount),\n            \"transfer failed\"\n        );\n    }\n\n    function lockedBalance() external view returns (uint256) {\n        return IERC20(LP_TOKEN).balanceOf(address(this));\n    }\n}"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": false,
      "runs": 200
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "abi"
        ]
      }
    },
    "remappings": []
  }
}