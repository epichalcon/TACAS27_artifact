// SPDX-License-Identifier: MIT
pragma solidity =0.8.24;









struct Market {
    uint256 chainId;
    address midnight;
    address loanToken;
    CollateralParams[] collateralParams;
    uint256 maturity;
    uint256 rcfThreshold;
    address enterGate;
    address liquidatorGate;
}

struct CollateralParams {
    address token;
    uint256 lltv;
    uint256 liquidationCursor;
    address oracle;
}

struct Offer {
    Market market;
    bool buy;
    address maker;
    uint256 start;
    uint256 expiry;
    uint256 tick;
    bytes32 group;
    address callback;
    bytes callbackData;
    address receiverIfMakerIsSeller;
    address ratifier;
    bool reduceOnly;
    uint128 maxUnits;
    uint128 maxAssets; // buyerAssets if offer.buy else sellerAssets
    uint256 continuousFeeCap;
}



struct MarketState {
    uint128 totalUnits; // credit units
    uint128 lossFactor;
    uint128 withdrawable;
    uint128 continuousFeeCredit;
    uint16 settlementFeeCbp0;
    uint16 settlementFeeCbp1;
    uint16 settlementFeeCbp2;
    uint16 settlementFeeCbp3;
    uint16 settlementFeeCbp4;
    uint16 settlementFeeCbp5;
    uint16 settlementFeeCbp6;
    uint32 continuousFee;
    uint8 tickSpacing;
}

struct Position {
    uint128 credit;
    uint128 pendingFee;
    uint128 lastLossFactor;
    uint128 lastAccrual;
    uint128 debt;
    uint128 collateralBitmap;
    uint128[128] collateral;
}

interface IMidnight {
    // forgefmt: disable-start
    /// STORAGE GETTERS ///
    function position(bytes32 id, address user) external view returns (uint128 credit, uint128 pendingFee, uint128 lastLossFactor, uint128 lastAccrual, uint128 debt, uint128 collateralBitmap);
    function marketState(bytes32 id) external view returns (uint128 totalUnits, uint128 lossFactor, uint128 withdrawable, uint128 continuousFeeCredit, uint16 settlementFeeCbp0, uint16 settlementFeeCbp1, uint16 settlementFeeCbp2, uint16 settlementFeeCbp3, uint16 settlementFeeCbp4, uint16 settlementFeeCbp5, uint16 settlementFeeCbp6, uint32 continuousFee, uint8 tickSpacing);
    function consumed(address user, bytes32 group) external view returns (uint128);
    function isAuthorized(address authorizer, address authorized) external view returns (bool);
    function defaultSettlementFeeCbp(address loanToken, uint256 index) external view returns (uint16);
    function defaultContinuousFee(address loanToken) external view returns (uint32);
    function claimableSettlementFee(address token) external view returns (uint256);
    function isLltvEnabled(uint256 lltv) external view returns (bool);
    function isLiquidationCursorEnabled(uint256 liquidationCursor) external view returns (bool);
    function configurator() external view returns (address);
    function feeSetter() external view returns (address);
    function feeClaimer() external view returns (address);
    function tickSpacingSetter() external view returns (address);

    /// MULTICALL ///
    function multicall(bytes[] memory calls) external;

    /// ADMIN FUNCTIONS ///
    function setConfigurator(address newConfigurator) external;
    function setFeeSetter(address newFeeSetter) external;
    function setFeeClaimer(address newFeeClaimer) external;
    function setTickSpacingSetter(address newTickSpacingSetter) external;
    function enableLltv(uint256 lltv) external;
    function enableLiquidationCursor(uint256 liquidationCursor) external;
    function setMarketTickSpacing(bytes32 id, uint256 newTickSpacing) external;
    function setMarketSettlementFee(bytes32 id, uint256 index, uint256 newSettlementFee) external;
    function setDefaultSettlementFee(address loanToken, uint256 index, uint256 newSettlementFee) external;
    function setMarketContinuousFee(bytes32 id, uint256 newContinuousFee) external;
    function setDefaultContinuousFee(address loanToken, uint256 newContinuousFee) external;
    function claimSettlementFee(address token, uint256 amount, address receiver) external;
    function claimContinuousFee(Market memory market, uint256 amount, address receiver) external;

    /// ENTRY-POINTS ///
    function take(Offer memory offer, bytes memory ratifierData, uint256 units, address taker, address receiverIfTakerIsSeller, address takerCallback, bytes memory takerCallbackData) external returns (uint256 buyerAssets, uint256 sellerAssets);
    function withdraw(Market memory market, uint256 units, address onBehalf, address receiver) external;
    function repay(Market memory market, uint256 units, address onBehalf, address callback, bytes memory data) external;
    function supplyCollateral(Market memory market, uint256 collateralIndex, uint256 assets, address onBehalf) external;
    function withdrawCollateral(Market memory market, uint256 collateralIndex, uint256 assets, address onBehalf, address receiver) external;
    function liquidate(Market memory market, uint256 collateralIndex, uint256 seizedAssets, uint256 repaidUnits, address borrower, bool postMaturityMode, address receiver, address callback, bytes memory data) external returns (uint256 outputSeizedAssets, uint256 outputRepaidUnits);
    function setConsumed(bytes32 group, uint128 amount, address onBehalf) external;
    function setIsAuthorized(address authorized, bool newIsAuthorized, address onBehalf) external;
    function flashLoan(address[] memory tokens, uint256[] memory assets, address callback, bytes memory data) external;
    function touchMarket(Market memory market) external returns (bytes32);

    /// SLASHING AND CONTINUOUS FEE ACCRUAL ///
    function updatePositionView(Market memory market, bytes32 id, address user) external view returns (uint128 newCredit, uint128 newPendingFee, uint128 accruedFee);
    function updatePosition(Market memory market, address user) external returns (uint128 newCredit, uint128 newPendingFee, uint128 accruedFee);

    /// OTHER VIEW FUNCTIONS ///
    function lastLossFactor(bytes32 id, address user) external view returns (uint128);
    function collateralBitmap(bytes32 id, address user) external view returns (uint128);
    function collateral(bytes32 id, address user, uint256 index) external view returns (uint128);
    function toMarket(bytes32 id) external view returns (Market memory);
    function credit(bytes32 id, address user) external view returns (uint128);
    function debt(bytes32 id, address user) external view returns (uint128);
    function totalUnits(bytes32 id) external view returns (uint128);
    function lossFactor(bytes32 id) external view returns (uint128);
    function tickSpacing(bytes32 id) external view returns (uint8);
    function withdrawable(bytes32 id) external view returns (uint128);
    function settlementFeeCbps(bytes32 id) external view returns (uint16[7] memory);
    function continuousFee(bytes32 id) external view returns (uint32);
    function continuousFeeCredit(bytes32 id) external view returns (uint128);
    function pendingFee(bytes32 id, address user) external view returns (uint128);
    function lastAccrual(bytes32 id, address user) external view returns (uint128);
    function liquidationLocked(bytes32 id, address user) external view returns (bool);
    function isHealthy(Market memory market, bytes32 id, address borrower) external view returns (bool);
    function settlementFee(bytes32 id, uint256 timeToMaturity) external view returns (uint256);
    // forgefmt: disable-end
}









library IdLib {
    /// @dev Used as a prefix to some data, to give a creation code that deploys the data as runtime bytecode.
    /// @dev Explanation of the prefix:
    /// hex       opcode          stack              comments
    /// ------------------------------------------------------------------------------
    /// 60 0b     PUSH1 0x0b      [11]               11 = length(prefix)
    /// 38        CODESIZE        [codesize, 11]
    /// 03        SUB             [len]              with len = codesize - 11
    /// 80        DUP1            [len, len]
    /// 60 0b     PUSH1 0x0b      [11, len, len]     code offset = 11
    /// 5f        PUSH0           [0, 11, len, len]  mem offset = 0
    /// 39        CODECOPY        [len]              mem[0:len] <- code[11:11+len]
    /// 5f        PUSH0           [0, len]           return offset = 0
    /// f3        RETURN          []                 mem[0:len] is returned
    bytes constant SSTORE2_PREFIX = hex"600b380380600b5f395ff3";

    function toId(Market memory market) internal pure returns (bytes32) {
        return keccak256(
            abi.encodePacked(
                uint8(0xff),
                market.midnight,
                uint256(0),
                keccak256(abi.encodePacked(SSTORE2_PREFIX, abi.encode(market)))
            )
        );
    }
}







contract MainnetMidnightAddresses {
    IMidnight internal constant MIDNIGHT = IMidnight(0x471686c42792F93528B000beF54bC10E3aa2045f);
}
















library UtilsLib {
    function zeroFloorSub(uint256 x, uint256 y) internal pure returns (uint256 z) {
        assembly {
            z := mul(gt(x, y), sub(x, y))
        }
    }

    /// @dev Assumes bitmap is not zero.
    function msb(uint128 bitmap) internal pure returns (uint256 res) {
        assembly {
            bitmap := and(bitmap, 0xffffffffffffffffffffffffffffffff)
            res := shl(6, gt(bitmap, 0xffffffffffffffff))
            res := or(res, shl(5, gt(shr(res, bitmap), 0xffffffff)))
            res := or(res, shl(4, gt(shr(res, bitmap), 0xffff)))
            res := or(res, shl(3, gt(shr(res, bitmap), 0xff)))
            res := or(res, shl(2, gt(shr(res, bitmap), 0xf)))
            res := or(res, shl(1, gt(shr(res, bitmap), 0x3)))
            res := or(res, gt(shr(res, bitmap), 0x1))
        }
    }

    /// @dev Assumes bit is less than 128.
    function clearBit(uint128 bitmap, uint256 bit) internal pure returns (uint128) {
        // forge-lint: disable-next-item(unsafe-typecast)
        return uint128(bitmap & ~(1 << bit));
    }

    /// @dev Returns (x * y) / d rounded down.
    function mulDivDown(uint256 x, uint256 y, uint256 d) internal pure returns (uint256) {
        return (x * y) / d;
    }

    /// @dev Returns (x * y) / d rounded up.
    function mulDivUp(uint256 x, uint256 y, uint256 d) internal pure returns (uint256) {
        return (x * y + (d - 1)) / d;
    }

    /// @dev Returns min(x, y).
    function min(uint256 x, uint256 y) internal pure returns (uint256 z) {
        assembly {
            z := xor(x, mul(xor(x, y), lt(y, x)))
        }
    }

    /// @dev Returns min(x, y, z).
    function min(uint256 x, uint256 y, uint256 z) internal pure returns (uint256) {
        return min(min(x, y), z);
    }

    /// @dev Returns min(x, y, z, w).
    function min(uint256 x, uint256 y, uint256 z, uint256 w) internal pure returns (uint256) {
        return min(min(x, y, z), w);
    }
}






interface IOracle {
    function price() external view returns (uint256);
}











contract MidnightHelper is MainnetMidnightAddresses {
    error InvalidCollateralIndex();
    error InvalidOfferType();
    error InvalidOfferMarketId();
    error NoOrdersProvided();
    error ZeroAmountRequested();

    /// @dev Oracle price is scaled by 1e36 + debtDec - collDec
    /// If we want to calculate collateral value in deb tokens:
    /// X = collateral * price * 10^debtDec / 10^collDec / 10^(36 + debtDec - collDec)
    /// X = collateral * price * 10^debtDec / 10^(collDec + 36 + debtDec - collDec)
    /// X = collateral * price * 10^debtDec / 10^(36 + debtDec)
    /// X = collateral * price / 10^36
    /// X = collateral * price / ORACLE_PRICE_SCALE
    uint256 internal constant ORACLE_PRICE_SCALE = 1e36;
    uint256 internal constant WAD = 1e18;

    function getRatio(bytes32 _id, address _user) public view returns (uint256 ratio) {
        (,,,, uint128 debt, uint128 collateralBitmap) = MIDNIGHT.position(_id, _user);

        if (debt == 0) return 0;

        Market memory market = MIDNIGHT.toMarket(_id);

        uint256 totalCollInDebtToken;
        while (collateralBitmap != 0) {
            uint256 i = UtilsLib.msb(collateralBitmap);
            uint256 price = IOracle(market.collateralParams[i].oracle).price();
            uint256 collateral = MIDNIGHT.collateral(_id, _user, i);
            totalCollInDebtToken += collateral * price / ORACLE_PRICE_SCALE;
            collateralBitmap = UtilsLib.clearBit(collateralBitmap, i);
        }

        ratio = totalCollInDebtToken * WAD / debt;
    }
}











contract MidnightView is MidnightHelper {
    struct MarketInfo {
        bytes32 id;
        uint128 totalUnits;
        uint128 lossFactor;
        uint128 withdrawable;
        uint128 continuousFeeCredit;
        uint16[7] settlementFees;
        uint32 continuousFee;
        uint8 tickSpacing;
        uint256[] prices;
    }

    struct PositionInfo {
        uint128 credit;
        uint128 pendingFee;
        uint128 debt;
        uint128 collateralBitmap;
        uint128[] collateral;
        uint256 ratio;
    }

    function toMarket(bytes32 _id) public view returns (Market memory market) {
        market = MIDNIGHT.toMarket(_id);
    }

    function toId(Market memory _market) public pure returns (bytes32 id) {
        id = IdLib.toId(_market);
    }

    function getMarketInfo(bytes32 _id) public view returns (MarketInfo memory info) {
        // Use separate calls to avoid stack too deep errors.
        info.id = _id;
        info.totalUnits = MIDNIGHT.totalUnits(_id);
        info.lossFactor = MIDNIGHT.lossFactor(_id);
        info.withdrawable = MIDNIGHT.withdrawable(_id);
        info.continuousFeeCredit = MIDNIGHT.continuousFeeCredit(_id);
        info.settlementFees = MIDNIGHT.settlementFeeCbps(_id);
        info.continuousFee = MIDNIGHT.continuousFee(_id);
        info.tickSpacing = MIDNIGHT.tickSpacing(_id);

        Market memory market = toMarket(_id);
        info.prices = new uint256[](market.collateralParams.length);
        for (uint256 i = 0; i < market.collateralParams.length; ++i) {
            info.prices[i] = IOracle(market.collateralParams[i].oracle).price();
        }
    }

    function getPositionInfo(bytes32 _id, address _user)
        public
        view
        returns (PositionInfo memory pos)
    {
        (pos.credit, pos.pendingFee,,, pos.debt, pos.collateralBitmap) =
            MIDNIGHT.position(_id, _user);

        Market memory market = toMarket(_id);

        pos.collateral = new uint128[](market.collateralParams.length);
        uint256 totalCollInDebtToken;

        uint128 map = pos.collateralBitmap;
        while (map != 0) {
            uint256 i = UtilsLib.msb(map);
            pos.collateral[i] = MIDNIGHT.collateral(_id, _user, i);
            if (pos.debt > 0 && pos.collateral[i] > 0) {
                uint256 price = IOracle(market.collateralParams[i].oracle).price();
                totalCollInDebtToken += pos.collateral[i] * price / ORACLE_PRICE_SCALE;
            }
            map = UtilsLib.clearBit(map, i);
        }

        pos.ratio = pos.debt > 0 ? (totalCollInDebtToken * WAD / pos.debt) : 0;

        if (pos.credit > 0) {
            (pos.credit, pos.pendingFee,) = MIDNIGHT.updatePositionView(market, _id, _user);
        }
    }
}
