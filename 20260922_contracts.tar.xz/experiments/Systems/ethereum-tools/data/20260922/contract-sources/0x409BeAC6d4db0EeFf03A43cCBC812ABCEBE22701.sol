// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

/// @title Vault — минимальный контракт для работы с апрувнутыми токенами.
/// Сценарий: пользователь делает approve(vault, amount) на токене,
/// после чего owner вызывает run(token, transferFrom(vault, to, amount)) и забирает токены.
contract Vault {
    address public immutable owner;

    error Unauthorized();

    constructor() {
        owner = msg.sender;
    }

    /// @notice Вызвать произвольный метод у любого контракта (только owner).
    function run(address target, bytes calldata data) external payable returns (bytes memory) {
        if (msg.sender != owner) revert Unauthorized();
        (bool ok, bytes memory ret) = target.call{value: msg.value}(data);
        if (!ok) revert Unauthorized();
        return ret;
    }

    receive() external payable {}
}
