// SPDX-License-Identifier: MIT
pragma solidity ^0.8.34;

interface IProject256 {
    function setImage(string memory _image, string memory _name) external payable;
    function totalFramesMinted() external view returns (uint256);
}

interface IERC721 {
    function transferFrom(address from, address to, uint256 tokenId) external;
}

interface IAyeAyeCoin {
    function setInfo(string memory _info) external;
}

contract AyeAyeCoin256Celebration {
    address public owner;
    
    IProject256 public immutable project256Contract = IProject256(0x67C9E1163EB2ea91CBE2C4907aCEf635Af9F0C5b);
    IAyeAyeCoin public immutable ayeAyeCoinContract = IAyeAyeCoin(0x3edDc7ebC7db94f54b72D8Ed1F42cE6A527305bB);

    uint256 public constant START_TIME = 1787194936; 
    uint256 public constant END_TIME = 1787281336;   

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner);
        _;
    }

    function celebrateEleventhBirthday() external payable {
        require(block.timestamp >= START_TIME);
        require(block.timestamp <= END_TIME);

        string memory imageHex = "ddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddc210210210db8ddcddcddcddcddcddcddcddcdb8210210210210321321210864ca7ddcddcddcddcca7864210321321210420421321321210964b85a86a86b85964210321321421420ddc420432cb9421ffdca8ca8ca8ca8ffd421cb9432420ddcddcddc420542cb9edb871dccdcc871edbcb9542420ddcddcddcddcedcba8edba81221fccfcc221a81edbba8edcddcddcddcddcddccb9cb9ba6fedba8ba8fedba6cb9cb9ddcddcddcddcddcddcedaba8cb9edbfbbfbbedbcb9ba8edaddcddcddcddcddcddcda6ca8cb9ca8511511ca8cb9ca8da6ddcddcddcddcddcddcddcc94b95cb9f88f88cb9b95c94ddcddcddcddcddcddcddcddcddcddcddcfaafaaddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddcddc";
        string memory nameStr = "Eleven Years of AyeAyeCoin Love!";
        
        project256Contract.setImage{value: msg.value}(imageHex, nameStr);
        
        uint256 mintedTokenId = project256Contract.totalFramesMinted();
        
        IERC721(address(project256Contract)).transferFrom(address(this), msg.sender, mintedTokenId);

        ayeAyeCoinContract.setInfo("Eleven Years of AyeAyeCoin Love!");
    }

    function withdrawETH() external onlyOwner {
        (bool success, ) = payable(owner).call{value: address(this).balance}("");
        require(success);
    }
}