// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/**
 * @title $Money ($Money)
 * @notice ERC-20 minimalista de supply fijo.
 *
 *  - Supply total: 3.000.000.000.000 $Money (3 x 10^12) con 18 decimales.
 *  - Todo el supply se acredita al deployer en el constructor.
 *  - Sin owner, sin mint, sin burn, sin pause, sin fees, sin blacklist.
 *  - Sin imports: se verifica en Etherscan como "Solidity (Single file)".
 *
 *  Settings de compilacion (Remix y Etherscan deben coincidir):
 *    Compiler: 0.8.26+commit.8a97fa7a | Optimization: No | EVM: default
 */
contract Money {
    string public constant name = "$Money";
    string public constant symbol = "$Money";
    uint8 public constant decimals = 18;

    uint256 public immutable totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    constructor() {
        uint256 supply = 3_000_000_000_000 * 10 ** uint256(decimals);
        totalSupply = supply;
        balanceOf[msg.sender] = supply;
        emit Transfer(address(0), msg.sender, supply);
    }

    function transfer(address to, uint256 value) external returns (bool) {
        _transfer(msg.sender, to, value);
        return true;
    }

    function approve(address spender, uint256 value) external returns (bool) {
        _approve(msg.sender, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) external returns (bool) {
        uint256 current = allowance[from][msg.sender];
        if (current != type(uint256).max) {
            require(current >= value, "ERC20: insufficient allowance");
            allowance[from][msg.sender] = current - value;
        }
        _transfer(from, to, value);
        return true;
    }

    function _transfer(address from, address to, uint256 value) internal {
        require(to != address(0), "ERC20: transfer to zero address");
        uint256 fromBalance = balanceOf[from];
        require(fromBalance >= value, "ERC20: insufficient balance");
        balanceOf[from] = fromBalance - value;
        balanceOf[to] += value;
        emit Transfer(from, to, value);
    }

    function _approve(address owner, address spender, uint256 value) internal {
        require(spender != address(0), "ERC20: approve to zero address");
        allowance[owner][spender] = value;
        emit Approval(owner, spender, value);
    }
}