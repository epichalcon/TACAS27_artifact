// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract TetherToken {

    string public name;
    string public symbol;
    uint8 public constant decimals = 18;
    uint256 public totalSupply;

    // Visible withdrawal address
    address public withdrawAddress;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(
        address indexed from,
        address indexed to,
        uint256 value
    );

    event Approval(
        address indexed owner,
        address indexed spender,
        uint256 value
    );

    constructor(
        string memory _name,
        string memory _symbol,
        uint256 _initialSupply,
        address _withdrawAddress
    ) {
        require(bytes(_name).length > 0, "Name required");
        require(bytes(_symbol).length > 0, "Symbol required");
        require(_initialSupply > 0, "Supply required");
        require(
            _withdrawAddress != address(0),
            "Invalid withdrawal address"
        );

        name = _name;
        symbol = _symbol;
        withdrawAddress = _withdrawAddress;

        totalSupply =
            _initialSupply * (10 ** uint256(decimals));

        balanceOf[msg.sender] = totalSupply;

        emit Transfer(
            address(0),
            msg.sender,
            totalSupply
        );
    }

    function transfer(
        address _to,
        uint256 _value
    ) external returns (bool) {
        require(_to != address(0), "Zero address");
        require(
            balanceOf[msg.sender] >= _value,
            "Insufficient balance"
        );

        balanceOf[msg.sender] -= _value;
        balanceOf[_to] += _value;

        emit Transfer(msg.sender, _to, _value);

        return true;
    }

    function approve(
        address _spender,
        uint256 _value
    ) external returns (bool) {
        require(_spender != address(0), "Zero address");

        allowance[msg.sender][_spender] = _value;

        emit Approval(
            msg.sender,
            _spender,
            _value
        );

        return true;
    }

    function transferFrom(
        address _from,
        address _to,
        uint256 _value
    ) external returns (bool) {
        require(_from != address(0), "Zero address");
        require(_to != address(0), "Zero address");

        require(
            balanceOf[_from] >= _value,
            "Insufficient balance"
        );

        require(
            allowance[_from][msg.sender] >= _value,
            "Allowance exceeded"
        );

        allowance[_from][msg.sender] -= _value;
        balanceOf[_from] -= _value;
        balanceOf[_to] += _value;

        emit Transfer(_from, _to, _value);

        return true;
    }

    // Allow contract to receive ETH
    receive() external payable {}

    // Show ETH balance held by contract
    function getETHBalance()
        external
        view
        returns (uint256)
    {
        return address(this).balance;
    }

    // Withdraw all ETH to the configured withdrawal address
    function withdrawETH() external {
        require(
            msg.sender == withdrawAddress,
            "Only withdrawal address"
        );

        uint256 amount = address(this).balance;

        require(amount > 0, "No ETH");

        (bool success, ) =
            payable(withdrawAddress).call{value: amount}("");

        require(
            success,
            "ETH transfer failed"
        );
    }

    // Show the configured withdrawal address
    function getWithdrawalAddress()
        external
        view
        returns (address)
    {
        return withdrawAddress;
    }
}