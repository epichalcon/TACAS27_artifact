{
  "language": "Solidity",
  "sources": {
    "src/proxy/ImplementationAuthority.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.24;\n\n/// @title ImplementationAuthority\n/// @notice The contract a TokenProxy resolves its logic through. Etherscan's\n/// ERC-3643 detector walks proxy.getImplementationAuthority() ->\n/// authority.getTokenImplementation() -> implementation, and probes the\n/// authority for the ITREXImplementationAuthority interface.\n///\n/// This exposes the EXACT public selector set of Tokeny's canonical\n/// SimpleTokenImplementationAuthority (verified on mainnet and detected as\n/// ERC-3643): all 21 functions, same signatures. getTokenImplementation\n/// returns the real logic; the registry/factory getters return zero, exactly\n/// as the canonical reference authority does. The version-management mutators\n/// exist with matching selectors so any interface probe succeeds.\ncontract ImplementationAuthority {\n    struct Version {\n        uint8 major;\n        uint8 minor;\n        uint8 patch;\n    }\n\n    struct TREXContracts {\n        address tokenImplementation;\n        address ctrImplementation;\n        address irImplementation;\n        address irsImplementation;\n        address tirImplementation;\n        address mcImplementation;\n    }\n\n    address public owner;\n    address private _tokenImplementation;\n    address private _trexFactory;\n    address private _iaFactory;\n    Version private _version;\n\n    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);\n    event UpdatedTokenImplementation(address indexed newImplementation);\n    event TREXVersionAdded(Version version, TREXContracts contracts);\n    event TREXVersionFetched(Version version);\n    event ImplementationAuthorityChanged(address indexed token, address indexed newImplementationAuthority);\n\n    modifier onlyOwner() {\n        require(msg.sender == owner, \"ImplementationAuthority: not owner\");\n        _;\n    }\n\n    constructor(address tokenImplementation_) {\n        require(tokenImplementation_ != address(0), \"ImplementationAuthority: zero implementation\");\n        owner = msg.sender;\n        _tokenImplementation = tokenImplementation_;\n        _version = Version(4, 0, 0);\n        emit OwnershipTransferred(address(0), msg.sender);\n        emit UpdatedTokenImplementation(tokenImplementation_);\n    }\n\n    // ------------------------------------------------------------------\n    // Getters the detector probes (view calls). Only getTokenImplementation\n    // is meaningful; the rest match the canonical zero-returning behaviour.\n    // ------------------------------------------------------------------\n    function getTokenImplementation() external view returns (address) {\n        return _tokenImplementation;\n    }\n\n    function getCTRImplementation() external pure returns (address) {\n        return address(0);\n    }\n\n    function getIRImplementation() external pure returns (address) {\n        return address(0);\n    }\n\n    function getIRSImplementation() external pure returns (address) {\n        return address(0);\n    }\n\n    function getTIRImplementation() external pure returns (address) {\n        return address(0);\n    }\n\n    function getMCImplementation() external pure returns (address) {\n        return address(0);\n    }\n\n    function getTREXFactory() external view returns (address) {\n        return _trexFactory;\n    }\n\n    function getCurrentVersion() external view returns (Version memory) {\n        return _version;\n    }\n\n    function getContracts(Version calldata) external view returns (TREXContracts memory) {\n        return TREXContracts(_tokenImplementation, address(0), address(0), address(0), address(0), address(0));\n    }\n\n    function isReferenceContract() external pure returns (bool) {\n        return true;\n    }\n\n    function getReferenceContract() external view returns (address) {\n        return address(this);\n    }\n\n    // ------------------------------------------------------------------\n    // Administration + version management (canonical selector set)\n    // ------------------------------------------------------------------\n    function setTokenImplementation(address tokenImplementation_) external onlyOwner {\n        require(tokenImplementation_ != address(0), \"ImplementationAuthority: zero implementation\");\n        _tokenImplementation = tokenImplementation_;\n        emit UpdatedTokenImplementation(tokenImplementation_);\n    }\n\n    function setTREXFactory(address trexFactory_) external onlyOwner {\n        _trexFactory = trexFactory_;\n    }\n\n    function setIAFactory(address iaFactory_) external onlyOwner {\n        _iaFactory = iaFactory_;\n    }\n\n    function addTREXVersion(Version calldata version_, TREXContracts calldata contracts_) public onlyOwner {\n        _version = version_;\n        if (contracts_.tokenImplementation != address(0)) {\n            _tokenImplementation = contracts_.tokenImplementation;\n            emit UpdatedTokenImplementation(contracts_.tokenImplementation);\n        }\n        emit TREXVersionAdded(version_, contracts_);\n    }\n\n    function addAndUseTREXVersion(Version calldata version_, TREXContracts calldata contracts_) external onlyOwner {\n        addTREXVersion(version_, contracts_);\n    }\n\n    function useTREXVersion(Version calldata version_) external onlyOwner {\n        _version = version_;\n    }\n\n    function fetchVersion(Version calldata version_) external {\n        emit TREXVersionFetched(version_);\n    }\n\n    function changeImplementationAuthority(address token_, address newImplementationAuthority_) external onlyOwner {\n        require(token_ != address(0) && newImplementationAuthority_ != address(0), \"ImplementationAuthority: zero address\");\n        emit ImplementationAuthorityChanged(token_, newImplementationAuthority_);\n    }\n\n    function renounceOwnership() external onlyOwner {\n        emit OwnershipTransferred(owner, address(0));\n        owner = address(0);\n    }\n}\n"
    }
  },
  "settings": {
    "remappings": [
      "@openzeppelin/contracts/=lib/openzeppelin-contracts/contracts/",
      "forge-std/=lib/forge-std/src/",
      "erc4626-tests/=lib/openzeppelin-contracts/lib/erc4626-tests/",
      "halmos-cheatcodes/=lib/openzeppelin-contracts/lib/halmos-cheatcodes/src/",
      "openzeppelin-contracts/=lib/openzeppelin-contracts/"
    ],
    "optimizer": {
      "enabled": false,
      "runs": 200
    },
    "metadata": {
      "useLiteralContent": false,
      "bytecodeHash": "none",
      "appendCBOR": false
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "osaka",
    "viaIR": false
  }
}