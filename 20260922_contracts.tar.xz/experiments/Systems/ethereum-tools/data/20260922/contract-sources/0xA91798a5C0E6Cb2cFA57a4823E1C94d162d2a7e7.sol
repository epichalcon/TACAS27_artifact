// SPDX-License-Identifier: Unlicensed
pragma solidity ^0.8.13;

interface IERC20 {
    function totalSupply() external view returns (uint);
    function decimals() external view returns (uint8);
    function symbol() external view returns (string memory);
    function name() external view returns (string memory);
    function getOwner() external view returns (address);
    function balanceOf(address account) external view returns (uint);
    function transfer(address to, uint amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint);
    function approve(address spender, uint amount) external returns (bool);
    function transferFrom(address sender, address to, uint amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint value);
    event Approval(address indexed owner, address indexed spender, uint value);
}

interface IDEXFactory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
    function getPair(address tokenA, address tokenB) external view returns (address pair);
}

interface IDEXRouter {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline
    ) external;
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin, address[] calldata path, address to, uint deadline
    ) external payable;
    function addLiquidity(
        address tokenA, address tokenB,
        uint amountADesired, uint amountBDesired,
        uint amountAMin, uint amountBMin,
        address to, uint deadline
    ) external returns (uint amountA, uint amountB, uint liquidity);
}

interface INOCOUNTRYFORSHITCOINSREFLECTIONS {
    function setDistributionCriteria(uint minPeriod, uint minDistribution) external;
    function setShare(address shareholder, uint amount) external;
    function deposit() external payable;
    function process(uint gas) external;
    function withdraw(address shareholder) external;
    function removeStuckDividends() external;
    function updateActivity(address shareholder) external;
    function getUnpaidEarnings(address shareholder) external view returns (uint);
    function setRewardBurnPercent(uint newPct) external;
    function setDividendBurnPercent(uint newPct) external;
}

contract Auth {
    address public owner;
    modifier onlyOwner() { require(msg.sender == owner, "Not owner"); _; }
    constructor(address _owner) { owner = _owner; }
    function transferOwnership(address newOwner) external onlyOwner { owner = newOwner; }
}

contract NOCOUNTRYFORSHITCOINSREFLECTIONS is INOCOUNTRYFORSHITCOINSREFLECTIONS {
    address private immutable token;
    address private constant REWARD_TOKEN = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    address private constant DEV = 0x837360fE7954cD35dEC385639667b887e4C64C6e;
    IDEXRouter private immutable router;

    struct Share { uint amount; uint totalExcluded; uint totalRealised; }
    address[] private shareholders;
    mapping(address => uint) private shareholderIdx;
    mapping(address => uint) private claims;
    mapping(address => Share) public shares;

    uint public totalShares;
    uint public totalDividends;
    uint public totalDistributed;
    uint public divPerShare;
    uint private constant ACCURACY = 10**36;
    uint public minPeriod = 30 minutes;
    uint public minDistribution;
    uint public currentIdx;
    uint public rewardBurnPct = 20;
    uint public divBurnPct = 5;

    modifier onlyToken() { require(msg.sender == token, "Only token"); _; }

    constructor(address token_) {
        token = token_;
        router = IDEXRouter(0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D);
    }

    receive() external payable { deposit(); }

    function removeStuckDividends() external onlyToken {
        uint bal = IERC20(REWARD_TOKEN).balanceOf(address(this));
        if (bal > 0) IERC20(REWARD_TOKEN).transfer(DEV, bal);
    }

    function setDistributionCriteria(uint newMinPeriod, uint newMinDist) external override onlyToken {
        minPeriod = newMinPeriod;
        minDistribution = newMinDist;
    }

    function setRewardBurnPercent(uint newPct) external override onlyToken {
        require(newPct <= 50, "Max 50%");
        rewardBurnPct = newPct;
    }

    function setDividendBurnPercent(uint newPct) external override onlyToken {
        require(newPct <= 20, "Max 20%");
        divBurnPct = newPct;
    }

    function updateActivity(address) external override onlyToken {}

    function setShare(address shareholder, uint amount) external override onlyToken {
        if (shares[shareholder].amount > 0) distributeDividend(shareholder);

        if (amount > 0 && shares[shareholder].amount == 0) {
            shareholderIdx[shareholder] = shareholders.length;
            shareholders.push(shareholder);
        } else if (amount == 0 && shares[shareholder].amount > 0) {
            uint lastIdx = shareholders.length - 1;
            uint idx = shareholderIdx[shareholder];
            shareholders[idx] = shareholders[lastIdx];
            shareholderIdx[shareholders[lastIdx]] = idx;
            shareholders.pop();
        }

        totalShares = totalShares + amount - shares[shareholder].amount;
        shares[shareholder].amount = amount;
        shares[shareholder].totalExcluded = (amount * divPerShare) / ACCURACY;
    }

    function deposit() public payable override {
        if (msg.value == 0) return;
        uint balBefore = IERC20(REWARD_TOKEN).balanceOf(address(this));
        address[] memory path = new address[](2);
        path[0] = router.WETH();
        path[1] = REWARD_TOKEN;
        try router.swapExactETHForTokensSupportingFeeOnTransferTokens{value: msg.value}(
            0, path, address(this), block.timestamp
        ) {} catch { return; }
        uint amount = IERC20(REWARD_TOKEN).balanceOf(address(this)) - balBefore;
        if (amount == 0) return;

        uint burnAmt = (amount * rewardBurnPct) / 100;
        if (burnAmt > 0) IERC20(REWARD_TOKEN).transfer(DEAD, burnAmt);

        uint distAmt = amount - burnAmt;
        totalDividends += distAmt;
        if (totalShares > 0) divPerShare += (ACCURACY * distAmt) / totalShares;
    }

    function process(uint gas) external override {
        uint count = shareholders.length;
        if (count == 0) return;

        uint gasUsed;
        uint gasLeft = gasleft();
        uint maxIter = count > 50 ? 50 : count;

        for (uint i = 0; gasUsed < gas && i < maxIter; i++) {
            if (currentIdx >= count) currentIdx = 0;
            if (shouldDistribute(shareholders[currentIdx])) {
                distributeDividend(shareholders[currentIdx]);
            }
            gasUsed += gasLeft - gasleft();
            gasLeft = gasleft();
            currentIdx++;
        }
    }

    function shouldDistribute(address shareholder) public view returns (bool) {
        return claims[shareholder] + minPeriod < block.timestamp
            && getUnpaidEarnings(shareholder) > minDistribution;
    }

    function getUnpaidEarnings(address shareholder) public view override returns (uint) {
        if (shares[shareholder].amount == 0) return 0;
        uint totalDiv = (shares[shareholder].amount * divPerShare) / ACCURACY;
        return totalDiv > shares[shareholder].totalExcluded
            ? totalDiv - shares[shareholder].totalExcluded
            : 0;
    }

    function distributeDividend(address shareholder) internal {
        if (shares[shareholder].amount == 0) return;
        uint amount = getUnpaidEarnings(shareholder);
        if (amount > 0) {
            uint burnAmt = (amount * divBurnPct) / 100;
            uint transferAmt = amount - burnAmt;
            totalDistributed += transferAmt;

            if (burnAmt > 0) IERC20(REWARD_TOKEN).transfer(DEAD, burnAmt);
            if (transferAmt > 0) IERC20(REWARD_TOKEN).transfer(shareholder, transferAmt);

            claims[shareholder] = block.timestamp;
            shares[shareholder].totalRealised += transferAmt;
            shares[shareholder].totalExcluded = (shares[shareholder].amount * divPerShare) / ACCURACY;
        }
    }

    function withdraw(address shareholder) external override onlyToken {
        distributeDividend(shareholder);
    }
}

contract NOCOUNTRYFORSHITCOINS is IERC20, Auth {
    address private constant SLACK        = 0xfEF4C6B56e011a684dC2054aFd576d83817C2620;
    address private constant USDC         = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;
    address private constant DEAD         = 0x000000000000000000000000000000000000dEaD;
    address private constant ZERO         = address(0);

    string private constant _name   = "NOCOUNTRYFORSHITCOINS";
    string private constant _symbol = "NOCOUNTRYFORSHITCOINS";
    uint8  private constant _decimals = 18;
    uint   private _totalSupply = 100_000_000_000 * (10**18);

    mapping(address => uint) private _balances;
    mapping(address => mapping(address => uint)) private _allowances;
    mapping(address => bool) public isFeeExempt;
    mapping(address => bool) public isNOCOUNTRYFORSHITCOINSReflectionsExempt;

    uint public buyFee  = 8;
    uint public sellFee = 8;
    uint public p2pFee  = 2;

    uint public toSlackUsdcLp   = 25;
    uint public toReflections   = 25;
    uint public toUsdcBurn       = 15;
    uint public toNativeBurn    = 10;
    uint public toTreasury      = 15;
    uint public toMarketing     = 10;

    IDEXRouter public immutable router;
    address public immutable pair;
    address public immutable slackUsdcPair;
    address public immutable WETH;

    address public constant devWallet = 0x837360fE7954cD35dEC385639667b887e4C64C6e;
    address payable public treasuryWallet  = payable(0x837360fE7954cD35dEC385639667b887e4C64C6e);
    address payable public marketingWallet = payable(0x837360fE7954cD35dEC385639667b887e4C64C6e);

    bool private inSwap;
    bool public swapEnabled = true;
    bool public tradingOpen;
    INOCOUNTRYFORSHITCOINSREFLECTIONS public immutable reflections;

    uint public swapThreshold = 500_000_000 * (10**18);

    uint private constant _NOT_ENTERED = 1;
    uint private constant _ENTERED = 2;
    uint private _status = _NOT_ENTERED;

    modifier nonReentrant() {
        require(_status != _ENTERED, "ReentrancyGuard: reentrant call");
        _status = _ENTERED;
        _;
        _status = _NOT_ENTERED;
    }

    constructor() Auth(0x837360fE7954cD35dEC385639667b887e4C64C6e) {
        router = IDEXRouter(0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D);
        WETH   = router.WETH();

        pair = IDEXFactory(router.factory()).createPair(WETH, address(this));

        address _slackUsdc = IDEXFactory(router.factory()).getPair(SLACK, USDC);
        if (_slackUsdc == address(0)) {
            _slackUsdc = IDEXFactory(router.factory()).createPair(SLACK, USDC);
        }
        slackUsdcPair = _slackUsdc;

        reflections = INOCOUNTRYFORSHITCOINSREFLECTIONS(address(new NOCOUNTRYFORSHITCOINSREFLECTIONS(address(this))));

        _allowances[address(this)][address(router)] = type(uint).max;

        isFeeExempt[owner]           = true;
        isFeeExempt[devWallet]       = true;
        isFeeExempt[marketingWallet] = true;
        isFeeExempt[treasuryWallet]  = true;
        isFeeExempt[address(this)]   = true;
        isFeeExempt[DEAD]            = true;

        isNOCOUNTRYFORSHITCOINSReflectionsExempt[pair]          = true;
        isNOCOUNTRYFORSHITCOINSReflectionsExempt[address(this)] = true;
        isNOCOUNTRYFORSHITCOINSReflectionsExempt[DEAD]          = true;
        isNOCOUNTRYFORSHITCOINSReflectionsExempt[address(reflections)] = true;

        address[10] memory exemptWallets = [
            0xFb524085426515d6cCCbA000A68749e5D7512004,
            0xfADfea0ed7eE88AF64630bA39b69BE3E0e1c2bf4,
            0x96b252721dF21dFfC48A0e95Ab2d4f96CC547D20,
            0x0472246D9687e932f9ccfDD751702A26b7184cfe,
            0xB17e11bFCa87D459e9a81c1954629B04455c935E,
            0x837360fE7954cD35dEC385639667b887e4C64C6e,
            0x65c9247F4485fA591F0C2eeC4251546e93BCb3AD,
            0x3085847f2ef18940df2bF6c309b7dAca8eC9A59a,
            0xA6eeA5B48A62B77EC5c1926e9F80826FFf35240c,
            0x25D0C2A6b134d88c02A2671f0adF008Dcf5ddfEB
        ];

        for (uint i = 0; i < exemptWallets.length; i++) {
            isFeeExempt[exemptWallets[i]] = true;
            isNOCOUNTRYFORSHITCOINSReflectionsExempt[exemptWallets[i]] = true;
        }

        _balances[owner] = _totalSupply;
        emit Transfer(ZERO, owner, _totalSupply);
    }

    receive() external payable {}

    function totalSupply() external view override returns (uint) { return _totalSupply; }
    function decimals() external pure override returns (uint8) { return _decimals; }
    function symbol() external pure override returns (string memory) { return _symbol; }
    function name() external pure override returns (string memory) { return _name; }
    function getOwner() external view override returns (address) { return owner; }
    function balanceOf(address account) public view override returns (uint) { return _balances[account]; }
    function allowance(address ownerAddr, address spender) external view override returns (uint) {
        return _allowances[ownerAddr][spender];
    }

    function approve(address spender, uint amount) public override returns (bool) {
        _allowances[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transfer(address to, uint amount) external override returns (bool) {
        return _transfer(msg.sender, to, amount);
    }

    function transferFrom(address sender, address to, uint amount) external override returns (bool) {
        uint currentAllowance = _allowances[sender][msg.sender];
        if (currentAllowance != type(uint).max) {
            require(currentAllowance >= amount, "Insufficient allowance");
            unchecked { _allowances[sender][msg.sender] -= amount; }
        }
        return _transfer(sender, to, amount);
    }

    function _transfer(address sender, address to, uint amount) internal returns (bool) {
        if (sender != owner && to != owner) require(tradingOpen, "Trading not open");

        if (inSwap) {
            _balances[sender] -= amount;
            _balances[to] += amount;
            emit Transfer(sender, to, amount);
            return true;
        }

        if (_balances[address(this)] >= swapThreshold && !inSwap && swapEnabled && sender != pair) {
            inSwap = true;
            swapBack();
            inSwap = false;
        }

        _balances[sender] -= amount;
        uint finalAmount = !isFeeExempt[sender] && !isFeeExempt[to] ? takeFee(sender, to, amount) : amount;
        _balances[to] += finalAmount;

        if (!isNOCOUNTRYFORSHITCOINSReflectionsExempt[sender]) {
            reflections.updateActivity(sender);
            reflections.setShare(sender, _balances[sender]);
        }
        if (!isNOCOUNTRYFORSHITCOINSReflectionsExempt[to]) {
            reflections.updateActivity(to);
            reflections.setShare(to, _balances[to]);
        }

        emit Transfer(sender, to, finalAmount);
        return true;
    }

    function takeFee(address sender, address to, uint amount) internal returns (uint) {
        uint fee = to == pair ? sellFee : (sender == pair ? buyFee : p2pFee);
        uint feeAmount = (amount * fee) / 100;
        _balances[address(this)] += feeAmount;
        emit Transfer(sender, address(this), feeAmount);
        return amount - feeAmount;
    }

    function swapTokensForEth(uint tokenAmount) private {
        if (tokenAmount == 0) return;
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = WETH;
        try router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            tokenAmount, 0, path, address(this), block.timestamp
        ) {} catch {}
    }

    function addSlackUsdcLp(uint ethAmount) private {
        if (ethAmount < 0.001 ether) return;

        uint half = ethAmount / 2;
        if (half == 0) return;

        uint usdcBefore = IERC20(USDC).balanceOf(address(this));
        address[] memory path = new address[](2);
        path[0] = WETH;
        path[1] = USDC;
        try router.swapExactETHForTokensSupportingFeeOnTransferTokens{value: half}(
            0, path, address(this), block.timestamp
        ) {} catch { return; }
        uint usdcAmount = IERC20(USDC).balanceOf(address(this)) - usdcBefore;

        uint slackBefore = IERC20(SLACK).balanceOf(address(this));
        path[1] = SLACK;
        try router.swapExactETHForTokensSupportingFeeOnTransferTokens{value: half}(
            0, path, address(this), block.timestamp
        ) {} catch { return; }
        uint slackAmount = IERC20(SLACK).balanceOf(address(this)) - slackBefore;

        if (usdcAmount == 0 || slackAmount == 0) return;

        IERC20(USDC).approve(address(router), usdcAmount);
        IERC20(SLACK).approve(address(router), slackAmount);

        try router.addLiquidity(
            SLACK,
            USDC,
            slackAmount,
            usdcAmount,
            0,
            0,
            address(this),
            block.timestamp
        ) returns (uint, uint, uint liquidity) {
            if (liquidity > 0) {
                uint halfLp = liquidity / 2;
                IERC20(slackUsdcPair).transfer(devWallet, halfLp);
                IERC20(slackUsdcPair).transfer(DEAD, liquidity - halfLp);
            }
        } catch {}
    }

    function swapBack() internal nonReentrant {
        uint bal = _balances[address(this)];
        if (bal == 0) return;

        swapTokensForEth(bal);
        uint totalEth = address(this).balance;
        if (totalEth == 0) return;

        uint ethForLp          = (totalEth * toSlackUsdcLp) / 100;
        uint ethForReflections = (totalEth * toReflections) / 100;
        uint ethForUsdcBurn    = (totalEth * toUsdcBurn) / 100;
        uint ethForNativeBurn  = (totalEth * toNativeBurn) / 100;
        uint ethForTreasury    = (totalEth * toTreasury) / 100;
        uint ethForMarketing   = totalEth - ethForLp - ethForReflections - ethForUsdcBurn - ethForNativeBurn - ethForTreasury;

        if (ethForLp > 0) {
            try this.addSlackUsdcLpExternal(ethForLp) {} catch {}
        }

        if (ethForReflections > 0) {
            try reflections.deposit{value: ethForReflections}() {} catch {}
        }

        if (ethForUsdcBurn > 0) {
            address[] memory path = new address[](2);
            path[0] = WETH;
            path[1] = USDC;
            try router.swapExactETHForTokensSupportingFeeOnTransferTokens{value: ethForUsdcBurn}(
                0, path, DEAD, block.timestamp
            ) {} catch {}
        }

        if (ethForNativeBurn > 0) {
            address[] memory path = new address[](2);
            path[0] = WETH;
            path[1] = address(this);
            try router.swapExactETHForTokensSupportingFeeOnTransferTokens{value: ethForNativeBurn}(
                0, path, DEAD, block.timestamp
            ) {} catch {}
        }

        if (ethForMarketing > 0) {
            (bool successM, ) = marketingWallet.call{value: ethForMarketing}("");
            successM;
        }
        if (ethForTreasury > 0) {
            (bool successT, ) = treasuryWallet.call{value: ethForTreasury}("");
            successT;
        }

        uint remaining = address(this).balance;
        if (remaining > 0) {
            (bool successR, ) = marketingWallet.call{value: remaining}("");
            successR;
        }
    }

    function addSlackUsdcLpExternal(uint ethAmount) external {
        require(msg.sender == address(this), "Only self");
        addSlackUsdcLp(ethAmount);
    }

    function enableTrading() external onlyOwner { tradingOpen = true; }

    function changeTotalFees(uint newBuyFee, uint newSellFee) external onlyOwner {
        require(newBuyFee <= 25 && newSellFee <= 25, "Max 25%");
        buyFee = newBuyFee;
        sellFee = newSellFee;
    }

    function changeP2PFee(uint newP2PFee) external onlyOwner {
        require(newP2PFee <= 25, "Max 25%");
        p2pFee = newP2PFee;
    }

    function changeFeeAllocation(
        uint _toSlackUsdcLp,
        uint _toReflections,
        uint _toUsdcBurn,
        uint _toNativeBurn,
        uint _toTreasury,
        uint _toMarketing
    ) external onlyOwner {
        require(
            _toSlackUsdcLp + _toReflections + _toUsdcBurn + _toNativeBurn + _toTreasury + _toMarketing == 100,
            "Must equal 100%"
        );
        toSlackUsdcLp   = _toSlackUsdcLp;
        toReflections   = _toReflections;
        toUsdcBurn       = _toUsdcBurn;
        toNativeBurn    = _toNativeBurn;
        toTreasury      = _toTreasury;
        toMarketing     = _toMarketing;
    }

    function changeIsFeeExempt(address holder, bool exempt) external onlyOwner {
        isFeeExempt[holder] = exempt;
    }

    function setIsNOCOUNTRYFORSHITCOINSReflectionsExempt(address holder, bool exempt) external onlyOwner {
        require(holder != address(this) && holder != pair, "Cannot exempt core");
        isNOCOUNTRYFORSHITCOINSReflectionsExempt[holder] = exempt;
        reflections.setShare(holder, exempt ? 0 : _balances[holder]);
    }

    function setMarketingWallet(address payable newWallet) external onlyOwner { marketingWallet = newWallet; }
    function setTreasuryWallet(address payable newWallet) external onlyOwner { treasuryWallet = newWallet; }

    function changeSwapBackSettings(bool enable, uint newLimit) external onlyOwner {
        swapEnabled = enable;
        swapThreshold = newLimit;
    }

    function setReflectionDistributionCriteria(uint minPeriod, uint minDist) external onlyOwner {
        reflections.setDistributionCriteria(minPeriod, minDist);
    }

    function setRewardBurnPercent(uint newPct) external onlyOwner {
        reflections.setRewardBurnPercent(newPct);
    }

    function setDividendBurnPercent(uint newPct) external onlyOwner {
        reflections.setDividendBurnPercent(newPct);
    }

    function getCirculatingSupply() public view returns (uint) {
        return _totalSupply - _balances[DEAD] - _balances[ZERO];
    }

    function manualSwapBack() external onlyOwner {
        inSwap = true;
        swapBack();
        inSwap = false;
    }

    function clearStuckEth() external onlyOwner {
        (bool success, ) = payable(devWallet).call{value: address(this).balance}("");
        require(success, "ETH transfer failed");
    }

    function rescueToken(address tokenAddress, uint amount) external onlyOwner {
        require(tokenAddress != address(this), "Cannot rescue own token");
        IERC20(tokenAddress).transfer(devWallet, amount);
    }

    function manualProcessGas(uint gas) external onlyOwner { reflections.process(gas); }

    function checkPendingReflections(address shareholder) external view returns (uint) {
        return reflections.getUnpaidEarnings(shareholder);
    }

    function withdraw() external { reflections.withdraw(msg.sender); }

    function removeStuckDividends() external onlyOwner { reflections.removeStuckDividends(); }
}