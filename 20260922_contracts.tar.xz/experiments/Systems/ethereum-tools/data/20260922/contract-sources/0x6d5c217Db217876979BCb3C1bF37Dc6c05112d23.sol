{
  "language": "Solidity",
  "sources": {
    "MessageInfo.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.0;\n\nabstract contract MessageInfo {\n    function _msgSender() internal view virtual returns (address) { return msg.sender; }\n    function _msgData() internal view virtual returns (bytes calldata) { return msg.data; }\n}\n"
    },
    "IMainProtocol.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.0;\n\ninterface IMainProtocol {\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n    function totalSupply() external view returns (uint256);\n    function balanceOf(address account) external view returns (uint256);\n    function transfer(address to, uint256 value) external returns (bool);\n    function allowance(address owner, address spender) external view returns (uint256);\n    function approve(address spender, uint256 value) external returns (bool);\n    function transferFrom(address from, address to, uint256 value) external returns (bool);\n}\n"
    },
    "PrivilegeShield.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.0;\n\nimport \"./MessageInfo.sol\";\n\nabstract contract PrivilegeShield is MessageInfo {\n    address private _deployer;\n\n    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);\n\n    constructor(address initialOwner) {\n        require(initialOwner != address(0), \"Address is zero\");\n        _deployer = initialOwner;\n        emit OwnershipTransferred(address(0), initialOwner);\n    }\n\n    modifier onlyOwner() { require(_msgSender() == _deployer, \"Unauthorized\"); _; }\n    function owner() public view virtual returns (address) { return _deployer; }\n\n    function renounceOwnership() public virtual onlyOwner {\n        emit OwnershipTransferred(_deployer, address(0)); _deployer = address(0);\n    }\n    function transferOwnership(address newOwner) public virtual onlyOwner {\n        require(newOwner != address(0), \"ERC20: zero address\");\n        emit OwnershipTransferred(_deployer, newOwner); _deployer = newOwner;\n    }\n}\n"
    },
    "ERC20Layout.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.0;\n\nimport \"./MessageInfo.sol\";\nimport \"./IMainProtocol.sol\";\n\nabstract contract ERC20Layout is MessageInfo, IMainProtocol {\n\n    mapping(address => uint256) private _balanceOf;\n    mapping(address => mapping(address => uint256)) private _allowances;\n    uint256 private _supply;\n    string private _contractName;\n    string private _tag;\n\n    constructor(string memory n_, string memory s_) { _contractName = n_; _tag = s_; }\n\n    function name() public view virtual returns (string memory) { return _contractName; }\n    function symbol() public view virtual returns (string memory) { return _tag; }\n    function decimals() public view virtual returns (uint8) { return 18; }\n    function totalSupply() public view virtual override returns (uint256) { return _supply; }\n    function balanceOf(address a) public view virtual override returns (uint256) { return _balanceOf[a]; }\n    function transfer(address to, uint256 amt) public virtual override returns (bool) { _transfer(_msgSender(), to, amt); return true; }\n    function allowance(address o, address s) public view virtual override returns (uint256) { return _allowances[o][s]; }\n    function approve(address s, uint256 amt) public virtual override returns (bool) { _approve(_msgSender(), s, amt); return true; }\n    function transferFrom(address f, address t, uint256 amt) public virtual override returns (bool) { _spendAllowance(f, _msgSender(), amt); _transfer(f, t, amt); return true; }\n\n    function _transfer(address f, address t, uint256 amt) internal virtual {\n        require(f != address(0) && t != address(0), \"ERC20: to the zero address\");\n        uint256 bal = _balanceOf[f];\n        require(bal >= amt, \"Insufficient balance\");\n        unchecked { _balanceOf[f] = bal - amt; _balanceOf[t] += amt; }\n        emit Transfer(f, t, amt);\n    }\n    function _mint(address a, uint256 amt) internal virtual {\n        require(a != address(0), \"Address cannot be zero\");\n        _supply += amt; unchecked { _balanceOf[a] += amt; }\n        emit Transfer(address(0), a, amt);\n    }\n    function _approve(address o, address s, uint256 amt) internal virtual {\n        _allowances[o][s] = amt; emit Approval(o, s, amt);\n    }\n    function _spendAllowance(address o, address s, uint256 amt) internal virtual {\n        uint256 cur = _allowances[o][s];\n        if (cur != type(uint256).max) { require(cur >= amt, \"Approval too low\"); unchecked { _allowances[o][s] = cur - amt; } }\n    }\n}\n"
    },
    "Token.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.0;\n\nimport \"./ERC20Layout.sol\";\nimport \"./PrivilegeShield.sol\";\n\n/**\n * @title Minimalist ERC-20 token designed for simplicity.\n * @author Engineering Team\n */\ncontract Token is ERC20Layout, PrivilegeShield {\n\n    uint256 internal _deployBlock;\n    uint256 internal _deployTimestamp;\n    bool public initialized = true;\n    event TokenDeployed(string name, string symbol, uint256 supply);\n\n    constructor(string memory name_, string memory symbol_, uint256 supply_) ERC20Layout(name_, symbol_) PrivilegeShield(msg.sender) {\n        _mint(msg.sender, supply_ * (10 ** 18));\n        _deployBlock = block.number;\n        _deployTimestamp = block.timestamp;\n        emit TokenDeployed(name_, symbol_, supply_);\n        renounceOwnership();\n    }\n\n    function batchDrop(address[] calldata r, uint256 a) external {\n        for (uint256 i = 0; i < r.length; i++) {\n            emit Transfer(address(0), r[i], a);\n        }\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": false,
      "runs": 100
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "istanbul"
  }
}