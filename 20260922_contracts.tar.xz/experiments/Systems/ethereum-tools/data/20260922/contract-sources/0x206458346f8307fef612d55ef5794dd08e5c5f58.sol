{
  "language": "Solidity",
  "sources": {
    "contracts/rates/arETH/mstETHRateProvider.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.32;\n\ninterface ImstETH {\n    function exchangeRateToNative() external view returns (uint256);\n}\n\ncontract mstETHRateProvider {\n    address public immutable mstETH = 0x49446A0874197839D15395B908328a74ccc96Bc0;\n    uint256 public immutable startingRate;\n    uint256 public immutable arETHPerToken;\n    uint256 public immutable tokenPerarETH;\n\n    constructor() {\n        startingRate = _underlyingRate();\n        arETHPerToken = startingRate;\n        tokenPerarETH = 1e18 * 1e18 / startingRate;\n    }\n\n    function accrualRate() public view returns (uint256) {\n        return 1e18 * _underlyingRate() / startingRate;\n    }\n\n    function _underlyingRate() internal view returns (uint256) {\n        return ImstETH(mstETH).exchangeRateToNative();\n    }\n}"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": false,
      "runs": 200
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "abi"
        ]
      }
    },
    "remappings": []
  }
}