{
  "language": "Solidity",
  "sources": {
    "BitreumOtc.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.37;\n\nimport {ReentrancyGuard} from \"./vendor/ReentrancyGuard.sol\";\nimport {IERC20} from \"./interfaces/IERC20.sol\";\n\n/// @title BitreumOtc\n/// @notice Fixed-rate ETH → $BTE desk. 100,000,000 $BTE hard cap.\n///         1 ETH = 500,000 $BTE. Min 0.1 ETH per buy. Max 5 ETH lifetime per wallet.\n/// @dev No owner, no pause, no upgrade. Fund by transferring $BTE in.\n///      ETH is forwarded to the treasury EOA in the same transaction as the $BTE send.\n///      Never send ETH to the treasury. Buy through this contract.\ncontract BitreumOtc is ReentrancyGuard {\n    IERC20 public immutable bte;\n    address payable public immutable treasury;\n\n    uint256 public constant BTE_PER_ETH = 500_000;\n    uint256 public constant MIN_WEI = 1e17;\n    uint256 public constant MAX_WALLET_WEI = 5 ether;\n    uint256 public constant HARD_CAP = 100_000_000 * 1e18;\n\n    /// @dev Storage slot 1: ETH this wallet has already spent.\n    mapping(address => uint256) public spentWei;\n    /// @dev Storage slot 2: $BTE already sold against the hard cap.\n    uint256 public soldBte;\n\n    error ZeroAddress();\n    error TooSmall();\n    error OverWalletCap();\n    error SoldOut();\n    error TransferFailed();\n\n    event Bought(address indexed buyer, uint256 ethIn, uint256 bteOut);\n\n    constructor(address token, address payable treasury_) {\n        if (token == address(0) || treasury_ == address(0)) revert ZeroAddress();\n        bte = IERC20(token);\n        treasury = treasury_;\n    }\n\n    function quote(uint256 ethWei) public pure returns (uint256) {\n        return ethWei * BTE_PER_ETH;\n    }\n\n    function remainingWei(address wallet) public view returns (uint256) {\n        uint256 used = spentWei[wallet];\n        if (used >= MAX_WALLET_WEI) return 0;\n        return MAX_WALLET_WEI - used;\n    }\n\n    function remainingBte() public view returns (uint256) {\n        uint256 capLeft = HARD_CAP - soldBte;\n        uint256 bag = bte.balanceOf(address(this));\n        return bag < capLeft ? bag : capLeft;\n    }\n\n    receive() external payable {\n        _buy(msg.sender, msg.value);\n    }\n\n    function buy() external payable {\n        _buy(msg.sender, msg.value);\n    }\n\n    function _buy(address buyer, uint256 value) internal nonReentrant {\n        if (value < MIN_WEI) revert TooSmall();\n        uint256 used = spentWei[buyer];\n        if (used + value > MAX_WALLET_WEI) revert OverWalletCap();\n        uint256 out = value * BTE_PER_ETH;\n        uint256 nextSold = soldBte + out;\n        if (nextSold > HARD_CAP) revert SoldOut();\n        if (out > bte.balanceOf(address(this))) revert SoldOut();\n\n        spentWei[buyer] = used + value;\n        soldBte = nextSold;\n\n        if (!bte.transfer(buyer, out)) revert TransferFailed();\n        (bool ok, ) = treasury.call{value: value}(\"\");\n        if (!ok) revert TransferFailed();\n\n        emit Bought(buyer, value, out);\n    }\n}\n"
    },
    "vendor/ReentrancyGuard.sol": {
      "content": "// SPDX-License-Identifier: MIT\n// OpenZeppelin Contracts (last updated v5.1.0) (utils/ReentrancyGuard.sol)\npragma solidity ^0.8.37;\n\n/**\n * @dev Contract module that helps prevent reentrant calls to a function.\n * Storage: occupies slot 0 of the inheriting contract (`_status`).\n */\nabstract contract ReentrancyGuard {\n    uint256 private constant NOT_ENTERED = 1;\n    uint256 private constant ENTERED = 2;\n\n    /// @dev Storage slot 0 of BitereumTalk.\n    uint256 private _status;\n\n    error ReentrancyGuardReentrantCall();\n\n    constructor() {\n        _status = NOT_ENTERED;\n    }\n\n    modifier nonReentrant() {\n        _nonReentrantBefore();\n        _;\n        _nonReentrantAfter();\n    }\n\n    function _nonReentrantBefore() private {\n        if (_status == ENTERED) revert ReentrancyGuardReentrantCall();\n        _status = ENTERED;\n    }\n\n    function _nonReentrantAfter() private {\n        _status = NOT_ENTERED;\n    }\n}\n"
    },
    "interfaces/IERC20.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.37;\n\ninterface IERC20 {\n    function balanceOf(address account) external view returns (uint256);\n    function transfer(address to, uint256 amount) external returns (bool);\n    function transferFrom(address from, address to, uint256 amount) external returns (bool);\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "evmVersion": "cancun",
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "abi"
        ]
      }
    }
  }
}