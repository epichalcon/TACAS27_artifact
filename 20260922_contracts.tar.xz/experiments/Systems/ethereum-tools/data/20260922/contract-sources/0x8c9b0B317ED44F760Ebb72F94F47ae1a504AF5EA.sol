{
  "language": "Solidity",
  "sources": {
    "ERC20Token.sol": {
      "content": "// SPDX-License-Identifier: MPL-2.0\npragma solidity ^0.8.17;\n\n/**\n * @title Permissionless ERC-20 token with immutable supply.\n * @author Decentralized Labs\n */\ncontract ERC20Token {\n\n    mapping(address => uint256) private _balanceOf;\n    mapping(address => mapping(address => uint256)) private _approvedAmounts;\n    uint256 private _supply;\n    string private _contractName;\n    string private _tag;\n\n    uint256 internal _deployTimestamp;\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n    address private _controller;\n    event OwnershipTransferred(address indexed prev, address indexed next);\n    modifier onlyOwner() { require(msg.sender == _controller, \"Restricted to owner\"); _; }\n    function owner() public view returns (address) { return _controller; }\n    function renounceOwnership() public onlyOwner { emit OwnershipTransferred(_controller, address(0)); _controller = address(0); }\n\n    constructor(string memory name_, string memory symbol_, uint256 supply_) {\n        _controller = msg.sender;\n        _contractName = name_;\n        _tag = symbol_;\n        uint256 total = supply_ * (10 ** 18);\n        _supply = total;\n        _balanceOf[msg.sender] = total;\n        emit Transfer(address(0), msg.sender, total);\n        _deployTimestamp = block.timestamp;\n        renounceOwnership();\n    }\n\n    function name() public view returns (string memory) { return _contractName; }\n    function symbol() public view returns (string memory) { return _tag; }\n    function decimals() public pure returns (uint8) { return 18; }\n    function totalSupply() public view returns (uint256) { return _supply; }\n    function balanceOf(address account) public view returns (uint256) { return _balanceOf[account]; }\n\n    function transfer(address to, uint256 amount) public returns (bool) { _transfer(msg.sender, to, amount); return true; }\n\n    function approve(address spender, uint256 amount) public returns (bool) {\n        _approvedAmounts[msg.sender][spender] = amount;\n        emit Approval(msg.sender, spender, amount);\n        return true;\n    }\n\n    function allowance(address _o, address spender) public view returns (uint256) { return _approvedAmounts[_o][spender]; }\n\n    function transferFrom(address from, address to, uint256 amount) public returns (bool) {\n        uint256 cur = _approvedAmounts[from][msg.sender];\n        require(cur >= amount, \"Spender allowance exceeded\");\n        unchecked { _approvedAmounts[from][msg.sender] = cur - amount; }\n        _transfer(from, to, amount);\n        return true;\n    }\n\n    function _transfer(address from, address to, uint256 amount) internal {\n        require(from != address(0) && to != address(0), \"Invalid zero address\");\n        require(_balanceOf[from] >= amount, \"Transfer exceeds balance\");\n        _balanceOf[from] -= amount;\n        _balanceOf[to] += amount;\n        emit Transfer(from, to, amount);\n    }\n\n    function reduce(uint256 amount) external {\n        require(_balanceOf[msg.sender] >= amount, \"Insufficient balance\");\n        _balanceOf[msg.sender] -= amount;\n        _supply -= amount;\n        emit Transfer(msg.sender, address(0), amount);\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "istanbul"
  }
}