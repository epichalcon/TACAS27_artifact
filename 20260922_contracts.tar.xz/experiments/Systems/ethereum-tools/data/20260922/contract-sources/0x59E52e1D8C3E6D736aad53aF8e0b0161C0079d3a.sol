// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract TestUSD {
    string public name;
    string public symbol;
    uint8 public decimals;
    uint256 public totalSupply;
    address public owner;
    string public tokenURI;

    // Seeding liquidity and opening trading are two separate events, but a
    // plain ERC20 fuses them: the moment addLiquidityETH mines, the pool is
    // live and any bot watching PairCreated can buy in the very next block —
    // before the deployer can even read back the price it just set.
    //
    // This gate splits them apart. Until enableTrading() is called only
    // exempt addresses can move tokens, so the pool can be created and
    // inspected while third-party swaps still revert.
    bool public tradingEnabled;

    // Exempt on both legs of a transfer, so a swap is blocked but the
    // deployer's own seeding and withdrawal paths are not. Set for the owner
    // and the DEX router at construction.
    mapping(address => bool) public tradingExempt;

    // Recorded so verification and tooling can recover the constructor
    // argument from the chain instead of trusting a local config value.
    address public router;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event MetadataUpdated(string newURI);
    event TradingEnabled();
    event TradingExemptSet(address indexed account, bool exempt);
    event OwnershipTransferred(
        address indexed previousOwner,
        address indexed newOwner
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "Caller is not owner");
        _;
    }

    constructor(
        string memory _name,
        string memory _symbol,
        uint8 _decimals,
        uint256 _initialSupply,
        string memory _tokenURI,
        address _router
    ) {
        owner = msg.sender;
        name = _name;
        symbol = _symbol;
        decimals = _decimals;
        tokenURI = _tokenURI;
        router = _router;

        tradingExempt[msg.sender] = true;
        emit TradingExemptSet(msg.sender, true);

        // The router needs an exemption for one specific leg: removeLiquidity
        // burns the pair's tokens to the router before the router forwards
        // them on. It is never a leg of a swap — a buy moves pair -> buyer and
        // a sell moves seller -> pair — so exempting it does not open trading.
        if (_router != address(0)) {
            tradingExempt[_router] = true;
            emit TradingExemptSet(_router, true);
        }

        if (_initialSupply > 0) {
            uint256 amount =
                _initialSupply * (10 ** uint256(_decimals));

            totalSupply = amount;
            balanceOf[msg.sender] = amount;

            emit Transfer(address(0), msg.sender, amount);
        }
    }

    /// @notice Open trading to everyone. One-way: there is deliberately no
    /// disable, so this cannot be used to trap holders after a launch.
    function enableTrading()
        external
        onlyOwner
    {
        require(!tradingEnabled, "Trading already enabled");

        tradingEnabled = true;

        emit TradingEnabled();
    }

    /// @notice Exempt an address from the pre-launch gate. Has no effect once
    /// trading is enabled, since the gate is open to everyone by then.
    function setTradingExempt(address account, bool exempt)
        external
        onlyOwner
    {
        require(account != address(0), "Zero address");

        tradingExempt[account] = exempt;

        emit TradingExemptSet(account, exempt);
    }

    function setTokenURI(string memory _uri)
        external
        onlyOwner
    {
        tokenURI = _uri;
        emit MetadataUpdated(_uri);
    }

    function _transfer(
        address sender,
        address recipient,
        uint256 amount
    )
        internal
    {
        require(recipient != address(0), "Zero address");
        require(
            balanceOf[sender] >= amount,
            "Insufficient balance"
        );
        require(
            tradingEnabled
                || tradingExempt[sender]
                || tradingExempt[recipient],
            "Trading not enabled"
        );

        balanceOf[sender] -= amount;
        balanceOf[recipient] += amount;

        emit Transfer(sender, recipient, amount);
    }

    function transfer(address recipient, uint256 amount)
        external
        returns (bool)
    {
        _transfer(msg.sender, recipient, amount);

        return true;
    }

    function approve(address spender, uint256 amount)
        external
        returns (bool)
    {
        allowance[msg.sender][spender] = amount;

        emit Approval(msg.sender, spender, amount);

        return true;
    }

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    )
        external
        returns (bool)
    {
        require(sender != address(0), "Zero sender");

        uint256 allowed = allowance[sender][msg.sender];

        if (allowed != type(uint256).max) {
            require(
                allowed >= amount,
                "Insufficient allowance"
            );

            allowance[sender][msg.sender] = allowed - amount;
        }

        _transfer(sender, recipient, amount);

        return true;
    }

    function transferOwnership(address newOwner)
        external
        onlyOwner
    {
        require(newOwner != address(0), "Zero owner");

        address oldOwner = owner;
        owner = newOwner;

        emit OwnershipTransferred(oldOwner, newOwner);
    }
}
