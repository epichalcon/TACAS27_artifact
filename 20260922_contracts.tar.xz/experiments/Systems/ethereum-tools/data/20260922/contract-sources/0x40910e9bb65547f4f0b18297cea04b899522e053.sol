// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

/// @title VAREON Genesis Seal 01
/// @notice Minimal, non-upgradeable, append-only Ethereum witness for GENESIS_01.
/// @dev This contract does not generate randomness and does not store participant identity.
contract VareonGenesisSeal01 {
    error Unauthorized();
    error WrongBatch();
    error WrongSequenceStart();
    error InvalidSequenceRange();
    error BatchTooLarge();
    error ZeroMerkleRoot();
    error ZeroSealRecordHash();
    error BatchAlreadySealed();
    error SealRecordHashMismatch();

    bytes32 public immutable GENESIS_ID_HASH;
    bytes32 public immutable PROTOCOL_HASH;
    address public immutable SEAL_AUTHORITY;

    uint64 public nextBatchNumber = 1;
    uint64 public nextSequence = 1;

    mapping(uint64 => bytes32) public sealedRootByBatch;
    mapping(uint64 => bytes32) public sealedHashByBatch;

    event Seal(
        uint64 indexed batchNumber,
        uint64 sequenceStart,
        uint64 sequenceEnd,
        bytes32 merkleRoot,
        bytes32 sealRecordHash
    );

    constructor(
        bytes32 genesisIdHash_,
        bytes32 protocolHash_,
        address sealAuthority_
    ) {
        require(genesisIdHash_ != bytes32(0), "ZERO_GENESIS_ID_HASH");
        require(protocolHash_ != bytes32(0), "ZERO_PROTOCOL_HASH");
        require(sealAuthority_ != address(0), "ZERO_SEAL_AUTHORITY");

        GENESIS_ID_HASH = genesisIdHash_;
        PROTOCOL_HASH = protocolHash_;
        SEAL_AUTHORITY = sealAuthority_;
    }

    function seal(
        uint64 batchNumber,
        uint64 sequenceStart,
        uint64 sequenceEnd,
        bytes32 merkleRoot,
        bytes32 sealRecordHash
    ) external {
        if (msg.sender != SEAL_AUTHORITY) revert Unauthorized();
        if (batchNumber != nextBatchNumber) revert WrongBatch();
        if (sequenceStart != nextSequence) revert WrongSequenceStart();
        if (sequenceEnd < sequenceStart) revert InvalidSequenceRange();

        uint64 count = sequenceEnd - sequenceStart + 1;
        if (count > 256) revert BatchTooLarge();

        if (merkleRoot == bytes32(0)) revert ZeroMerkleRoot();
        if (sealRecordHash == bytes32(0)) revert ZeroSealRecordHash();
        if (sealedRootByBatch[batchNumber] != bytes32(0)) revert BatchAlreadySealed();

        bytes32 expected = _sealRecordHash(
            batchNumber,
            sequenceStart,
            sequenceEnd,
            merkleRoot
        );
        if (sealRecordHash != expected) revert SealRecordHashMismatch();

        sealedRootByBatch[batchNumber] = merkleRoot;
        sealedHashByBatch[batchNumber] = sealRecordHash;

        nextBatchNumber = batchNumber + 1;
        nextSequence = sequenceEnd + 1;

        emit Seal(
            batchNumber,
            sequenceStart,
            sequenceEnd,
            merkleRoot,
            sealRecordHash
        );
    }

    function _sealRecordHash(
        uint64 batchNumber,
        uint64 sequenceStart,
        uint64 sequenceEnd,
        bytes32 merkleRoot
    ) internal view returns (bytes32) {
        bytes memory genesis = bytes("GENESIS_01");

        bytes memory framed = abi.encodePacked(
            bytes4(0x56415245),
            bytes1(0x01),
            bytes1(0x06),
            uint8(genesis.length),
            genesis,
            batchNumber,
            sequenceStart,
            sequenceEnd,
            merkleRoot,
            PROTOCOL_HASH
        );

        return sha256(framed);
    }
}