// SPDX-License-Identifier: AGPL-3.0-or-later

pragma solidity 0.7.5;
pragma abicoder v2;

library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256 c) {
        require((c = a + b) >= a, "SafeMath: add overflow");
    }

    function sub(uint256 a, uint256 b) internal pure returns (uint256 c) {
        require((c = a - b) <= a, "SafeMath: sub underflow");
    }

    function mul(uint256 a, uint256 b) internal pure returns (uint256 c) {
        require(a == 0 || (c = a * b) / a == b, "SafeMath: mul overflow");
    }

    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        require(b > 0, "SafeMath: div by zero");
        return a / b;
    }
}

interface IERC20 {
    function decimals() external view returns (uint8);
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

library SafeERC20 {
    function safeTransfer(IERC20 token, address to, uint256 value) internal {
        _call(address(token), abi.encodeWithSelector(token.transfer.selector, to, value));
    }

    function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {
        _call(address(token), abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
    }

    function _call(address token, bytes memory data) private {
        uint256 size;
        assembly { size := extcodesize(token) }
        require(size > 0, "SafeERC20: not a contract");

        (bool success, bytes memory returndata) = token.call(data);
        require(success, "SafeERC20: call failed");

        if (returndata.length > 0) {
            require(abi.decode(returndata, (bool)), "SafeERC20: op returned false");
        }
    }
}

interface ISidraAuthority {
    function governor() external view returns (address);
    function guardian() external view returns (address);
    function policyManager() external view returns (address);
    function treasury() external view returns (address);
}

abstract contract SidraAccessControlled {
    event AuthorityUpdated(ISidraAuthority indexed previousAuthority, ISidraAuthority indexed newAuthority);

    ISidraAuthority public authority;

    constructor(ISidraAuthority _authority) {
        require(address(_authority) != address(0), "SIDRA: zero address");
        authority = _authority;
        emit AuthorityUpdated(ISidraAuthority(address(0)), _authority);
    }

    modifier onlyGovernor() {
        require(msg.sender == authority.governor(), "SIDRA: not governor");
        _;
    }

    modifier onlyPolicyManager() {
        require(msg.sender == authority.policyManager(), "SIDRA: not policy manager");
        _;
    }

    modifier onlyGovernorOrGuardian() {
        require(
            msg.sender == authority.governor() || msg.sender == authority.guardian(),
            "SIDRA: not governor or guardian"
        );
        _;
    }

    function setAuthority(ISidraAuthority newAuthority) external virtual onlyGovernor {
        require(address(newAuthority) != address(0), "SIDRA: zero address");
        ISidraAuthority previous = authority;
        authority = newAuthority;
        emit AuthorityUpdated(previous, newAuthority);
    }
}

interface IStakedSidra is IERC20 {
    function rebase(uint256 profit, uint256 epoch) external returns (uint256);
    function circulatingSupply() external view returns (uint256);
    function gonsForBalance(uint256 amount) external view returns (uint256);
    function balanceForGons(uint256 gons) external view returns (uint256);
    function index() external view returns (uint256);
}

interface IStakingVault {
    function retrieve(address staker, uint256 amount) external;
}

interface IRewardDistributor {
    function distribute() external returns (bool);
}

contract Staking is SidraAccessControlled {
    using SafeMath for uint256;
    using SafeERC20 for IERC20;
    using SafeERC20 for IStakedSidra;

    uint256 public constant BPS = 10000;
    uint256 public constant MAX_LOCK_BONUS_BPS = 5000;
    uint32 public constant MAX_LOCK_DURATION = 730 days;
    uint256 public constant MAX_REBASE_CATCHUP = 24;

    IERC20 public immutable sidra;
    IStakedSidra public immutable stSidra;

    struct Epoch {
        uint256 number;
        uint256 distribute;
        uint32 length;
        uint32 endTime;
    }
    Epoch public epoch;

    IRewardDistributor public distributor;
    IStakingVault public warmupVault;
    IStakingVault public lockVault;

    uint256 public warmupPeriod;
    bool public stakingPaused;

    struct Warmup {
        uint256 principal;
        uint256 gons;
        uint256 expiry;
        bool depositLocked;
    }
    mapping(address => Warmup) public warmupOf;

    struct LockTier {
        uint32 duration;
        uint16 bonusBps;
        bool enabled;
    }
    LockTier[] public lockTiers;

    struct LockPosition {
        uint256 gons;
        uint256 principal;
        uint256 bonus;
        uint64 maturity;
        uint16 tierId;
        bool closed;
    }
    mapping(address => LockPosition[]) private _locks;

    uint256 public bonusReserve;
    uint256 public bonusAllocated;

    uint256 private _entered;

    event Staked(address indexed staker, address indexed recipient, uint256 amount, bool warmed);
    event Claimed(address indexed recipient, uint256 amount);
    event Forfeited(address indexed staker, uint256 stakedReturned, uint256 principalReturned);
    event DepositLockSet(address indexed account, bool locked);
    event Unstaked(address indexed staker, uint256 amount);

    event LockOpened(address indexed staker, uint256 indexed positionId, uint16 tierId, uint256 principal, uint256 bonus, uint64 maturity);
    event LockRedeemed(address indexed staker, uint256 indexed positionId, uint256 payout, uint256 bonus);
    event LockExitedEarly(address indexed staker, uint256 indexed positionId, uint256 payout, uint256 forfeited);
    event LockTierAdded(uint256 indexed tierId, uint32 duration, uint16 bonusBps);
    event LockTierUpdated(uint256 indexed tierId, uint32 duration, uint16 bonusBps, bool enabled);

    event BonusReserveFunded(address indexed from, uint256 amount);
    event BonusReserveWithdrawn(address indexed to, uint256 amount);

    event RebaseExecuted(uint256 indexed epochNumber, uint256 distributed, uint256 index);
    event DistributorUpdated(address indexed distributor);
    event WarmupVaultSet(address indexed vault);
    event LockVaultSet(address indexed vault);
    event WarmupPeriodUpdated(uint256 period);
    event StakingPausedSet(bool paused);

    modifier nonReentrant() {
        require(_entered == 0, "SIDRA: reentrant");
        _entered = 1;
        _;
        _entered = 0;
    }

    modifier whenActive() {
        require(!stakingPaused, "SIDRA: staking paused");
        _;
    }

    constructor(
        ISidraAuthority _authority,
        address _sidra,
        address _stSidra,
        uint32 _epochLength,
        uint256 _firstEpochNumber,
        uint32 _firstEpochTime
    ) SidraAccessControlled(_authority) {
        require(_sidra != address(0) && _stSidra != address(0), "SIDRA: zero address");
        require(_epochLength > 0, "SIDRA: zero epoch length");

        sidra = IERC20(_sidra);
        stSidra = IStakedSidra(_stSidra);

        epoch = Epoch({
            length: _epochLength,
            number: _firstEpochNumber,
            endTime: _firstEpochTime,
            distribute: 0
        });
    }

    // ---------------------------------------------------------------------
    // Liquid staking
    // ---------------------------------------------------------------------

    function stake(uint256 amount, address recipient) external nonReentrant whenActive returns (bool) {
        require(recipient != address(0), "SIDRA: zero recipient");
        require(amount > 0, "SIDRA: zero amount");

        rebase();
        sidra.safeTransferFrom(msg.sender, address(this), amount);

        if (warmupPeriod == 0) {
            stSidra.safeTransfer(recipient, amount);
            emit Staked(msg.sender, recipient, amount, false);
            return true;
        }

        require(address(warmupVault) != address(0), "SIDRA: warmup vault unset");

        Warmup storage info = warmupOf[recipient];
        require(!info.depositLocked, "SIDRA: deposits locked for account");

        info.principal = info.principal.add(amount);
        info.gons = info.gons.add(stSidra.gonsForBalance(amount));
        info.expiry = epoch.number.add(warmupPeriod);

        stSidra.safeTransfer(address(warmupVault), amount);
        emit Staked(msg.sender, recipient, amount, true);
        return true;
    }

    function claim(address recipient) external nonReentrant {
        Warmup memory info = warmupOf[recipient];
        require(info.gons > 0, "SIDRA: nothing in warmup");
        require(epoch.number >= info.expiry, "SIDRA: warmup not elapsed");

        delete warmupOf[recipient];

        uint256 amount = stSidra.balanceForGons(info.gons);
        warmupVault.retrieve(recipient, amount);
        emit Claimed(recipient, amount);
    }

    function forfeit() external nonReentrant {
        Warmup memory info = warmupOf[msg.sender];
        require(info.gons > 0, "SIDRA: nothing in warmup");

        delete warmupOf[msg.sender];

        uint256 staked = stSidra.balanceForGons(info.gons);
        warmupVault.retrieve(address(this), staked);
        sidra.safeTransfer(msg.sender, info.principal);

        emit Forfeited(msg.sender, staked, info.principal);
    }

    function setDepositLock(bool locked) external {
        warmupOf[msg.sender].depositLocked = locked;
        emit DepositLockSet(msg.sender, locked);
    }

    function unstake(uint256 amount, bool trigger) external nonReentrant {
        require(amount > 0, "SIDRA: zero amount");
        if (trigger) {
            rebase();
        }

        stSidra.safeTransferFrom(msg.sender, address(this), amount);
        sidra.safeTransfer(msg.sender, amount);

        emit Unstaked(msg.sender, amount);
    }

    // ---------------------------------------------------------------------
    // Locked staking
    // ---------------------------------------------------------------------

    function stakeLocked(uint256 amount, uint16 tierId) external nonReentrant whenActive returns (uint256 positionId) {
        require(amount > 0, "SIDRA: zero amount");
        require(tierId < lockTiers.length, "SIDRA: bad tier");
        require(address(lockVault) != address(0), "SIDRA: lock vault unset");

        LockTier memory tier = lockTiers[tierId];
        require(tier.enabled, "SIDRA: tier disabled");

        rebase();

        uint256 bonus = amount.mul(tier.bonusBps).div(BPS);
        require(availableBonus() >= bonus, "SIDRA: bonus reserve exhausted");
        bonusAllocated = bonusAllocated.add(bonus);

        sidra.safeTransferFrom(msg.sender, address(this), amount);
        stSidra.safeTransfer(address(lockVault), amount);

        uint64 maturity = uint64(block.timestamp) + tier.duration;

        _locks[msg.sender].push(LockPosition({
            gons: stSidra.gonsForBalance(amount),
            principal: amount,
            bonus: bonus,
            maturity: maturity,
            tierId: tierId,
            closed: false
        }));

        positionId = _locks[msg.sender].length - 1;
        emit LockOpened(msg.sender, positionId, tierId, amount, bonus, maturity);
    }

    function redeemLock(uint256 positionId) external nonReentrant {
        LockPosition storage position = _positionOf(msg.sender, positionId);
        require(block.timestamp >= position.maturity, "SIDRA: still locked");

        rebase();

        uint256 staked = stSidra.balanceForGons(position.gons);
        uint256 bonus = position.bonus;

        position.closed = true;
        bonusAllocated = bonusAllocated.sub(bonus);
        bonusReserve = bonusReserve.sub(bonus);

        lockVault.retrieve(address(this), staked);
        sidra.safeTransfer(msg.sender, staked.add(bonus));

        emit LockRedeemed(msg.sender, positionId, staked.add(bonus), bonus);
    }

    function exitLockEarly(uint256 positionId) external nonReentrant {
        LockPosition storage position = _positionOf(msg.sender, positionId);
        require(block.timestamp < position.maturity, "SIDRA: use redeemLock");

        rebase();

        uint256 staked = stSidra.balanceForGons(position.gons);
        uint256 principal = position.principal;

        position.closed = true;
        bonusAllocated = bonusAllocated.sub(position.bonus);

        lockVault.retrieve(address(this), staked);
        sidra.safeTransfer(msg.sender, principal);

        emit LockExitedEarly(msg.sender, positionId, principal, staked.sub(principal));
    }

    function _positionOf(address account, uint256 positionId) private view returns (LockPosition storage position) {
        require(positionId < _locks[account].length, "SIDRA: bad position");
        position = _locks[account][positionId];
        require(!position.closed, "SIDRA: position closed");
    }

    // ---------------------------------------------------------------------
    // Rebase
    // ---------------------------------------------------------------------

    function rebase() public {
        uint256 iterations;

        while (epoch.endTime <= uint32(block.timestamp) && iterations < MAX_REBASE_CATCHUP) {
            stSidra.rebase(epoch.distribute, epoch.number);

            epoch.endTime = epoch.endTime + epoch.length;
            epoch.number++;

            if (address(distributor) != address(0)) {
                distributor.distribute();
            }

            uint256 balance = stakingBalance();
            uint256 staked = stSidra.circulatingSupply();
            epoch.distribute = balance > staked ? balance.sub(staked) : 0;

            emit RebaseExecuted(epoch.number, epoch.distribute, stSidra.index());
            iterations++;
        }
    }

    /// @dev SIDRA backing circulating stSIDRA. Bonus reserve is excluded so it
    ///      is never handed out as rebase yield.
    function stakingBalance() public view returns (uint256) {
        return sidra.balanceOf(address(this)).sub(bonusReserve);
    }

    function index() external view returns (uint256) {
        return stSidra.index();
    }

    // ---------------------------------------------------------------------
    // Bonus reserve
    // ---------------------------------------------------------------------

    function fundBonusReserve(uint256 amount) external nonReentrant {
        require(amount > 0, "SIDRA: zero amount");
        sidra.safeTransferFrom(msg.sender, address(this), amount);
        bonusReserve = bonusReserve.add(amount);
        emit BonusReserveFunded(msg.sender, amount);
    }

    function withdrawUnallocatedBonus(address to, uint256 amount) external onlyGovernor nonReentrant {
        require(to != address(0), "SIDRA: zero address");
        require(amount <= availableBonus(), "SIDRA: amount is allocated");

        bonusReserve = bonusReserve.sub(amount);
        sidra.safeTransfer(to, amount);
        emit BonusReserveWithdrawn(to, amount);
    }

    function availableBonus() public view returns (uint256) {
        return bonusReserve.sub(bonusAllocated);
    }

    // ---------------------------------------------------------------------
    // Views
    // ---------------------------------------------------------------------

    function lockTierCount() external view returns (uint256) {
        return lockTiers.length;
    }

    function lockCount(address account) external view returns (uint256) {
        return _locks[account].length;
    }

    function getLock(address account, uint256 positionId) external view returns (LockPosition memory) {
        require(positionId < _locks[account].length, "SIDRA: bad position");
        return _locks[account][positionId];
    }

    function getLocks(address account) external view returns (LockPosition[] memory) {
        return _locks[account];
    }

    function lockValue(address account, uint256 positionId) external view returns (uint256 staked, uint256 bonus) {
        require(positionId < _locks[account].length, "SIDRA: bad position");
        LockPosition memory position = _locks[account][positionId];
        return (stSidra.balanceForGons(position.gons), position.bonus);
    }

    function warmupClaimable(address account) external view returns (bool ready, uint256 amount) {
        Warmup memory info = warmupOf[account];
        if (info.gons == 0) return (false, 0);
        return (epoch.number >= info.expiry, stSidra.balanceForGons(info.gons));
    }

    // ---------------------------------------------------------------------
    // Policy
    // ---------------------------------------------------------------------

    function addLockTier(uint32 duration, uint16 bonusBps) external onlyPolicyManager returns (uint256 tierId) {
        require(duration > 0 && duration <= MAX_LOCK_DURATION, "SIDRA: bad duration");
        require(bonusBps <= MAX_LOCK_BONUS_BPS, "SIDRA: bonus too high");

        lockTiers.push(LockTier({duration: duration, bonusBps: bonusBps, enabled: true}));
        tierId = lockTiers.length - 1;
        emit LockTierAdded(tierId, duration, bonusBps);
    }

    function updateLockTier(uint256 tierId, uint32 duration, uint16 bonusBps, bool enabled) external onlyPolicyManager {
        require(tierId < lockTiers.length, "SIDRA: bad tier");
        require(duration > 0 && duration <= MAX_LOCK_DURATION, "SIDRA: bad duration");
        require(bonusBps <= MAX_LOCK_BONUS_BPS, "SIDRA: bonus too high");

        lockTiers[tierId] = LockTier({duration: duration, bonusBps: bonusBps, enabled: enabled});
        emit LockTierUpdated(tierId, duration, bonusBps, enabled);
    }

    function setWarmupPeriod(uint256 period) external onlyPolicyManager {
        warmupPeriod = period;
        emit WarmupPeriodUpdated(period);
    }

    // ---------------------------------------------------------------------
    // Governance
    // ---------------------------------------------------------------------

    function setDistributor(address _distributor) external onlyGovernor {
        distributor = IRewardDistributor(_distributor);
        emit DistributorUpdated(_distributor);
    }

    function setWarmupVault(address _vault) external onlyGovernor {
        require(address(warmupVault) == address(0), "SIDRA: warmup vault already set");
        require(_vault != address(0), "SIDRA: zero address");
        warmupVault = IStakingVault(_vault);
        emit WarmupVaultSet(_vault);
    }

    function setLockVault(address _vault) external onlyGovernor {
        require(address(lockVault) == address(0), "SIDRA: lock vault already set");
        require(_vault != address(0), "SIDRA: zero address");
        lockVault = IStakingVault(_vault);
        emit LockVaultSet(_vault);
    }

    function setStakingPaused(bool paused) external {
        if (paused) {
            require(
                msg.sender == authority.governor() || msg.sender == authority.guardian(),
                "SIDRA: not governor or guardian"
            );
        } else {
            require(msg.sender == authority.governor(), "SIDRA: not governor");
        }
        stakingPaused = paused;
        emit StakingPausedSet(paused);
    }

    function rescueToken(address token, address to, uint256 amount) external onlyGovernor {
        require(token != address(sidra) && token != address(stSidra), "SIDRA: protected token");
        require(to != address(0), "SIDRA: zero address");
        IERC20(token).safeTransfer(to, amount);
    }
}