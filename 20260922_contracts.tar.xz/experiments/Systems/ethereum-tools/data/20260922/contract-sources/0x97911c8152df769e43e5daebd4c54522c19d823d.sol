// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract GM {
    // สร้างตัวแปรสำหรับเก็บข้อมูล (จะแสดงผลในหน้า Read Contract อัตโนมัติ)
    string public currentMessage = "GM7";

    // ฟังก์ชันนี้จะไปปรากฏในหน้า Write Contract ให้คุณกดทำ Tx ได้
    function setMessage(string memory _newMessage) external {
        currentMessage = _newMessage;
    }
}