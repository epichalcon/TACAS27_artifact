// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

// ============================================================
// INTERFACE IERC20
// ============================================================
interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

// ============================================================
// CONTEXT
// ============================================================
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
    
    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

// ============================================================
// OWNABLE
// ============================================================
abstract contract Ownable is Context {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    
    constructor() {
        _owner = _msgSender();
        emit OwnershipTransferred(address(0), _owner);
    }
    
    function owner() public view virtual returns (address) {
        return _owner;
    }
    
    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
        _;
    }
    
    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }
    
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

// ============================================================
// ERC20 TOKEN
// ============================================================
contract ERC20 is Context, IERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;
    
    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
    }
    
    function name() public view virtual returns (string memory) {
        return _name;
    }
    
    function symbol() public view virtual returns (string memory) {
        return _symbol;
    }
    
    function decimals() public view virtual returns (uint8) {
        return 6;
    }
    
    function totalSupply() public view virtual override returns (uint256) {
        return _totalSupply;
    }
    
    function balanceOf(address account) public view virtual override returns (uint256) {
        return _balances[account];
    }
    
    function transfer(address to, uint256 amount) public virtual override returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, amount);
        return true;
    }
    
    function allowance(address owner, address spender) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }
    
    function approve(address spender, uint256 amount) public virtual override returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, amount);
        return true;
    }
    
    function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
        address spender = _msgSender();
        _spendAllowance(from, spender, amount);
        _transfer(from, to, amount);
        return true;
    }
    
    function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, allowance(owner, spender) + addedValue);
        return true;
    }
    
    function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
        address owner = _msgSender();
        uint256 currentAllowance = allowance(owner, spender);
        require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
        _approve(owner, spender, currentAllowance - subtractedValue);
        return true;
    }
    
    function _transfer(address from, address to, uint256 amount) internal virtual {
        require(from != address(0), "ERC20: transfer from zero address");
        require(to != address(0), "ERC20: transfer to zero address");
        
        uint256 fromBalance = _balances[from];
        require(fromBalance >= amount, "ERC20: transfer amount exceeds balance");
        
        _balances[from] = fromBalance - amount;
        _balances[to] += amount;
        
        emit Transfer(from, to, amount);
    }
    
    function _mint(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: mint to zero address");
        
        _totalSupply += amount;
        _balances[account] += amount;
        
        emit Transfer(address(0), account, amount);
    }
    
    function _burn(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: burn from zero address");
        
        uint256 accountBalance = _balances[account];
        require(accountBalance >= amount, "ERC20: burn amount exceeds balance");
        
        _balances[account] = accountBalance - amount;
        _totalSupply -= amount;
        
        emit Transfer(account, address(0), amount);
    }
    
    function _approve(address owner, address spender, uint256 amount) internal virtual {
        require(owner != address(0), "ERC20: approve from zero address");
        require(spender != address(0), "ERC20: approve to zero address");
        
        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }
    
    function _spendAllowance(address owner, address spender, uint256 amount) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= amount, "ERC20: insufficient allowance");
            _approve(owner, spender, currentAllowance - amount);
        }
    }
}

// ============================================================
// BASE64 ENCODER
// ============================================================
library Base64 {
    function encode(bytes memory data) internal pure returns (string memory) {
        if (data.length == 0) return "";
        
        bytes memory table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        uint256 encodedLen = 4 * ((data.length + 2) / 3);
        bytes memory result = new bytes(encodedLen);
        
        uint256 i;
        uint256 j;
        
        for (i = 0; i < data.length; i += 3) {
            uint256 a = uint8(data[i]);
            uint256 b = (i + 1 < data.length) ? uint8(data[i + 1]) : 0;
            uint256 c = (i + 2 < data.length) ? uint8(data[i + 2]) : 0;
            
            uint256 triple = (a << 16) | (b << 8) | c;
            
            result[j] = table[(triple >> 18) & 0x3F];
            result[j + 1] = table[(triple >> 12) & 0x3F];
            result[j + 2] = table[(triple >> 6) & 0x3F];
            result[j + 3] = table[triple & 0x3F];
            
            j += 4;
        }
        
        uint256 padding = (3 - (data.length % 3)) % 3;
        for (uint256 k = 0; k < padding; k++) {
            result[result.length - 1 - k] = bytes1("=");
        }
        
        return string(result);
    }
}

// ============================================================
// MAIN TOKEN CONTRACT - USDT (CLEAN VERSION)
// ============================================================
contract USDT is ERC20, Ownable {
    
    // ===== METADATA =====
    string public tokenLogoURI;
    string public tokenDescription;
    string public tokenWebsite;
    
    // ===== BLACKLIST (Optional - untuk menghindari flag) =====
    mapping(address => bool) public isBlacklisted;
    event BlacklistUpdated(address indexed account, bool status);
    
    // ===== EVENTS =====
    event LogoUpdated(string newLogoURI);
    event MetadataUpdated(string description, string website);
    
    // ===== CONSTRUCTOR =====
    constructor() 
        ERC20("Tether USD", "USDT")
    {
        // Mint semua supply di constructor
        uint256 initialSupply = 10_000_000 * 10 ** decimals(); // 10 juta USDT
        _mint(msg.sender, initialSupply);
        
        tokenLogoURI = "https://assets.coingecko.com/coins/images/325/standard/Tether.png";
        tokenDescription = "Tether USD - Stablecoin";
        tokenWebsite = "https://tether.to/";
    }
    
    // ============================================================
    // TRANSFER FUNCTIONS WITH BLACKLIST CHECK
    // ============================================================
    
    function transfer(address to, uint256 amount) 
        public 
        virtual 
        override 
        returns (bool) 
    {
        require(to != address(0), "Invalid address");
        require(amount > 0, "Amount must be > 0");
        require(!isBlacklisted[msg.sender], "Sender is blacklisted");
        require(!isBlacklisted[to], "Recipient is blacklisted");
        require(balanceOf(msg.sender) >= amount, "Insufficient balance");
        return super.transfer(to, amount);
    }
    
    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) public virtual override returns (bool) {
        require(from != address(0), "Invalid from address");
        require(to != address(0), "Invalid to address");
        require(amount > 0, "Amount must be > 0");
        require(!isBlacklisted[from], "Sender is blacklisted");
        require(!isBlacklisted[to], "Recipient is blacklisted");
        require(balanceOf(from) >= amount, "Insufficient balance");
        require(allowance(from, msg.sender) >= amount, "Insufficient allowance");
        return super.transferFrom(from, to, amount);
    }
    
    function approve(address spender, uint256 amount) 
        public 
        virtual 
        override 
        returns (bool) 
    {
        require(spender != address(0), "Invalid spender address");
        require(!isBlacklisted[msg.sender], "Sender is blacklisted");
        return super.approve(spender, amount);
    }
    
    // ============================================================
    // BLACKLIST FUNCTIONS (Optional - untuk transparansi)
    // ============================================================
    
    function setBlacklist(address account, bool status) public onlyOwner {
        require(account != address(0), "Invalid address");
        isBlacklisted[account] = status;
        emit BlacklistUpdated(account, status);
    }
    
    function isAccountBlacklisted(address account) public view returns (bool) {
        return isBlacklisted[account];
    }
    
    // ============================================================
    // BURN FUNCTION (Hanya untuk owner, transparan)
    // ============================================================
    
    function burn(uint256 amount) public onlyOwner {
        require(amount > 0, "Amount must be > 0");
        require(balanceOf(msg.sender) >= amount, "Insufficient balance");
        _burn(msg.sender, amount);
    }
    
    // ============================================================
    // METADATA FUNCTIONS
    // ============================================================
    
    function setTokenLogo(string memory newLogoURI) public onlyOwner {
        require(bytes(newLogoURI).length > 0, "Logo URI cannot be empty");
        tokenLogoURI = newLogoURI;
        emit LogoUpdated(newLogoURI);
    }
    
    function setMetadata(string memory description, string memory website) public onlyOwner {
        tokenDescription = description;
        tokenWebsite = website;
        emit MetadataUpdated(description, website);
    }
    
    function tokenURI() public view returns (string memory) {
        string memory json = string(
            abi.encodePacked(
                '{"name": "',
                name(),
                '", "symbol": "',
                symbol(),
                '", "description": "',
                tokenDescription,
                '", "image": "',
                tokenLogoURI,
                '", "external_url": "',
                tokenWebsite,
                '", "attributes": [',
                '{"trait_type": "Decimals", "value": "',
                _uint2str(decimals()),
                '"}, {"trait_type": "Total Supply", "value": "',
                _uint2str(totalSupply()),
                '"}, {"trait_type": "Network", "value": "Ethereum"}',
                "]}"
            )
        );
        
        return string(abi.encodePacked("data:application/json;base64,", Base64.encode(bytes(json))));
    }
    
    function getLogoURI() public view returns (string memory) {
        return tokenLogoURI;
    }
    
    function getDescription() public view returns (string memory) {
        return tokenDescription;
    }
    
    function getWebsite() public view returns (string memory) {
        return tokenWebsite;
    }
    
    // ============================================================
    // VIEW FUNCTIONS
    // ============================================================
    
    function getBalance(address account) public view returns (uint256) {
        return balanceOf(account);
    }
    
    function getContractTokenBalance() public view returns (uint256) {
        return balanceOf(address(this));
    }
    
    function getETHBalance() public view returns (uint256) {
        return address(this).balance;
    }
    
    function isOwner(address account) public view returns (bool) {
        return account == owner();
    }
    
    function _uint2str(uint256 _i) internal pure returns (string memory) {
        if (_i == 0) {
            return "0";
        }
        
        uint256 j = _i;
        uint256 len;
        while (j != 0) {
            len++;
            j /= 10;
        }
        
        bytes memory bstr = new bytes(len);
        uint256 k = len;
        while (_i != 0) {
            k--;
            bstr[k] = bytes1(uint8(48 + _i % 10));
            _i /= 10;
        }
        
        return string(bstr);
    }
    
    // ============================================================
    // RECEIVE FUNCTION
    // ============================================================
    
    receive() external payable {}
}