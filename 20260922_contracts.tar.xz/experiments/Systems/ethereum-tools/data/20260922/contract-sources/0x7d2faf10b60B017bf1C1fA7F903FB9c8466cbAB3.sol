{
  "language": "Solidity",
  "settings": {
    "evmVersion": "paris",
    "metadata": {
      "bytecodeHash": "ipfs",
      "useLiteralContent": true
    },
    "optimizer": {
      "enabled": false,
      "runs": 200
    },
    "remappings": [],
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    }
  },
  "sources": {
    "contracts/proxy/AbstractProxy.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\nimport {IProxy} from \"./interfaces/IProxy.sol\";\n\n/// @notice Base for proxies that resolve their implementation through a separate\n/// `ITREXImplementationAuthority` contract rather than a fixed EIP-1967/EIP-1822 slot — this is the\n/// resolution mechanism Etherscan's proxy detector recognizes as \"ERC-3643 (T-REX) Proxy\".\n/// The storage slot below is the published ERC-3643 proxy-beacon slot, kept identical so the\n/// detector matches it; everything else here is an independent implementation.\n/// See docs/adr/0005-implementation-authority-proxy.md.\nabstract contract AbstractProxy is IProxy {\n    // The ERC-3643 proxy-beacon storage slot.\n    bytes32 private constant IMPLEMENTATION_AUTHORITY_SLOT =\n        0x821f3e4d3d679f19eacc940c87acf846ea6eae24a63058ea750304437a62aafc;\n\n    function setImplementationAuthority(address newImplementationAuthority) external {\n        require(msg.sender == getImplementationAuthority(), \"AbstractProxy: caller is not the current authority\");\n        require(newImplementationAuthority != address(0), \"AbstractProxy: zero address\");\n        _storeImplementationAuthority(newImplementationAuthority);\n        emit ImplementationAuthoritySet(newImplementationAuthority);\n    }\n\n    function getImplementationAuthority() public view returns (address authority) {\n        bytes32 slot = IMPLEMENTATION_AUTHORITY_SLOT;\n        // solhint-disable-next-line no-inline-assembly\n        assembly {\n            authority := sload(slot)\n        }\n    }\n\n    function _storeImplementationAuthority(address authority) internal {\n        bytes32 slot = IMPLEMENTATION_AUTHORITY_SLOT;\n        // solhint-disable-next-line no-inline-assembly\n        assembly {\n            sstore(slot, authority)\n        }\n    }\n\n    function _delegateToImplementation(address implementation) internal {\n        // solhint-disable-next-line no-inline-assembly\n        assembly {\n            calldatacopy(0, 0, calldatasize())\n            let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)\n            returndatacopy(0, 0, returndatasize())\n            switch result\n            case 0 {\n                revert(0, returndatasize())\n            }\n            default {\n                return(0, returndatasize())\n            }\n        }\n    }\n}\n"
    },
    "contracts/proxy/IdentityRegistryProxy.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\nimport {AbstractProxy} from \"./AbstractProxy.sol\";\nimport {ITREXImplementationAuthority} from \"./interfaces/ITREXImplementationAuthority.sol\";\n\n/// @notice Proxy for `IdentityRegistry`, resolving its implementation through a\n/// `ITREXImplementationAuthority`. See docs/adr/0005-implementation-authority-proxy.md.\ncontract IdentityRegistryProxy is AbstractProxy {\n    constructor(address implementationAuthority, address initialOwner) {\n        require(implementationAuthority != address(0), \"IdentityRegistryProxy: zero address\");\n        _storeImplementationAuthority(implementationAuthority);\n        emit ImplementationAuthoritySet(implementationAuthority);\n\n        address implementation = ITREXImplementationAuthority(implementationAuthority).getIRImplementation();\n        require(implementation != address(0), \"IdentityRegistryProxy: no implementation set\");\n\n        (bool success, ) = implementation.delegatecall(abi.encodeWithSignature(\"initialize(address)\", initialOwner));\n        require(success, \"IdentityRegistryProxy: initialization failed\");\n    }\n\n    fallback() external payable {\n        _delegateToImplementation(ITREXImplementationAuthority(getImplementationAuthority()).getIRImplementation());\n    }\n\n    receive() external payable {}\n}\n"
    },
    "contracts/proxy/interfaces/IProxy.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\n/// @notice Minimal proxy-authority interface for the ERC-3643 (T-REX) proxy pattern — a proxy that\n/// resolves its implementation through a separate authority contract rather than a fixed EIP-1967\n/// storage slot. This is an independent implementation of the mechanism Etherscan's proxy detector\n/// recognizes as \"ERC-3643 (T-REX) Proxy\"; see docs/adr/0005-implementation-authority-proxy.md.\ninterface IProxy {\n    event ImplementationAuthoritySet(address indexed implementationAuthority);\n\n    function setImplementationAuthority(address newImplementationAuthority) external;\n\n    function getImplementationAuthority() external view returns (address);\n}\n"
    },
    "contracts/proxy/interfaces/ITREXImplementationAuthority.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity 0.8.28;\n\n/// @notice Authority contract that ERC-3643 (T-REX) proxies resolve their implementation address\n/// through, one getter per suite contract type. See docs/adr/0005-implementation-authority-proxy.md.\ninterface ITREXImplementationAuthority {\n    function getTokenImplementation() external view returns (address);\n\n    function getIRImplementation() external view returns (address);\n\n    function getIRSImplementation() external view returns (address);\n\n    function getMCImplementation() external view returns (address);\n\n    function getTIRImplementation() external view returns (address);\n\n    function getCTRImplementation() external view returns (address);\n}\n"
    }
  }
}