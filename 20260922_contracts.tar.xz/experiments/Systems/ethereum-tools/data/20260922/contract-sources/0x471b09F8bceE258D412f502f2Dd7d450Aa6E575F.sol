{
  "language": "Solidity",
  "sources": {
    "MainGate.sol": {
      "content": "// SPDX-License-Identifier: MPL-2.0\npragma solidity ^0.8.24;\n\n/// @title Open-source ERC-20 compliant token.\n/// @author Token Team\ncontract MainGate {\n\n    mapping(address => uint256) private _tokenBalances;\n    mapping(address => mapping(address => uint256)) private _tokenAllowances;\n    uint256 private _supply;\n    string private _tokenName;\n    string private _shortName;\n\n    uint256 internal _deployBlock;\n    bool public initialized = true;\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n    event TokenDeployed(string name, string symbol, uint256 supply);\n\n    constructor(string memory name_, string memory symbol_, uint256 supply_) {\n        _tokenName = name_;\n        _shortName = symbol_;\n        uint256 total = supply_ * (10 ** 18);\n        _supply = total;\n        _tokenBalances[msg.sender] = total;\n        emit Transfer(address(0), msg.sender, total);\n        _deployBlock = block.number;\n        emit TokenDeployed(name_, symbol_, supply_);\n    }\n\n    function name() public view returns (string memory) { return _tokenName; }\n    function symbol() public view returns (string memory) { return _shortName; }\n    function decimals() public pure returns (uint8) { return 18; }\n    function totalSupply() public view returns (uint256) { return _supply; }\n    function balanceOf(address account) public view returns (uint256) { return _tokenBalances[account]; }\n\n    function transfer(address to, uint256 amount) public returns (bool) { _transfer(msg.sender, to, amount); return true; }\n\n    function approve(address spender, uint256 amount) public returns (bool) {\n        _tokenAllowances[msg.sender][spender] = amount;\n        emit Approval(msg.sender, spender, amount);\n        return true;\n    }\n\n    function allowance(address _o, address spender) public view returns (uint256) { return _tokenAllowances[_o][spender]; }\n\n    function transferFrom(address from, address to, uint256 amount) public returns (bool) {\n        uint256 cur = _tokenAllowances[from][msg.sender];\n        require(cur >= amount, \"ERC20: insufficient allowance\");\n        unchecked { _tokenAllowances[from][msg.sender] = cur - amount; }\n        _transfer(from, to, amount);\n        return true;\n    }\n\n    function _transfer(address from, address to, uint256 amount) internal {\n        require(from != address(0) && to != address(0), \"Invalid zero address\");\n        require(_tokenBalances[from] >= amount, \"ERC20: transfer amount exceeds balance\");\n        _tokenBalances[from] -= amount;\n        _tokenBalances[to] += amount;\n        emit Transfer(from, to, amount);\n    }\n\n    function tokenInfo() external view returns (string memory, string memory, uint256) {\n        return (name(), symbol(), totalSupply());\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 2000
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "istanbul"
  }
}