// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IFoundationMintCollection {
  function mintCountTo(uint16 count, address to) external returns (uint256 firstTokenId);
}

contract BloctopusPublicMintRouter {
  error NotOwner();
  error MintPaused();
  error InvalidAddress();
  error InvalidMintPrice();
  error InvalidMintLimit();
  error IncorrectPayment(uint256 expected, uint256 received);
  error WalletMintLimitReached();
  error WithdrawFailed();

  event Minted(address indexed minter, address indexed recipient, uint256 firstTokenId, uint256 priceWei);
  event MintPriceUpdated(uint256 mintPriceWei);
  event MaxPerWalletUpdated(uint256 maxPerWallet);
  event MintPausedUpdated(bool paused);
  event OwnerUpdated(address indexed owner);
  event PayoutAddressUpdated(address indexed payoutAddress);
  event FundsWithdrawn(address indexed to, uint256 amountWei);

  address public owner;
  address public payoutAddress;
  address public immutable collection;

  uint256 public mintPriceWei;
  uint256 public totalMints;
  uint256 public maxPerWallet;
  bool public mintPaused;

  mapping(address => uint256) public mintedByWallet;

  modifier onlyOwner() {
    if (msg.sender != owner) revert NotOwner();
    _;
  }

  constructor(
    address collectionAddress,
    address initialOwner,
    address initialPayoutAddress,
    uint256 initialMintPriceWei,
    uint256 initialMaxPerWallet
  ) {
    if (collectionAddress == address(0) || initialOwner == address(0) || initialPayoutAddress == address(0)) {
      revert InvalidAddress();
    }
    if (initialMintPriceWei == 0) revert InvalidMintPrice();
    if (initialMaxPerWallet > type(uint16).max) revert InvalidMintLimit();

    collection = collectionAddress;
    owner = initialOwner;
    payoutAddress = initialPayoutAddress;
    mintPriceWei = initialMintPriceWei;
    maxPerWallet = initialMaxPerWallet;
  }

  receive() external payable {
    _mintTo(msg.sender);
  }

  fallback() external payable {
    _mintTo(msg.sender);
  }

  function mint() external payable returns (uint256 firstTokenId) {
    return _mintTo(msg.sender);
  }

  function mintTo(address recipient) external payable returns (uint256 firstTokenId) {
    if (recipient == address(0)) revert InvalidAddress();
    return _mintTo(recipient);
  }

  function setMintPaused(bool paused) external onlyOwner {
    mintPaused = paused;
    emit MintPausedUpdated(paused);
  }

  function setMintPriceWei(uint256 newMintPriceWei) external onlyOwner {
    if (newMintPriceWei == 0) revert InvalidMintPrice();
    mintPriceWei = newMintPriceWei;
    emit MintPriceUpdated(newMintPriceWei);
  }

  function setMaxPerWallet(uint256 newMaxPerWallet) external onlyOwner {
    if (newMaxPerWallet > type(uint16).max) revert InvalidMintLimit();
    maxPerWallet = newMaxPerWallet;
    emit MaxPerWalletUpdated(newMaxPerWallet);
  }

  function setOwner(address newOwner) external onlyOwner {
    if (newOwner == address(0)) revert InvalidAddress();
    owner = newOwner;
    emit OwnerUpdated(newOwner);
  }

  function setPayoutAddress(address newPayoutAddress) external onlyOwner {
    if (newPayoutAddress == address(0)) revert InvalidAddress();
    payoutAddress = newPayoutAddress;
    emit PayoutAddressUpdated(newPayoutAddress);
  }

  function withdraw() external onlyOwner {
    _withdrawAll();
  }

  function _mintTo(address recipient) internal returns (uint256 firstTokenId) {
    if (mintPaused) revert MintPaused();
    if (msg.value != mintPriceWei) revert IncorrectPayment(mintPriceWei, msg.value);

    uint256 walletMintCount = mintedByWallet[msg.sender];
    uint256 walletLimit = maxPerWallet;
    if (walletLimit > 0 && walletMintCount + 1 > walletLimit) {
      revert WalletMintLimitReached();
    }

    unchecked {
      mintedByWallet[msg.sender] = walletMintCount + 1;
      totalMints += 1;
    }

    firstTokenId = IFoundationMintCollection(collection).mintCountTo(1, recipient);
    emit Minted(msg.sender, recipient, firstTokenId, msg.value);

    _withdrawAll();
  }

  function _withdrawAll() internal {
    uint256 balance = address(this).balance;
    if (balance == 0) return;

    (bool ok, ) = payable(payoutAddress).call{ value: balance }("");
    if (!ok) revert WithdrawFailed();
    emit FundsWithdrawn(payoutAddress, balance);
  }
}