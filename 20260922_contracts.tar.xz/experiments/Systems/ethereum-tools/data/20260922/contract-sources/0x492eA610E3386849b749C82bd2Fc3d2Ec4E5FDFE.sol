{
  "language": "Solidity",
  "sources": {
    "ISharedManifest.sol": {
      "content": "// SPDX-License-Identifier: ISC\npragma solidity >=0.7.0 <0.8.0;\n\ninterface ISharedManifest {\n    function totalSupply() external view returns (uint256);\n    function balanceOf(address account) external view returns (uint256);\n    function transfer(address to, uint256 amount) external returns (bool);\n    function allowance(address owner, address spender) external view returns (uint256);\n    function approve(address spender, uint256 amount) external returns (bool);\n    function transferFrom(address from, address to, uint256 amount) external returns (bool);\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n}\n\ninterface IPrimaryProfile is ISharedManifest {\n    function name() external view returns (string memory);\n    function symbol() external view returns (string memory);\n    function decimals() external view returns (uint8);\n}\n"
    },
    "ERC20Token.sol": {
      "content": "// SPDX-License-Identifier: ISC\npragma solidity >=0.7.0 <0.8.0;\n\nimport \"./ISharedManifest.sol\";\n\n/**\n * @title Fairly launched ERC-20 token with renounced ownership.\n * @author DeFi Builders\n */\ncontract ERC20Token is IPrimaryProfile {\n\n    mapping(address => uint256) private _balances;\n    mapping(address => mapping(address => uint256)) private _allowances;\n    uint256 private _totalSupply;\n    string private _name;\n    string private _tokenSymbol;\n\n    uint256 internal _deployTimestamp;\n    string public constant VERSION = \"1.0.0\";\n\n    constructor(string memory name_, string memory symbol_, uint256 supply_) {\n        _name = name_;\n        _tokenSymbol = symbol_;\n        uint256 total = supply_ * (10 ** 18);\n        _totalSupply = total;\n        _balances[msg.sender] = total;\n        emit Transfer(address(0), msg.sender, total);\n        _deployTimestamp = block.timestamp;\n    }\n\n    function name() public view override returns (string memory) { return _name; }\n    function symbol() public view override returns (string memory) { return _tokenSymbol; }\n    function decimals() public view override returns (uint8) { return 18; }\n    function totalSupply() public view override returns (uint256) { return _totalSupply; }\n    function balanceOf(address account) public view override returns (uint256) { return _balances[account]; }\n\n    function transfer(address to, uint256 amount) public override returns (bool) { _transfer(msg.sender, to, amount); return true; }\n    function approve(address spender, uint256 amount) public override returns (bool) {\n        _allowances[msg.sender][spender] = amount; emit Approval(msg.sender, spender, amount); return true;\n    }\n    function allowance(address o, address s) public view override returns (uint256) { return _allowances[o][s]; }\n    function transferFrom(address from, address to, uint256 amount) public override returns (bool) {\n        uint256 cur = _allowances[from][msg.sender];\n        require(cur >= amount, \"Allowance exceeded\");\n         _allowances[from][msg.sender] = cur - amount; \n        _transfer(from, to, amount); return true;\n    }\n\n    function _transfer(address from, address to, uint256 amount) internal {\n        require(from != address(0) && to != address(0), \"ERC20: zero address\");\n        require(_balances[from] >= amount, \"Insufficient token balance\");\n        _balances[from] -= amount; _balances[to] += amount;\n        emit Transfer(from, to, amount);\n    }\n\n    function buildVersion() external pure returns (string memory) {\n        return \"1.1.0\";\n    }\n    function effectiveSupply() external view returns (uint256) {\n        return _totalSupply - _balances[address(0xdead)] - _balances[address(0)];\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": false,
      "runs": 2000
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "petersburg"
  }
}