// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/*
    ====================================================
                          $slowly
    ====================================================

         "slowly, then all at once"

    ====================================================

    LIMITS (PERMANENT, NEVER LIFT):
        Max TX:     0.10%  forever
        Max Wallet: 0.50%  forever

    Total Supply: 10,000
*/

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function allowance(address, address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

contract slowly is IERC20 {
    string public constant name     = "then all at once";
    string public constant symbol   = "slowly";
    uint8  public constant decimals = 18;
    uint256 public constant totalSupply = 10_000 * 1e18;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    // ============= OWNERSHIP =============
    address public owner;
    event OwnershipRenounced(address indexed previousOwner);
    error NotOwner();
    modifier onlyOwner() { if (msg.sender != owner) revert NotOwner(); _; }

    // ============= LIMITS (PERMANENT) =============
    // 0.10% of 10,000 = 10 tokens
    uint256 public constant MAX_TX     = (totalSupply * 10) / 10_000;
    // 0.50% of 10,000 = 50 tokens
    uint256 public constant MAX_WALLET = (totalSupply * 50) / 10_000;

    // ============= CONSTRUCTOR =============
    constructor() {
        owner = msg.sender;
        balanceOf[msg.sender] = totalSupply;
        emit Transfer(address(0), msg.sender, totalSupply);
    }

    // ============= ERC20 =============
    function transfer(address to, uint256 amount) external returns (bool) {
        return _send(msg.sender, to, amount);
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 a = allowance[from][msg.sender];
        if (a != type(uint256).max) {
            require(a >= amount, "allowance");
            unchecked { allowance[from][msg.sender] = a - amount; }
        }
        return _send(from, to, amount);
    }

    function _send(address from, address to, uint256 amount) internal returns (bool) {
        require(to != address(0), "zero to");
        require(balanceOf[from] >= amount, "balance");

        // Owner-originated traffic exempt so LP add via Uniswap UI works.
        // Once renounce() is called, owner == 0 and limits apply to everyone.
        if (tx.origin != owner) {
            require(amount <= MAX_TX, "max tx");
            require(balanceOf[to] + amount <= MAX_WALLET, "max wallet");
        }

        unchecked {
            balanceOf[from] -= amount;
            balanceOf[to]   += amount;
        }
        emit Transfer(from, to, amount);
        return true;
    }

    // ============= RENOUNCE =============
    function renounce() external onlyOwner {
        address prev = owner;
        owner = address(0);
        emit OwnershipRenounced(prev);
    }
}