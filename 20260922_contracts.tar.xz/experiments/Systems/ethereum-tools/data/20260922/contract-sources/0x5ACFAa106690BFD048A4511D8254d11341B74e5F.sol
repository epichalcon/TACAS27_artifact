// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * SVReserveOracle V2.1
 * Multi-currency portfolio reserve oracle for Sovereigns token suite
 * Vector Zulu LLC — St. Kitts and Nevis
 *
 * Architecture:
 * - Single USD reserve backs all SV tokens across all currencies
 * - Chainlink FX feeds convert each currency liability to USD equivalent
 * - Total portfolio adequacy check: reserve >= total USD liability * (1 + buffer)
 * - Timelock on oracle changes: 48 hour delay
 * - Boolean isAdequate() is the primary interface for all SV token mint gates
 *
 * Reserve threshold: USD 10,000,000,000 (10 billion minimum)
 * Overcollateralization buffer: 10%
 * Staleness limit: 2 hours
 * Oracle change timelock: 48 hours
 */

interface IChainlinkFeed {
    function latestRoundData() external view returns (
        uint80 roundId,
        int256 answer,
        uint256 startedAt,
        uint256 updatedAt,
        uint80 answeredInRound
    );
    function decimals() external view returns (uint8);
}

interface ISVToken {
    function totalSupply() external view returns (uint256);
    function decimals() external view returns (uint8);
}

contract SVReserveOracle {

    // ── Constants ─────────────────────────────────────────────────────────────
    uint256 public constant VERSION          = 21;
    uint256 public constant MAX_STALENESS    = 7200;      // 2 hours
    uint256 public constant ORACLE_TIMELOCK  = 172800;    // 48 hours
    uint256 public constant MIN_RESERVE_USD  = 10_000_000_000; // $10B
    uint256 public constant BUFFER_BPS       = 1000;      // 10% overcollateral
    uint256 public constant BPS_BASE         = 10000;
    uint8   public constant RESERVE_DECIMALS = 8;

    string  public constant description = "Vector Zulu Multi-Currency Portfolio Reserve Oracle";

    // ── State ─────────────────────────────────────────────────────────────────
    address public owner;
    address public oracle;

    // Pending oracle change (timelock)
    address public pendingOracle;
    uint256 public pendingOracleAt;

    // Reserve balance (submitted by oracle, 8 decimals)
    int256  public reserveBalance;
    uint256 public reserveUpdatedAt;
    uint80  public latestRoundId;

    // Registered SV tokens with their Chainlink FX feeds
    struct TokenConfig {
        address token;          // SV token contract address
        address chainlinkFeed;  // Chainlink USD price feed (e.g. GBP/USD)
        string  symbol;         // e.g. "SVGBP"
        bool    active;
    }

    mapping(address => TokenConfig) public tokenConfigs;
    address[] public registeredTokens;

    // ── Events ────────────────────────────────────────────────────────────────
    event ReserveUpdated(int256 balance, uint256 updatedAt, uint256 roundId);
    event TokenRegistered(address indexed token, address indexed feed, string symbol);
    event TokenDeactivated(address indexed token);
    event OracleChangeProposed(address indexed proposed, uint256 effectiveAt);
    event OracleChanged(address indexed oldOracle, address indexed newOracle);
    event AdequacyChanged(bool adequate, uint256 totalLiabilityUSD, int256 reserveUSD);

    // ── Modifiers ─────────────────────────────────────────────────────────────
    modifier onlyOwner()  { require(msg.sender == owner,                          "Not owner");  _; }
    modifier onlyOracle() { require(msg.sender == oracle || msg.sender == owner,  "Not oracle"); _; }

    // ── Constructor ───────────────────────────────────────────────────────────
    constructor(address _oracle) {
        owner  = msg.sender;
        oracle = _oracle;
    }

    // ── Oracle write ──────────────────────────────────────────────────────────

    /**
     * @notice Submit updated vault balance from KoreNet via Chainlink EA
     * @param balance Raw USD vault balance with 8 decimal places
     *                e.g. $49,918,000,000 = 4991800000000000000
     */
    function transmit(int256 balance) external onlyOracle {
        bool wasAdequate = _isAdequateInternal();

        latestRoundId++;
        reserveBalance    = balance;
        reserveUpdatedAt  = block.timestamp;

        emit ReserveUpdated(balance, block.timestamp, latestRoundId);

        bool nowAdequate = _isAdequateInternal();
        if (wasAdequate != nowAdequate) {
            emit AdequacyChanged(nowAdequate, _totalLiabilityUSD(), balance);
        }
    }

    // ── Primary interface ─────────────────────────────────────────────────────

    /**
     * @notice Returns true if USD reserve covers total SV token liability
     *         with 10% overcollateralization buffer and fresh data.
     *         All SV token mint gates call this before minting.
     */
    function isAdequate() external view returns (bool) {
        return _isAdequateInternal();
    }

    /**
     * @notice Full reserve status for auditors and counterparties
     */
    function reserveStatus() external view returns (
        bool    adequate,
        int256  reserveUSD,
        uint256 totalLiabilityUSD,
        uint256 availableUSD,
        uint256 utilizationBPS,
        uint256 lastUpdated,
        uint256 ageSeconds,
        uint256 tokenCount
    ) {
        uint256 liability = _totalLiabilityUSD();
        int256  reserve   = reserveBalance;
        bool    adq       = _isAdequateInternal();
        uint256 available = reserve > 0 && uint256(reserve) / 1e8 > liability
            ? uint256(reserve) / 1e8 - liability : 0;
        uint256 util      = liability > 0 && reserve > 0
            ? (liability * BPS_BASE) / (uint256(reserve) / 1e8) : 0;

        return (
            adq,
            reserve,
            liability,
            available,
            util,
            reserveUpdatedAt,
            block.timestamp - reserveUpdatedAt,
            registeredTokens.length
        );
    }

    /**
     * @notice Per-token liability breakdown in USD
     */
    function tokenLiabilities() external view returns (
        string[]  memory symbols,
        uint256[] memory liabilitiesUSD,
        uint256[] memory supplies,
        int256[]  memory fxRates
    ) {
        uint256 count = registeredTokens.length;
        symbols        = new string[](count);
        liabilitiesUSD = new uint256[](count);
        supplies       = new uint256[](count);
        fxRates        = new int256[](count);

        for (uint256 i = 0; i < count; i++) {
            address t = registeredTokens[i];
            TokenConfig memory cfg = tokenConfigs[t];
            if (!cfg.active) continue;

            uint256 supply  = ISVToken(t).totalSupply();
            uint8   dec     = ISVToken(t).decimals();
            (int256 rate, ) = _getFXRate(cfg.chainlinkFeed);

            uint256 liabilityUSD = _tokenLiabilityUSD(supply, dec, rate, cfg.chainlinkFeed);

            symbols[i]        = cfg.symbol;
            liabilitiesUSD[i] = liabilityUSD;
            supplies[i]       = supply;
            fxRates[i]        = rate;
        }
    }

    // ── Internal reserve math ─────────────────────────────────────────────────

    function _isAdequateInternal() internal view returns (bool) {
        if (reserveUpdatedAt == 0) return false;
        if (block.timestamp - reserveUpdatedAt > MAX_STALENESS) return false;
        if (reserveBalance <= 0) return false;

        uint256 reserveUSD  = uint256(reserveBalance) / 1e8;
        if (reserveUSD < MIN_RESERVE_USD) return false;

        uint256 liability   = _totalLiabilityUSD();
        uint256 required    = liability + (liability * BUFFER_BPS / BPS_BASE);

        return reserveUSD >= required;
    }

    function _totalLiabilityUSD() internal view returns (uint256 total) {
        for (uint256 i = 0; i < registeredTokens.length; i++) {
            address t = registeredTokens[i];
            TokenConfig memory cfg = tokenConfigs[t];
            if (!cfg.active) continue;

            uint256 supply  = ISVToken(t).totalSupply();
            uint8   dec     = ISVToken(t).decimals();
            (int256 rate, ) = _getFXRate(cfg.chainlinkFeed);

            total += _tokenLiabilityUSD(supply, dec, rate, cfg.chainlinkFeed);
        }
    }

    function _tokenLiabilityUSD(
        uint256 supply,
        uint8   tokenDecimals,
        int256  fxRate,
        address feed
    ) internal view returns (uint256) {
        if (supply == 0 || fxRate <= 0) return 0;

        uint8 feedDecimals = IChainlinkFeed(feed).decimals();

        // Convert supply to base units, multiply by FX rate, normalize
        // supply / 10^tokenDecimals * fxRate / 10^feedDecimals = USD value
        uint256 supplyBase = supply / (10 ** tokenDecimals);
        uint256 usdValue   = supplyBase * uint256(fxRate) / (10 ** feedDecimals);

        return usdValue;
    }

    function _getFXRate(address feed) internal view returns (int256 rate, uint256 updatedAt) {
        if (feed == address(0)) {
            // USD token — rate is 1.0 with 8 decimals
            return (1e8, block.timestamp);
        }
        (, rate, , updatedAt, ) = IChainlinkFeed(feed).latestRoundData();
        require(block.timestamp - updatedAt <= MAX_STALENESS, "FX feed stale");
        require(rate > 0, "Invalid FX rate");
    }

    // ── Token registry ────────────────────────────────────────────────────────

    /**
     * @notice Register an SV token with its Chainlink FX feed
     * @param token SV token contract address
     * @param feed  Chainlink price feed (address(0) for USD-denominated tokens)
     * @param symbol Human readable symbol e.g. "SVGBP"
     */
    function registerToken(address token, address feed, string calldata symbol)
        external onlyOwner
    {
        require(token != address(0), "Zero address");
        require(!tokenConfigs[token].active, "Already registered");

        tokenConfigs[token] = TokenConfig({
            token:        token,
            chainlinkFeed: feed,
            symbol:       symbol,
            active:       true
        });
        registeredTokens.push(token);

        emit TokenRegistered(token, feed, symbol);
    }

    function deactivateToken(address token) external onlyOwner {
        require(tokenConfigs[token].active, "Not active");
        tokenConfigs[token].active = false;
        emit TokenDeactivated(token);
    }

    // ── Timelock oracle change ────────────────────────────────────────────────

    function proposeOracle(address _oracle) external onlyOwner {
        require(_oracle != address(0), "Zero address");
        pendingOracle   = _oracle;
        pendingOracleAt = block.timestamp + ORACLE_TIMELOCK;
        emit OracleChangeProposed(_oracle, pendingOracleAt);
    }

    function executeOracleChange() external onlyOwner {
        require(pendingOracle != address(0), "No pending change");
        require(block.timestamp >= pendingOracleAt, "Timelock active");
        address old = oracle;
        oracle        = pendingOracle;
        pendingOracle = address(0);
        emit OracleChanged(old, oracle);
    }

    function cancelOracleChange() external onlyOwner {
        pendingOracle   = address(0);
        pendingOracleAt = 0;
    }

    // ── Chainlink AggregatorV3 compatibility ──────────────────────────────────

    function latestRoundData() external view returns (
        uint80, int256, uint256, uint256, uint80
    ) {
        return (latestRoundId, reserveBalance, reserveUpdatedAt, reserveUpdatedAt, latestRoundId);
    }

    function latestAnswer()    external view returns (int256)  { return reserveBalance; }
    function latestTimestamp() external view returns (uint256) { return reserveUpdatedAt; }
    function decimals()        external pure returns (uint8)   { return RESERVE_DECIMALS; }

    // ── Admin ─────────────────────────────────────────────────────────────────
    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Zero address");
        owner = newOwner;
    }
}