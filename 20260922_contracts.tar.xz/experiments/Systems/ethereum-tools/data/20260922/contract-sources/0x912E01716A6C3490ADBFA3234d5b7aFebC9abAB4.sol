// SPDX-License-Identifier: MIT
pragma solidity ^0.8.34;

contract RAREArtStorage {
    address public owner;
    bool public isLocked;
    string[] private _snippets;

    constructor() {
        owner = msg.sender;
    }

    function addArt(string calldata snippet) external {
        require(msg.sender == owner && !isLocked);
        _snippets.push(snippet);
    }

    function lock() external {
        require(msg.sender == owner && !isLocked);
        isLocked = true;
    }

    function transferOwnership(address newOwner) external {
        require(msg.sender == owner && newOwner != address(0));
        owner = newOwner;
    }

    function rareArt() external view returns (string memory) {
        bytes memory fullImage;
        uint256 len = _snippets.length;
        for (uint256 i = 0; i < len;) {
            fullImage = bytes.concat(fullImage, bytes(_snippets[i]));
            unchecked { ++i; }
        }
        return string(fullImage);
    }
}