{
  "language": "Solidity",
  "sources": {
    "src/osm/medians.sol": {
      "content": "// SPDX-License-Identifier: AGPL-3.0-or-later\npragma solidity ^0.6.12;\n\nimport \"./median.sol\";\n\ncontract MedianETHUSD is Median {\n    function wat() public pure override returns (bytes32) {\n        return \"ETHUSD\";\n    }\n}\n"
    },
    "src/osm/median.sol": {
      "content": "// SPDX-License-Identifier: AGPL-3.0-or-later\n\n/// median.sol\n\n// Copyright (C) 2017-2020 Maker Ecosystem Growth Holdings, INC.\n\n// This program is free software: you can redistribute it and/or modify\n// it under the terms of the GNU Affero General Public License as published by\n// the Free Software Foundation, either version 3 of the License, or\n// (at your option) any later version.\n//\n// This program is distributed in the hope that it will be useful,\n// but WITHOUT ANY WARRANTY; without even the implied warranty of\n// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n// GNU Affero General Public License for more details.\n//\n// You should have received a copy of the GNU Affero General Public License\n// along with this program.  If not, see <https://www.gnu.org/licenses/>.\n\npragma solidity ^0.6.12;\n\nimport \"./interfaces/IDSValue.sol\";\n\ncontract Median {\n\n    // --- Auth ---\n    mapping (address => uint) public wards;\n    function rely(address usr) external auth { wards[usr] = 1; emit Rely(usr); }\n    function deny(address usr) external auth { wards[usr] = 0; emit Deny(usr); }\n    modifier auth {\n        require(wards[msg.sender] == 1, \"Median/not-authorized\");\n        _;\n    }\n\n    // --- Event ---\n    event Rely(address usr);\n    event Deny(address usr);\n    event LogMedianPrice(uint256 val, uint256 age);\n    event Lift(address[] a);\n    event Drop(address[] a);\n    event SetBar(uint256 bar);\n    event Kiss(address a);\n    event Diss(address a);\n    event Kiss(address[] a);\n    event Diss(address[] a);\n    event SetDeviation(uint256 deviation);\n    event SetMainOracle(address oracle);\n\n    uint128        val;\n    uint32  public age;\n    // bytes32 public constant wat = \"ethusd\"; // You want to change this every deploy\n    uint256 public bar = 1;\n\n    // Authorized oracles, set by an auth\n    mapping (address => uint256) public orcl;\n\n    // Whitelisted contracts, set by an auth\n    mapping (address => uint256) public bud;\n\n    // Mapping for at most 256 oracles\n    mapping (uint8 => address) public slot;\n    uint8 public orclCount;\n\n    // main oracle\n    address public mainOrcl;\n\n    // max deviation (10% = 1000 bps default)\n    uint256 public deviation = 1000;\n\n    modifier toll { require(bud[msg.sender] == 1, \"Median/contract-not-whitelisted\"); _;}\n\n    //Set type of Oracle\n    constructor() public {\n        wards[msg.sender] = 1;\n    }\n\n    // You want to change this every deploy\n    function wat() public pure virtual returns (bytes32) {\n        return \"ethusd\";\n    }\n\n    function read() external view toll returns (uint256) {\n        require(val > 0, \"Median/invalid-price-feed\");\n        return val;\n    }\n\n    function peek() external view toll returns (uint256,bool) {\n        return (val, val > 0);\n    }\n\n    function setMainOrcl(address oracle) external auth {\n        require(oracle != address(0), \"Median/no-oracle-0\");\n        require(orcl[oracle] == 1, \"Median/not-authorized-oracle\");\n        mainOrcl = oracle;\n        emit SetMainOracle(oracle);\n    }\n\n    function setDeviation(uint256 deviation_) external auth {\n        require(deviation_ > 0, \"Median/deviation-is-zero\");\n        require(deviation_ <= 10000, \"Median/deviation-too-high\"); // max 100%\n        deviation = deviation_;\n        emit SetDeviation(deviation_);\n    }\n\n    function poke() external {\n        require(mainOrcl != address(0), \"Median/no-main-oracle\");\n        \n        // Get main oracle price\n        (bytes32 mainPriceBytes, bool mainValid) = IDSValue(mainOrcl).peek();\n        require(mainValid, \"Median/main-oracle-invalid\");\n        uint256 mainPrice = uint256(mainPriceBytes);\n        require(mainPrice > 0, \"Median/main-price-zero\");\n\n        uint256 validCount = 1; // Start with 1 for main oracle\n        \n        // Check all registered oracles\n        for (uint8 i = 0; i < orclCount; i++) {\n            address oracle = slot[i];\n            if (oracle == address(0) || oracle == mainOrcl) continue;\n            \n            // Get price from oracle\n            (bytes32 priceBytes, bool valid) = IDSValue(oracle).peek();\n            if (!valid) continue;\n            \n            uint256 price = uint256(priceBytes);\n            if (price == 0) continue;\n\n            // Check price deviation using basis points\n            uint256 maxDeviation = mainPrice * deviation / 10000;\n            uint256 diff = price > mainPrice ? \n                price - mainPrice : mainPrice - price;\n            if (diff > maxDeviation) continue;\n\n            validCount++;\n        }\n\n        // Ensure we have enough valid prices\n        require(validCount >= bar, \"Median/insufficient-valid-prices\");\n\n        // Set main oracle's price as the result\n        val = uint128(mainPrice);\n        age = uint32(block.timestamp);\n\n        emit LogMedianPrice(val, age);\n    }\n\n    // Set price from selected oracle\n    function pokeOracle(address oracle) external auth {\n        require(oracle != address(0), \"Median/no-oracle\");\n        require(orcl[oracle] == 1, \"Median/not-authorized-oracle\");\n        (bytes32 priceBytes, bool isValid) = IDSValue(oracle).peek();\n        uint256 price = uint256(priceBytes);\n        require(price > 0, \"Median/main-price-zero\");\n        \n        // Set oracle's price as the result\n        val = uint128(price);\n        age = uint32(block.timestamp);\n\n        emit LogMedianPrice(val, age);\n    }\n\n    function lift(address[] calldata a) external auth {\n        require(orclCount + a.length <= 255, \"median/oracle-limit-reached\");\n        for (uint i = 0; i < a.length; i++) {\n            require(a[i] != address(0), \"Median/no-oracle-0\");\n            require(orcl[a[i]] == 0, \"Median/signer-already-exists\");\n            orcl[a[i]] = 1;\n            slot[orclCount] = a[i];\n            orclCount++;\n        }\n        emit Lift(a);\n    }\n\n    function drop(address[] calldata a) external auth {\n       for (uint i = 0; i < a.length; i++) {\n            require(orcl[a[i]] == 1, \"Median/oracle-not-exists\");\n            orcl[a[i]] = 0;\n            if (mainOrcl == a[i]) {\n                mainOrcl = address(0);\n            }\n            // Find and remove from slot\n            for (uint8 j = 0; j < orclCount; j++) {\n                if (slot[j] == a[i]) {\n                    slot[j] = slot[orclCount - 1];\n                    slot[orclCount - 1] = address(0);\n                    orclCount--;\n                    break;\n                }\n            }\n        }\n        emit Drop(a);\n    }\n\n    function setBar(uint256 bar_) external auth {\n        require(bar_ > 0, \"Median/quorum-is-zero\");\n        bar = bar_;\n        emit SetBar(bar_);\n    }\n\n    function kiss(address a) external auth {\n        require(a != address(0), \"Median/no-contract-0\");\n        bud[a] = 1;\n        emit Kiss(a);\n    }\n\n    function diss(address a) external auth {\n        bud[a] = 0;\n        emit Diss(a);\n    }\n\n    function kiss(address[] calldata a) external auth {\n        for(uint i = 0; i < a.length; i++) {\n            require(a[i] != address(0), \"Median/no-contract-0\");\n            bud[a[i]] = 1;\n        }\n        emit Kiss(a);\n    }\n\n    function diss(address[] calldata a) external auth {\n        for(uint i = 0; i < a.length; i++) {\n            bud[a[i]] = 0;\n        }\n        emit Diss(a);\n    }\n}"
    },
    "src/osm/interfaces/IDSValue.sol": {
      "content": "// SPDX-License-Identifier: MIT\n\npragma solidity ^0.6.12;\n\ninterface IDSValue {\n    function peek() external view returns (bytes32, bool);\n    function read() external view returns (bytes32);\n}\n"
    }
  },
  "settings": {
    "remappings": [
      "ds-test/=lib/ds-auth/lib/ds-test/src/",
      "ds-thing/=lib/ds-value/lib/ds-thing/src/",
      "ds-value/=lib/ds-value/src/",
      "forge-std/=lib/forge-std/src/",
      "psm/=lib/psm/src/",
      "ds-token/=lib/ds-token/src/",
      "ds-auth/=lib/ds-auth/src/",
      "erc4626-tests/=lib/erc4626-tests/",
      "@openzeppelin/contracts/=lib/openzeppelin-contracts/contracts/",
      "ds-math/=lib/ds-token/lib/ds-math/src/",
      "ds-note/=lib/ds-value/lib/ds-thing/lib/ds-note/src/",
      "halmos-cheatcodes/=lib/openzeppelin-contracts/lib/halmos-cheatcodes/src/",
      "openzeppelin-contracts/=lib/openzeppelin-contracts/",
      "usddv2/=lib/psm/lib/usddv2/"
    ],
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "metadata": {
      "useLiteralContent": false,
      "bytecodeHash": "ipfs"
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "istanbul"
  }
}