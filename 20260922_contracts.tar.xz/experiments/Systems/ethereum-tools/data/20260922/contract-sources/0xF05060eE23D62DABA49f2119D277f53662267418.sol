// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract THRReward {
    uint8 public constant decimals = 18;

    uint8 public constant MIN_VALID_DAYS = 30;
    uint8 public constant MAX_VALID_DAYS = 40;

    uint256 private constant DAY = 1 days;

    string public constant name = "USDTher";
    string public constant symbol = "THR";

    address public owner;

    uint256 public totalSupply;

    mapping(address => uint256) private _balances;

    mapping(address => mapping(address => uint256))
        private _allowances;

    /*
     * Jika true:
     * - token pada address tersebut tidak dianggap expired
     * - expiredBalanceOf() = 0
     * - spendableBalanceOf() = seluruh balance
     */
    mapping(address => bool) public expiryExempt;

    /*
     * Setiap token yang dimint / dipindahkan tetap
     * mempunyai RewardBatch.
     */
    mapping(address => RewardBatch[])
        private _rewardBatches;

    struct RewardBatch {
        uint128 amount;
        uint64 expiresAt;
        bool burned;
    }

    event Transfer(
        address indexed from,
        address indexed to,
        uint256 value
    );

    event Approval(
        address indexed tokenOwner,
        address indexed spender,
        uint256 value
    );

    event OwnershipTransferred(
        address indexed oldOwner,
        address indexed newOwner
    );

    event RewardMinted(
        address indexed to,
        uint256 amount,
        uint256 expiresAt
    );

    event ExpiredBurned(
        address indexed account,
        uint256 amount
    );

    event ExpiryExemptSet(
        address indexed account,
        bool exempt
    );

    modifier onlyOwner() {
        require(
            msg.sender == owner,
            "not owner"
        );

        _;
    }

    constructor() {
        owner = msg.sender;

        emit OwnershipTransferred(
            address(0),
            msg.sender
        );
    }

    // =============================================================
    // ERC20 BASIC
    // =============================================================

    function balanceOf(
        address account
    )
        public
        view
        returns (uint256)
    {
        return _balances[account];
    }

    function allowance(
        address tokenOwner,
        address spender
    )
        public
        view
        returns (uint256)
    {
        return _allowances[tokenOwner][spender];
    }

    function approve(
        address spender,
        uint256 amount
    )
        public
        returns (bool)
    {
        require(
            spender != address(0),
            "zero address"
        );

        _allowances[msg.sender][spender] =
            amount;

        emit Approval(
            msg.sender,
            spender,
            amount
        );

        return true;
    }

    function transfer(
        address to,
        uint256 amount
    )
        public
        returns (bool)
    {
        _transfer(
            msg.sender,
            to,
            amount
        );

        return true;
    }

    function transferFrom(
        address from,
        address to,
        uint256 amount
    )
        public
        returns (bool)
    {
        uint256 allowed =
            _allowances[from][msg.sender];

        require(
            allowed >= amount,
            "allowance too low"
        );

        if (
            allowed !=
            type(uint256).max
        ) {
            _allowances[from][msg.sender] =
                allowed - amount;

            emit Approval(
                from,
                msg.sender,
                _allowances[from][msg.sender]
            );
        }

        _transfer(
            from,
            to,
            amount
        );

        return true;
    }

    // =============================================================
    // REWARD BATCH INFORMATION
    // =============================================================

    function rewardBatchCount(
        address account
    )
        public
        view
        returns (uint256)
    {
        return _rewardBatches[account].length;
    }

    function rewardBatch(
        address account,
        uint256 index
    )
        public
        view
        returns (
            uint256 amount,
            uint256 expiresAt,
            bool burned
        )
    {
        RewardBatch memory batch =
            _rewardBatches[account][index];

        return (
            batch.amount,
            batch.expiresAt,
            batch.burned
        );
    }

    // =============================================================
    // EXPIRY INFORMATION
    // =============================================================

    function expiredBalanceOf(
        address account
    )
        public
        view
        returns (uint256 expired)
    {
        /*
         * Exempt address tidak mempunyai
         * saldo expired.
         */
        if (expiryExempt[account]) {
            return 0;
        }

        RewardBatch[] storage batches =
            _rewardBatches[account];

        for (
            uint256 i = 0;
            i < batches.length;
            i++
        ) {
            RewardBatch storage batch =
                batches[i];

            if (
                !batch.burned &&
                batch.amount > 0 &&
                batch.expiresAt <= block.timestamp
            ) {
                expired += batch.amount;
            }
        }
    }

    function spendableBalanceOf(
        address account
    )
        public
        view
        returns (uint256)
    {
        /*
         * Exempt:
         * seluruh balance dapat digunakan.
         */
        if (expiryExempt[account]) {
            return _balances[account];
        }

        uint256 balance =
            _balances[account];

        uint256 expired =
            expiredBalanceOf(account);

        if (expired >= balance) {
            return 0;
        }

        return balance - expired;
    }

    // =============================================================
    // MINT
    // =============================================================

    function mintReward(
        address to,
        uint256 amount,
        uint8 validDays
    )
        public
        onlyOwner
        returns (bool)
    {
        require(
            to != address(0),
            "zero address"
        );

        require(
            amount > 0,
            "zero amount"
        );

        require(
            validDays >= MIN_VALID_DAYS &&
            validDays <= MAX_VALID_DAYS,
            "valid days 30-40"
        );

        require(
            amount <= type(uint128).max,
            "amount too large"
        );

        uint256 expiresAt =
            block.timestamp +
            uint256(validDays) *
            DAY;

        require(
            expiresAt <= type(uint64).max,
            "expiry too large"
        );

        _balances[to] += amount;

        totalSupply += amount;

        _rewardBatches[to].push(
            RewardBatch({
                amount: uint128(amount),
                expiresAt: uint64(expiresAt),
                burned: false
            })
        );

        /*
         * ERC20 mint event.
         */
        emit Transfer(
            address(0),
            to,
            amount
        );

        emit RewardMinted(
            to,
            amount,
            expiresAt
        );

        return true;
    }

    // =============================================================
    // BURN EXPIRED
    // =============================================================

    function burnExpired(
        address account
    )
        public
        returns (uint256 burned)
    {
        require(
            account != address(0),
            "zero address"
        );

        /*
         * Exempt address tidak mempunyai
         * token yang harus dibakar karena expiry.
         */
        if (expiryExempt[account]) {
            return 0;
        }

        RewardBatch[] storage batches =
            _rewardBatches[account];

        for (
            uint256 i = 0;
            i < batches.length;
            i++
        ) {
            RewardBatch storage batch =
                batches[i];

            if (
                !batch.burned &&
                batch.amount > 0 &&
                batch.expiresAt <= block.timestamp
            ) {
                burned += batch.amount;

                /*
                 * Tandai batch sebagai burned.
                 */
                batch.burned = true;

                /*
                 * amount dibuat 0 supaya
                 * tidak dihitung kembali.
                 */
                batch.amount = 0;
            }
        }

        if (burned > 0) {
            require(
                burned <= _balances[account],
                "burn exceeds balance"
            );

            _balances[account] -= burned;

            totalSupply -= burned;

            emit Transfer(
                account,
                address(0),
                burned
            );

            emit ExpiredBurned(
                account,
                burned
            );
        }
    }

    // =============================================================
    // EXPIRY EXEMPT
    // =============================================================

    function setExpiryExempt(
        address account,
        bool exempt
    )
        public
        onlyOwner
    {
        require(
            account != address(0),
            "zero address"
        );

        expiryExempt[account] =
            exempt;

        emit ExpiryExemptSet(
            account,
            exempt
        );
    }

    // =============================================================
    // OWNERSHIP
    // =============================================================

    function transferOwnership(
        address newOwner
    )
        public
        onlyOwner
    {
        require(
            newOwner != address(0),
            "zero address"
        );

        address oldOwner = owner;

        owner = newOwner;

        emit OwnershipTransferred(
            oldOwner,
            newOwner
        );
    }

    // =============================================================
    // INTERNAL TRANSFER
    // =============================================================

    function _transfer(
        address from,
        address to,
        uint256 amount
    )
        private
    {
        require(
            from != address(0),
            "zero address"
        );

        require(
            to != address(0),
            "zero address"
        );

        require(
            amount > 0,
            "zero amount"
        );

        /*
         * Hanya saldo yang belum expired
         * yang boleh ditransfer.
         *
         * Jika from adalah expiryExempt,
         * seluruh balance dianggap spendable.
         */
        require(
            spendableBalanceOf(from) >= amount,
            "expired or low balance"
        );

        require(
            _balances[from] >= amount,
            "low balance"
        );

        _balances[from] -= amount;

        _balances[to] += amount;

        /*
         * Pindahkan expiry information
         * bersama token.
         */
        _moveBatches(
            from,
            to,
            amount
        );

        emit Transfer(
            from,
            to,
            amount
        );
    }

    // =============================================================
    // MOVE REWARD BATCHES
    // =============================================================

    function _moveBatches(
        address from,
        address to,
        uint256 amount
    )
        private
    {
        uint256 remaining = amount;

        RewardBatch[] storage fromBatches =
            _rewardBatches[from];

        /*
         * Kita menggunakan batch dari yang
         * paling awal terlebih dahulu.
         *
         * Ini membuat sistem bekerja seperti FIFO.
         */
        for (
            uint256 i = 0;
            i < fromBatches.length &&
            remaining > 0;
            i++
        ) {
            RewardBatch storage batch =
                fromBatches[i];

            /*
             * Batch burned / kosong dilewati.
             */
            if (
                batch.burned ||
                batch.amount == 0
            ) {
                continue;
            }

            /*
             * Jika from TIDAK exempt,
             * batch expired tidak boleh
             * dipindahkan.
             *
             * spendableBalanceOf() sebelumnya
             * juga sudah memastikan total
             * amount yang dipindahkan masih valid.
             */
            if (
                !expiryExempt[from] &&
                batch.expiresAt <= block.timestamp
            ) {
                continue;
            }

            uint128 moved;

            if (
                uint256(batch.amount) >
                remaining
            ) {
                moved =
                    uint128(remaining);
            } else {
                moved =
                    batch.amount;
            }

            /*
             * Kurangi batch pengirim.
             */
            batch.amount -= moved;

            /*
             * Kurangi amount yang masih
             * harus dipindahkan.
             */
            remaining -= moved;

            /*
             * PENTING:
             *
             * RewardBatch SELALU dibuat
             * untuk penerima.
             *
             * expiryExempt tidak lagi
             * menghilangkan pencatatan batch.
             */
            _rewardBatches[to].push(
                RewardBatch({
                    amount: moved,
                    expiresAt: batch.expiresAt,
                    burned: false
                })
            );
        }

        /*
         * Ini merupakan safety check.
         *
         * Kalau accounting batch tidak
         * sesuai dengan balance, transaksi
         * akan revert.
         */
        require(
            remaining == 0,
            "batch accounting error"
        );
    }
}