// Launch bundler: in ONE transaction, add liquidity and do the creator's first
// buy, so no sniper can trade between the two. Atomic, any failure reverts the
// whole call, so funds can never be stranded.
//
// Tokens go straight from the creator to the pair (the creator is the token owner,
// so they're fee/limit-exempt) and the bundler mints the LP to the creator. The
// bundler never holds the tokens, so the token's max-wallet/max-tx limits are never
// hit. The creator only has to approve this bundler for the LP token amount.
//
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

interface IToken {
    function swapPair() external view returns (address);
    function swapRouterAddress() external view returns (address);
}

interface IWETH {
    function deposit() external payable;
    function transfer(address to, uint256 value) external returns (bool);
}

interface IPair {
    function mint(address to) external returns (uint256 liquidity);
}

interface IV2Router {
    function WETH() external pure returns (address);
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint256 amountOutMin, address[] calldata path, address to, uint256 deadline
    ) external payable;
}

contract ListpadLaunchBundler {
    bool private locked;
    modifier nonReentrant() { require(!locked, "reentrant"); locked = true; _; locked = false; }

    event Launched(address indexed token, address indexed creator, uint256 lpTokens, uint256 lpEth, uint256 buyEth);

    // msg.value = ETH for liquidity + ETH for the first buy.
    // Prerequisite (the UI handles it): token.approve(thisBundler, tokenAmountForLp).
    function launch(
        address token,
        address router,
        uint256 tokenAmountForLp,
        uint256 buyEth,
        uint256 minTokensOut
    ) external payable nonReentrant {
        require(token != address(0) && router != address(0), "addr");
        require(tokenAmountForLp > 0, "lp tokens");
        require(msg.value > buyEth, "value<=buy");
        uint256 lpEth = msg.value - buyEth;
        require(lpEth > 0, "no lp eth");

        // Baseline balances BEFORE this call moves anything, so the refund
        // below can be scoped to only what THIS call leaves over. Previously
        // the refund swept the contract's entire balance, so stray funds
        // sent here by mistake (the open receive() accepts from anyone) got
        // handed to whoever happened to call launch() next, not the person
        // who sent them, and not necessarily recoverable by anyone at all.
        uint256 tokenBaseline = IERC20(token).balanceOf(address(this));
        uint256 ethBaseline = address(this).balance - msg.value;

        address weth = IV2Router(router).WETH();
        address pair = IToken(token).swapPair();
        require(pair != address(0), "no pair");
        // A router mismatch only ever risks the caller's own funds (this
        // whole call only moves funds the caller themselves supplied), never
        // a third party's, but it's a cheap check and it turns a confusing
        // silent failure into a clear one.
        require(router == IToken(token).swapRouterAddress(), "wrong router for this token");

        // Move the creator's tokens straight to the pair. Because the creator (owner)
        // is fee/limit-exempt in the token, this is untaxed and not limit-checked.
        require(IERC20(token).transferFrom(msg.sender, pair, tokenAmountForLp), "transferFrom");

        // Wrap the liquidity ETH, send it to the pair, and mint the LP to the creator.
        IWETH(weth).deposit{ value: lpEth }();
        require(IWETH(weth).transfer(pair, lpEth), "weth");
        IPair(pair).mint(msg.sender);

        // Creator's first buy in the same tx, bought tokens go to the creator.
        if (buyEth > 0) {
            address[] memory path = new address[](2);
            path[0] = weth;
            path[1] = token;
            IV2Router(router).swapExactETHForTokensSupportingFeeOnTransferTokens{ value: buyEth }(
                minTokensOut, path, msg.sender, block.timestamp + 600
            );
        }

        // Refund only what THIS call added beyond its own starting baseline,
        // any pre-existing stray balance is left untouched rather than being
        // swept to this caller.
        uint256 tokenNow = IERC20(token).balanceOf(address(this));
        if (tokenNow > tokenBaseline) {
            require(IERC20(token).transfer(msg.sender, tokenNow - tokenBaseline), "token refund");
        }
        uint256 ethNow = address(this).balance;
        if (ethNow > ethBaseline) {
            (bool ok, ) = payable(msg.sender).call{ value: ethNow - ethBaseline }("");
            require(ok, "refund");
        }

        emit Launched(token, msg.sender, tokenAmountForLp, lpEth, buyEth);
    }

    receive() external payable {}
}