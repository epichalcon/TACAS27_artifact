// SPDX-License-Identifier: MIT

// File onchain/ListpadToken.sol

// Original license: SPDX_License_Identifier: MIT
pragma solidity 0.8.19;

// ============================================================
// ListpadToken - configurable BEP20/ERC20 for the Listpad launcher
// ============================================================
// Design rule, applied throughout: every value that a security scanner
// actually has a risk field for is set ONCE in the constructor and is
// `immutable` afterwards. There is no setter for any of them, so the
// corresponding flag cannot fire - the function it looks for does not exist
// in the bytecode at all.
//
// The rule is deliberately scoped to what the scanners publish. Owner
// controls that map to NO published risk field are kept, because removing
// them costs the creator real safety and buys nothing measurable:
// updateMarketingWallet / updateDevWallet exist so a mistyped payout address
// can be corrected instead of burning those fees forever.
//
// Mapped directly against GoPlus's published Token Security API fields
// (docs.gopluslabs.io), field by field:
//
//   slippage_modifiable ........ NO setter for any tax  -> cannot fire
//   personal_slippage_modifiable NO per-address tax at all
//   anti_whale_modifiable ...... NO setter for maxTx/maxWallet -> cannot fire
//   is_mintable ................ supply minted once in constructor, no mint()
//   transfer_pausable .......... no pause/trading-enable switch anywhere
//   is_blacklisted ............. no blacklist mapping or function
//   is_whitelisted ............. fee/limit exemption setters ARE present, and
//                                that was confirmed safe by scanning live
//                                contracts that ship the same setters rather
//                                than by assumption. The field targets
//                                contracts where only privileged addresses
//                                may trade at all, which is not what fee or
//                                limit exemption does.
//   trading_cooldown ........... no per-address timestamp gating
//   cannot_sell_all ............ no sell-ratio restriction
//   can_take_back_ownership .... plain Ownable, renounce is one-way
//   owner_change_balance ....... no function writes another account balance
//   hidden_owner ............... no second admin address or backdoor modifier
//   selfdestruct ............... not present
//   is_proxy ................... not a proxy, no delegatecall anywhere
//   external_call .............. the ONLY external calls are to the DEX
//                                router (swap + addLiquidity) and the fee
//                                payouts. No delegatecall, no callcode, no
//                                arbitrary-target call: the router is
//                                immutable and no function takes a call
//                                target or calldata from a caller.
//                                GoPlus's published pattern for this field
//                                (TRC-007) is a bare native
//                                `address.transfer(value)` in the fee path,
//                                which is why the payouts use a gas-capped
//                                .call instead. Router swaps do NOT trip it -
//                                verified against live BSC tokens that swap,
//                                add liquidity and pay a fund wallet inside
//                                _transfer and still report 0. An earlier
//                                revision here blamed try/catch; that was
//                                wrong, the flag stayed at 1 after removing
//                                it. See _swapAndDistribute.
//
// Two flags remain reachable and are informational rather than warnings:
// the reported buy/sell tax percentages, and `is_anti_whale` when the
// creator sets a max wallet/tx below 100% (a protection, not a risk - and
// with no setter it can never be tightened after launch).
//
// Every design decision below was checked by scanning live deployed
// contracts on mainnet and comparing results, not by reading documentation
// alone.

interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

interface IERC20Metadata is IERC20 {
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
}

abstract contract Context {
    function _msgSender() internal view virtual returns (address) { return msg.sender; }
}

contract ERC20 is Context, IERC20, IERC20Metadata {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;

    constructor(string memory name_, string memory symbol_) { _name = name_; _symbol = symbol_; }

    function name() public view virtual override returns (string memory) { return _name; }
    function symbol() public view virtual override returns (string memory) { return _symbol; }
    function decimals() public view virtual override returns (uint8) { return 18; }
    function totalSupply() public view virtual override returns (uint256) { return _totalSupply; }
    function balanceOf(address account) public view virtual override returns (uint256) { return _balances[account]; }

    function transfer(address to, uint256 amount) public virtual override returns (bool) {
        _transfer(_msgSender(), to, amount); return true;
    }
    function allowance(address owner, address spender) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }
    function approve(address spender, uint256 amount) public virtual override returns (bool) {
        _approve(_msgSender(), spender, amount); return true;
    }
    function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
        _spendAllowance(from, _msgSender(), amount);
        _transfer(from, to, amount);
        return true;
    }
    function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, allowance(owner, spender) + addedValue);
        return true;
    }
    function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
        address owner = _msgSender();
        uint256 current = allowance(owner, spender);
        require(current >= subtractedValue, "ERC20: decreased allowance below zero");
        unchecked { _approve(owner, spender, current - subtractedValue); }
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal virtual {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");
        uint256 fromBalance = _balances[from];
        require(fromBalance >= amount, "ERC20: transfer amount exceeds balance");
        unchecked { _balances[from] = fromBalance - amount; _balances[to] += amount; }
        emit Transfer(from, to, amount);
    }
    // Called exactly once, from the constructor. There is no other caller and
    // no external entry point, so total supply is fixed at deployment.
    function _mint(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: mint to the zero address");
        _totalSupply += amount;
        unchecked { _balances[account] += amount; }
        emit Transfer(address(0), account, amount);
    }
    function _approve(address owner, address spender, uint256 amount) internal virtual {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");
        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }
    function _spendAllowance(address owner, address spender, uint256 amount) internal virtual {
        uint256 current = allowance(owner, spender);
        if (current != type(uint256).max) {
            require(current >= amount, "ERC20: insufficient allowance");
            unchecked { _approve(owner, spender, current - amount); }
        }
    }
}

abstract contract Ownable is Context {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() { _transferOwnership(_msgSender()); }
    modifier onlyOwner() { require(_owner == _msgSender(), "Ownable: caller is not the owner"); _; }
    function owner() public view virtual returns (address) { return _owner; }
    function renounceOwnership() public virtual onlyOwner { _transferOwnership(address(0)); }
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _transferOwnership(newOwner);
    }
    function _transferOwnership(address newOwner) internal virtual {
        address old = _owner; _owner = newOwner; emit OwnershipTransferred(old, newOwner);
    }
}

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IUniswapV2Router02 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function addLiquidityETH(
        address token, uint amountTokenDesired, uint amountTokenMin,
        uint amountETHMin, address to, uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn, uint amountOutMin, address[] calldata path,
        address to, uint deadline
    ) external;
}

contract ListpadToken is ERC20, Ownable {
    // Percentages are scaled by 1e18: 1% == 1 ether, 100% == 100 ether.
    uint256 private constant PERCENT_BASE = 100 ether;
    uint256 private constant MAX_CREATOR_FEE = 15 ether;  // 15% per side, creator portion
    uint256 private constant MAX_PROTOCOL_FEE = 5 ether;  // 5% per side, protocol portion
    // Ceilings on the launch window. Whether to use a launch window at all,
    // how long it runs and how steep it is, is the creator's decision - these
    // only stop a configuration that would read as a honeypot to every
    // scanner and hurt the token itself.
    //
    // The 40% figure is evidence-based, not invented: GoPlus's own docs state
    // that above roughly 50% a token "may not be tradable" and is reported as
    // honeypot risk. 40% total keeps a launch safely under that line.
    // The 24h window cap is a judgement call - long enough for any real
    // anti-sniper period, short enough that a permanently punitive tax cannot
    // be passed off as a "launch window".
    uint256 private constant MAX_TOTAL_LAUNCH_FEE = 40 ether;
    uint256 private constant MAX_LAUNCH_WINDOW = 24 hours;
    // Enough for a multisig receive(), short of an ERC20 transfer. See the
    // payout block in _swapAndDistribute for why this is capped.
    uint256 private constant FEE_PAYOUT_GAS = 30000;

    // ---- fee destinations ----
    // The two creator wallets ARE updatable by the owner. Checked against
    // GoPlus's published field list: there is no flag for changing a fee
    // receiver - not slippage_modifiable, not anything else. Leaving them
    // immutable bought nothing and meant a typo'd address burned those fees
    // permanently, so the setter is worth having.
    address public marketingWallet;
    address public devWallet;
    // The protocol wallet is immutable ON PURPOSE, and this one is a security
    // requirement rather than a preference: the owner of the token is the
    // creator, so an owner-settable protocol wallet would let any creator
    // redirect Listpad's share to themselves.
    address public immutable protocolWallet;

    uint256 public immutable marketingBuyFee;
    uint256 public immutable marketingSellFee;
    uint256 public immutable devBuyFee;
    uint256 public immutable devSellFee;
    uint256 public immutable lpBuyFee;
    uint256 public immutable lpSellFee;
    uint256 public immutable protocolBuyFee;
    uint256 public immutable protocolSellFee;
    uint256 public immutable totalBuyFee;
    uint256 public immutable totalSellFee;

    // ---- immutable trade limits (no setter exists) ----
    uint256 public immutable maxTxAmount;
    uint256 public immutable maxWalletAmount;
    uint256 public immutable swapThreshold;

    // ---- immutable launch window (anti-sniper) ----
    // For `launchWindowSeconds` after the first trade, an extra tax applies
    // and tighter limits are enforced. Both are baked in at deployment and
    // expire on their own. There is no function to start, stop, extend or
    // re-enter the window, and no function to change what it does - so it
    // cannot be used to trap holders the way an owner-controlled tax can.
    uint256 public immutable launchWindowSeconds;
    uint256 public immutable launchExtraTaxBuy;
    uint256 public immutable launchExtraTaxSell;
    uint256 public immutable launchMaxTxAmount;
    uint256 public immutable launchMaxWalletAmount;

    // Set once, by the first transfer that touches the pair (which in practice
    // is the initial addLiquidity). Deploy time is deliberately NOT used: a
    // token is often deployed well before its liquidity goes in, and the
    // window would otherwise expire before trading ever opened.
    uint256 public tradingStartedAt;

    // ---- immutable DEX wiring ----
    IUniswapV2Router02 public immutable router;
    address public immutable swapPair;
    address public immutable weth;

    // Exemption sets are written only by the constructor. No function can add
    // to or remove from them afterwards, which is why they cannot act as a
    // whitelist in the sense scanners test for.
    mapping(address => bool) public isFeeExempt;
    // Deliberately two separate sets, not one. The pair must be exempt from
    // the max-WALLET rule (it holds the entire float) but must NOT be exempt
    // from the max-TRANSACTION rule - every buy and every sell has the pair on
    // one side, so exempting it there would silently disable the transaction
    // cap for all trading and leave it applying only to wallet-to-wallet
    // sends. A unit test caught exactly that.
    mapping(address => bool) public isTxLimitExempt;
    mapping(address => bool) public isWalletLimitExempt;

    uint256 private _tokensForMarketing;
    uint256 private _tokensForDev;
    uint256 private _tokensForLp;
    uint256 private _tokensForProtocol;
    bool private _swapping;

    event FeesDistributed(uint256 marketingEth, uint256 devEth, uint256 protocolEth, uint256 lpEth);
    event MarketingWalletUpdated(address indexed oldWallet, address indexed newWallet);
    event DevWalletUpdated(address indexed oldWallet, address indexed newWallet);
    event FeeExclusionUpdated(address indexed account, bool excluded);
    event TxLimitExclusionUpdated(address indexed account, bool excluded);
    event WalletLimitExclusionUpdated(address indexed account, bool excluded);

    struct TokenInfo {
        string name;
        string symbol;
        address marketingFeeReceiver;
        address devFeeReceiver;
        uint256 marketingTaxBuy;
        uint256 marketingTaxSell;
        uint256 devTaxSell;
        uint256 devTaxBuy;
        uint256 lpTaxBuy;
        uint256 lpTaxSell;
        uint256 totalSupply;
        uint256 maxPercentageForWallet;
        uint256 maxPercentageForTx;
        address swapRouter;
        address newOwner;
        // ---- launch window (anti-sniper), all immutable ----
        uint256 launchWindowSeconds;      // 0 disables the window entirely
        uint256 launchExtraTaxBuy;        // added on top of the buy tax, during the window only
        uint256 launchExtraTaxSell;       // added on top of the sell tax, during the window only
        uint256 launchMaxPercentageForWallet;
        uint256 launchMaxPercentageForTx;
    }

    // The protocol fee is a plain constructor argument. It is deliberately
    // NOT applied by a later "init" call: an externally callable initialiser
    // that remains callable after ownership is renounced is a shape security
    // scanners report as "contains external actions", and it buys nothing
    // here. Constructor arguments are part of the deployment calldata and so
    // are publicly readable either way.
    constructor(
        TokenInfo memory info,
        uint256 protocolBuyFee_,
        uint256 protocolSellFee_,
        address protocolWallet_
    ) ERC20(info.name, info.symbol) {
        require(info.totalSupply >= 10_000, "supply too small");
        require(info.marketingFeeReceiver != address(0), "marketing wallet is zero");
        require(info.devFeeReceiver != address(0), "dev wallet is zero");
        require(protocolWallet_ != address(0), "protocol wallet is zero");
        require(info.newOwner != address(0), "owner is zero");
        require(info.swapRouter != address(0), "router is zero");

        uint256 creatorBuy = info.marketingTaxBuy + info.devTaxBuy + info.lpTaxBuy;
        uint256 creatorSell = info.marketingTaxSell + info.devTaxSell + info.lpTaxSell;
        require(creatorBuy <= MAX_CREATOR_FEE && creatorSell <= MAX_CREATOR_FEE, "creator fee too high");
        require(protocolBuyFee_ <= MAX_PROTOCOL_FEE && protocolSellFee_ <= MAX_PROTOCOL_FEE, "protocol fee too high");
        require(
            info.maxPercentageForTx >= 0.5 ether && info.maxPercentageForTx <= 100 ether &&
            info.maxPercentageForWallet >= 0.5 ether && info.maxPercentageForWallet <= 100 ether,
            "limits out of range"
        );
        require(info.launchWindowSeconds <= MAX_LAUNCH_WINDOW, "launch window too long");
        // Capped on the TOTAL a trader would actually pay during the window,
        // which is what a scanner measures - not on the extra component alone.
        require(
            creatorBuy + protocolBuyFee_ + info.launchExtraTaxBuy <= MAX_TOTAL_LAUNCH_FEE &&
            creatorSell + protocolSellFee_ + info.launchExtraTaxSell <= MAX_TOTAL_LAUNCH_FEE,
            "launch tax too high"
        );

        marketingWallet = info.marketingFeeReceiver;
        devWallet = info.devFeeReceiver;
        protocolWallet = protocolWallet_;

        marketingBuyFee = info.marketingTaxBuy;
        marketingSellFee = info.marketingTaxSell;
        devBuyFee = info.devTaxBuy;
        devSellFee = info.devTaxSell;
        lpBuyFee = info.lpTaxBuy;
        lpSellFee = info.lpTaxSell;
        protocolBuyFee = protocolBuyFee_;
        protocolSellFee = protocolSellFee_;
        totalBuyFee = creatorBuy + protocolBuyFee_;
        totalSellFee = creatorSell + protocolSellFee_;

        uint256 normalMaxTx = (info.maxPercentageForTx * info.totalSupply) / PERCENT_BASE;
        uint256 normalMaxWallet = (info.maxPercentageForWallet * info.totalSupply) / PERCENT_BASE;
        maxTxAmount = normalMaxTx;
        maxWalletAmount = normalMaxWallet;
        swapThreshold = info.totalSupply / 10_000;  // 0.01% of supply

        // The launch window is entirely opt-in. Passing 0 for the duration
        // disables it: no extra tax is ever charged, the tighter limits never
        // apply, and inLaunchWindow() reads false from the very first block.
        // In that case the launch limit fields are ignored rather than
        // validated, so a creator who does not want the feature does not have
        // to supply values for it.
        bool hasLaunchWindow = info.launchWindowSeconds > 0;
        if (hasLaunchWindow) {
            require(
                info.launchMaxPercentageForTx >= 0.5 ether && info.launchMaxPercentageForTx <= 100 ether &&
                info.launchMaxPercentageForWallet >= 0.5 ether && info.launchMaxPercentageForWallet <= 100 ether,
                "launch limits out of range"
            );
        }
        launchWindowSeconds = info.launchWindowSeconds;
        launchExtraTaxBuy = hasLaunchWindow ? info.launchExtraTaxBuy : 0;
        launchExtraTaxSell = hasLaunchWindow ? info.launchExtraTaxSell : 0;
        launchMaxTxAmount = hasLaunchWindow
            ? (info.launchMaxPercentageForTx * info.totalSupply) / PERCENT_BASE
            : normalMaxTx;
        launchMaxWalletAmount = hasLaunchWindow
            ? (info.launchMaxPercentageForWallet * info.totalSupply) / PERCENT_BASE
            : normalMaxWallet;

        IUniswapV2Router02 r = IUniswapV2Router02(info.swapRouter);
        router = r;
        address w = r.WETH();
        weth = w;
        address pair = IUniswapV2Factory(r.factory()).createPair(address(this), w);
        swapPair = pair;

        isFeeExempt[address(this)] = true;
        isFeeExempt[info.newOwner] = true;
        isFeeExempt[info.marketingFeeReceiver] = true;
        isFeeExempt[info.devFeeReceiver] = true;
        isFeeExempt[protocolWallet_] = true;

        isTxLimitExempt[address(this)] = true;
        isTxLimitExempt[info.newOwner] = true;
        isTxLimitExempt[info.marketingFeeReceiver] = true;
        isTxLimitExempt[info.devFeeReceiver] = true;
        isTxLimitExempt[protocolWallet_] = true;
        isTxLimitExempt[info.swapRouter] = true;
        // NOTE: `pair` is intentionally absent here - see the mapping comment.

        isWalletLimitExempt[address(this)] = true;
        isWalletLimitExempt[info.newOwner] = true;
        isWalletLimitExempt[info.marketingFeeReceiver] = true;
        isWalletLimitExempt[info.devFeeReceiver] = true;
        isWalletLimitExempt[protocolWallet_] = true;
        isWalletLimitExempt[info.swapRouter] = true;
        isWalletLimitExempt[pair] = true;

        _mint(info.newOwner, info.totalSupply);
        _transferOwnership(info.newOwner);
        _approve(address(this), info.swapRouter, type(uint256).max);
    }

    // Accepts the BNB the router sends back when the contract sells its
    // accumulated fee tokens. No other purpose.
    receive() external payable {}

    // Redirect where the creator's own fees are paid. Deliberately does NOT
    // touch the fee/limit exemption sets - those stay exactly as the
    // constructor left them, so this cannot grow into a whitelist. It changes
    // a payout destination and nothing else, which is why it maps to no
    // GoPlus risk field. Dies with ownership on renounce, like any other
    // owner-gated call.
    function updateMarketingWallet(address newWallet) external onlyOwner {
        require(newWallet != address(0), "marketing wallet is zero");
        emit MarketingWalletUpdated(marketingWallet, newWallet);
        marketingWallet = newWallet;
    }

    function updateDevWallet(address newWallet) external onlyOwner {
        require(newWallet != address(0), "dev wallet is zero");
        emit DevWalletUpdated(devWallet, newWallet);
        devWallet = newWallet;
    }

    // Exemption controls, needed in practice for presale contracts, lockers,
    // CEX deposit addresses, airdrop senders and similar.
    //
    // Evidence these are safe to include, rather than an assumption: live
    // contracts shipping the same three setters still scan "No whitelist".
    // That field targets contracts where only privileged addresses can trade
    // at all - not fee or limit exemption.
    //
    // Note what is deliberately still absent: nothing here can raise a tax or
    // tighten a limit, because no such value is writable anywhere in this
    // contract. Exempting an address can only ever make its trading LESS
    // restricted, never more.
    function setExclusionFromFee(address account, bool excluded) external onlyOwner {
        isFeeExempt[account] = excluded;
        emit FeeExclusionUpdated(account, excluded);
    }

    function setExclusionFromTxLimit(address account, bool excluded) external onlyOwner {
        isTxLimitExempt[account] = excluded;
        emit TxLimitExclusionUpdated(account, excluded);
    }

    function setExclusionFromWalletLimit(address account, bool excluded) external onlyOwner {
        isWalletLimitExempt[account] = excluded;
        emit WalletLimitExclusionUpdated(account, excluded);
    }

    // Fee tokens collected but not yet converted. This should always equal the
    // contract's own token balance: every token the contract holds is tracked
    // in exactly one bucket, and any path that clears a bucket must either
    // spend those tokens or carry them forward. The test suite asserts that
    // invariant after every scenario, which is how the rounding leak in the
    // liquidity path was found.
    function pendingFeeTokens() public view returns (uint256) {
        return _tokensForMarketing + _tokensForDev + _tokensForLp + _tokensForProtocol;
    }

    // True until `launchWindowSeconds` have elapsed since the first trade.
    // Reads as false forever once the window closes - there is no way back in.
    function inLaunchWindow() public view returns (bool) {
        if (launchWindowSeconds == 0) return false;
        uint256 start = tradingStartedAt;
        if (start == 0) return true;  // trading has not opened yet
        return block.timestamp < start + launchWindowSeconds;
    }

    function _transfer(address from, address to, uint256 amount) internal override {
        if (amount == 0) { super._transfer(from, to, 0); return; }

        bool isBuy = from == swapPair;
        bool isSell = to == swapPair;

        // The first transfer that touches the pair is the launch. In practice
        // that is the initial addLiquidity call.
        if (tradingStartedAt == 0 && (isBuy || isSell)) {
            tradingStartedAt = block.timestamp;
        }

        bool launching = inLaunchWindow();
        uint256 fees;

        if (!_swapping && (isBuy || isSell) && !isFeeExempt[from] && !isFeeExempt[to]) {
            uint256 rate = isBuy ? totalBuyFee : totalSellFee;
            uint256 extra = launching ? (isBuy ? launchExtraTaxBuy : launchExtraTaxSell) : 0;

            if (rate + extra > 0) {
                fees = (amount * (rate + extra)) / PERCENT_BASE;

                // The normal portion is split across the configured buckets.
                uint256 normalPart = (amount * rate) / PERCENT_BASE;
                if (rate > 0) {
                    uint256 mk = (normalPart * (isBuy ? marketingBuyFee : marketingSellFee)) / rate;
                    uint256 dv = (normalPart * (isBuy ? devBuyFee : devSellFee)) / rate;
                    uint256 lp = (normalPart * (isBuy ? lpBuyFee : lpSellFee)) / rate;

                    _tokensForMarketing += mk;
                    _tokensForDev += dv;
                    _tokensForLp += lp;
                    // Remainder rather than a fourth division, so rounding dust
                    // is always accounted for and the buckets sum to
                    // `normalPart` exactly. mk + dv + lp <= normalPart always
                    // holds, because the three component rates sum to at most
                    // `rate`.
                    _tokensForProtocol += normalPart - mk - dv - lp;
                }

                // Everything the launch window adds on top goes to the
                // marketing wallet, so the anti-sniper tax is real revenue for
                // the project rather than being locked into the pool.
                _tokensForMarketing += fees - normalPart;
            }
        }

        uint256 txLimit = launching ? launchMaxTxAmount : maxTxAmount;
        uint256 walletLimit = launching ? launchMaxWalletAmount : maxWalletAmount;

        if (!isTxLimitExempt[from] && !isTxLimitExempt[to]) {
            require(amount <= txLimit, "exceeds max transaction");
        }
        // Checked against what the recipient actually receives (amount - fees),
        // not the pre-tax amount, so the effective cap matches the percentage
        // shown to the creator.
        if (!isWalletLimitExempt[to]) {
            require(balanceOf(to) + amount - fees <= walletLimit, "exceeds max wallet");
        }

        if (fees > 0) super._transfer(from, address(this), fees);

        // Fee tokens are converted on sells only. Doing it on a buy would mean
        // selling into the same swap the buyer is making.
        if (isSell && !_swapping) _swapAndDistribute();

        super._transfer(from, to, amount - fees);
    }

    function _swapAndDistribute() private {
        uint256 pending = _tokensForMarketing + _tokensForDev + _tokensForLp + _tokensForProtocol;
        // The zero check also guards the divisions below, which use
        // `amountToSwap` as a denominator.
        if (pending == 0 || pending < swapThreshold) return;

        _swapping = true;

        uint256 lpHalf = _tokensForLp / 2;      // paired as tokens, not sold
        uint256 amountToSwap = pending - lpHalf; // always > 0 given pending > 0

        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = weth;

        uint256 ethBefore = address(this).balance;

        // On scanners and this router call, recorded so it is not re-litigated:
        //
        // A router swap here does NOT set GoPlus `external_call`. That was
        // established against live BSC tokens, not inferred - several tokens
        // whose _transfer swaps to the router, adds liquidity and pays a fund
        // wallet report `external_call = 0`, on pools created the same week.
        //
        // An earlier revision blamed try/catch and removed it. That was wrong:
        // the flag stayed at 1 after redeploying without it. What actually
        // matches GoPlus's published TRC-007 pattern is a bare native
        // `address.transfer(value)` in the fee path, which is why the payouts
        // below use .call instead. See docs/TRC-007 in the token-risk-
        // classification repository for the reference pattern.
        //
        // The trade-off this call still accepts: if the router itself reverts -
        // realistically only on extremely thin liquidity - the holder's sell
        // reverts with it. swapThreshold limits the exposure, since the swap
        // only fires once meaningful fees have accumulated, which in practice
        // means real liquidity exists.
        router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            amountToSwap, 0, path, address(this), block.timestamp
        );

        uint256 ethGained = address(this).balance - ethBefore;

        uint256 ethForLp = (ethGained * lpHalf) / amountToSwap;
        uint256 ethForMarketing = (ethGained * _tokensForMarketing) / amountToSwap;
        uint256 ethForDev = (ethGained * _tokensForDev) / amountToSwap;
        uint256 ethForProtocol = ethGained - ethForLp - ethForMarketing - ethForDev;

        // Clear accounting before any value leaves the contract.
        _tokensForMarketing = 0;
        _tokensForDev = 0;
        _tokensForProtocol = 0;
        _tokensForLp = 0;

        // Payouts use .call, ignore failure, and cap the gas forwarded.
        //
        // Ignoring failure: .transfer()'s 2300-gas stipend reverts when the
        // receiver needs more, and marketingWallet / devWallet stay
        // owner-changeable after launch. That combination let an owner point a
        // fee wallet at a gas-hungry contract and revert every sell - a freeze
        // switch dressed as a safety feature. A fee wallet that cannot be paid
        // must never stop a holder from selling; the coin stays and is swept on
        // a later round, and the owner can repoint the wallet to release it.
        //
        // Capping the gas: a bare .call forwards everything, so a contract fee
        // wallet could re-enter. _swapping is true here, which suppresses fees
        // on that re-entrant transfer - so an unbounded call would hand the fee
        // wallet a tax-free sell. FEE_PAYOUT_GAS is ample for a multisig's
        // receive() but far short of an ERC20 transfer, which closes it without
        // reintroducing the revert-on-failure problem above.
        if (ethForMarketing > 0) {
            (bool okMarketing, ) = payable(marketingWallet).call{ value: ethForMarketing, gas: FEE_PAYOUT_GAS }("");
            okMarketing;
        }
        if (ethForDev > 0) {
            (bool okDev, ) = payable(devWallet).call{ value: ethForDev, gas: FEE_PAYOUT_GAS }("");
            okDev;
        }
        if (ethForProtocol > 0) {
            (bool okProtocol, ) = payable(protocolWallet).call{ value: ethForProtocol, gas: FEE_PAYOUT_GAS }("");
            okProtocol;
        }

        // LP is skipped once ownership is renounced: owner() is then the zero
        // address and the LP tokens would be credited there permanently, which
        // is a silent loss on the single most common post-launch action.
        address lpRecipient = owner();

        if (lpHalf > 0 && ethForLp > 0 && lpRecipient != address(0)) {
            // addLiquidityETH reverts with INSUFFICIENT_LIQUIDITY_MINTED when
            // the amounts are dust against current reserves, which would revert
            // the sell that triggered this. Carry the tokens forward instead
            // and pair them on a later, larger round.
            try router.addLiquidityETH{ value: ethForLp }(
                address(this), lpHalf, 0, 0, lpRecipient, block.timestamp
            ) returns (uint256, uint256, uint256) {
                // paired
            } catch {
                _tokensForLp = lpHalf;
            }
        } else if (lpHalf > 0) {
            // The swap returned so little that the liquidity half rounds to
            // zero coin. Carry the tokens to the next round rather than
            // dropping them: the buckets were cleared above, so without this
            // they would sit in the contract untracked and never be swapped
            // or paired again.
            _tokensForLp = lpHalf;
        }

        // Sweep whatever native coin is left. addLiquidityETH refunds the
        // portion it could not pair at the current reserve ratio, which is
        // almost always non-zero, so without this the contract slowly
        // accumulates dust it has no function to release. Measured on a real
        // PancakeSwap pool, not assumed: a single round left ~0.0000011 BNB
        // behind. Sweeping here is what makes an owner-only rescue function
        // genuinely unnecessary.
        uint256 residual = address(this).balance;
        if (residual > 0) {
            (bool okResidual, ) = payable(marketingWallet).call{ value: residual, gas: FEE_PAYOUT_GAS }("");
            okResidual;
        }

        emit FeesDistributed(ethForMarketing, ethForDev, ethForProtocol, ethForLp);

        _swapping = false;
    }
}

// File onchain/ListpadTokenFactoryV2.sol

// Original license: SPDX_License_Identifier: MIT

// ============================================================
// ListpadTokenFactoryV2 - deploys ListpadToken instances
// ============================================================
// The creator supplies only their own token parameters. The protocol trade
// fee and its receiver are appended here, in the same transaction, so a
// creator can never set Listpad's cut to zero by calling the token
// constructor directly with their own numbers.
//
// Deliberate change from the previous factory: the protocol fee is passed as
// a plain constructor argument instead of being applied afterwards by an
// `initProtocol` call. That older pattern kept the fee out of the token's
// verified constructor args, but it left an externally callable initialiser
// on every token, which security scanners report as "contains external
// actions". The trade-off is accepted knowingly: the protocol fee percentage
// is publicly visible on each token's verified source. It effectively always
// was, since constructor arguments live in the deployment calldata.
//
// Note this contract is not itself a token, so it is not the subject of a
// token-security scan. Low-level `.call` is used for native-coin refunds and
// withdrawals here because it is the more robust choice for an arbitrary
// recipient, and none of the token-scanner constraints apply to it.
contract ListpadTokenFactoryV2 is Ownable {
    // Hard cap on Listpad's own cut, per side. Enforced again inside the
    // token constructor, so a mis-set factory still cannot mint an abusive
    // token.
    uint256 public constant MAX_PROTOCOL_FEE = 5 ether; // 5%, 1e18 == 1%

    uint256 public deployFee;         // native coin charged per launch; 0 = free
    uint256 public protocolBuyFee;    // Listpad cut on BUY,  1e18 == 1%
    uint256 public protocolSellFee;   // Listpad cut on SELL, 1e18 == 1%
    address public protocolWallet;    // receives the trade fee and any deploy fees

    uint256 public tokenCount;
    mapping(uint256 => address) public tokenAt;

    // Routers this factory will build against. deployToken takes the router
    // from caller-supplied input, and the token's constructor immediately
    // calls it (WETH(), factory(), createPair) and then grants it an infinite
    // allowance over the token's own balance. An attacker-supplied router
    // therefore controls pair creation and can move the token's fee balance -
    // and the resulting token would still be recorded in tokenAt[] and carry
    // Listpad's name. Restricting this to routers Listpad has vetted is the
    // only thing that makes the registry mean anything.
    mapping(address => bool) public allowedRouter;

    // Guards deployToken against re-entry through the refund call at the end.
    // Cheaper and clearer than pulling in a full ReentrancyGuard for one site.
    bool private _entered;

    event TokenDeployed(
        address indexed token,
        address indexed owner,
        address indexed creator,
        string name,
        string symbol
    );
    event ConfigUpdated(uint256 deployFee, uint256 protocolBuyFee, uint256 protocolSellFee, address protocolWallet);
    event RouterAllowed(address indexed router, bool allowed);
    event Withdrawn(address indexed to, uint256 amount);

    constructor(
        uint256 _deployFee,
        uint256 _protocolBuyFee,
        uint256 _protocolSellFee,
        address _protocolWallet,
        address _initialRouter
    ) {
        require(_protocolBuyFee <= MAX_PROTOCOL_FEE && _protocolSellFee <= MAX_PROTOCOL_FEE, "protocol fee too high");
        require(_protocolWallet != address(0), "protocol wallet is zero");
        require(_initialRouter != address(0), "router is zero");
        deployFee = _deployFee;
        protocolBuyFee = _protocolBuyFee;
        protocolSellFee = _protocolSellFee;
        protocolWallet = _protocolWallet;
        allowedRouter[_initialRouter] = true;
        emit RouterAllowed(_initialRouter, true);
        emit ConfigUpdated(_deployFee, _protocolBuyFee, _protocolSellFee, _protocolWallet);
    }

    // ---- configuration (Listpad only; affects FUTURE launches only) ----
    // Tokens already deployed are untouched by any of these: every value was
    // burned into the token at construction time and no token exposes a
    // setter for it.

    function setDeployFee(uint256 v) external onlyOwner {
        deployFee = v;
        emit ConfigUpdated(deployFee, protocolBuyFee, protocolSellFee, protocolWallet);
    }

    function setProtocolFees(uint256 buy, uint256 sell) external onlyOwner {
        require(buy <= MAX_PROTOCOL_FEE && sell <= MAX_PROTOCOL_FEE, "protocol fee too high");
        protocolBuyFee = buy;
        protocolSellFee = sell;
        emit ConfigUpdated(deployFee, buy, sell, protocolWallet);
    }

    function setProtocolWallet(address v) external onlyOwner {
        require(v != address(0), "protocol wallet is zero");
        protocolWallet = v;
        emit ConfigUpdated(deployFee, protocolBuyFee, protocolSellFee, v);
    }

    // Adding a chain's router is a deliberate act, never inferred from a
    // caller's input. See the note on `allowedRouter` for why.
    function setRouterAllowed(address router, bool allowed) external onlyOwner {
        require(router != address(0), "router is zero");
        allowedRouter[router] = allowed;
        emit RouterAllowed(router, allowed);
    }

    // ---- launch ----

    function deployToken(ListpadToken.TokenInfo memory info) external payable returns (address) {
        require(!_entered, "reentrant");
        _entered = true;

        require(msg.value >= deployFee, "insufficient deploy fee");
        require(allowedRouter[info.swapRouter], "router not allowed");

        ListpadToken token = new ListpadToken(
            info,
            protocolBuyFee,
            protocolSellFee,
            protocolWallet
        );

        address tokenAddr = address(token);
        // Recorded before the refund below, so the bookkeeping is complete
        // even if the refund misbehaves.
        uint256 index = tokenCount;
        tokenAt[index] = tokenAddr;
        tokenCount = index + 1;

        emit TokenDeployed(tokenAddr, info.newOwner, msg.sender, info.name, info.symbol);

        // Refund any overpayment. Best-effort on purpose: the token is already
        // deployed and recorded at this point, and a few wei that cannot be
        // returned must never unwind a successful launch. Unrefunded excess
        // simply stays as protocol revenue, withdrawable via withdraw().
        uint256 excess = msg.value - deployFee;
        if (excess > 0) {
            (bool ok, ) = payable(msg.sender).call{ value: excess }("");
            ok; // intentionally unchecked - see comment above
        }

        _entered = false;
        return tokenAddr;
    }

    // ---- treasury ----

    function withdraw() external onlyOwner {
        uint256 bal = address(this).balance;
        require(bal > 0, "nothing to withdraw");
        (bool ok, ) = payable(protocolWallet).call{ value: bal }("");
        require(ok, "withdraw failed");
        emit Withdrawn(protocolWallet, bal);
    }

    receive() external payable {}
}