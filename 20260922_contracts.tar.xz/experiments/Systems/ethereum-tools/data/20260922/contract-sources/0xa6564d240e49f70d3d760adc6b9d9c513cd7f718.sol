// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
}

interface ITokenMessengerV2 {
    function depositForBurn(
        uint256 amount,
        uint32 destinationDomain,
        bytes32 mintRecipient,
        address burnToken,
        bytes32 destinationCaller,
        uint256 maxFee,
        uint32 minFinalityThreshold
    ) external;
}

contract CctpBridgeForwarder {
    // configurable at deploy
    address public immutable caller1; // only this address can trigger
    address public immutable source2; // token source (must approve this contract)

    // задаются при деплое под конкретную сеть
    address public immutable usdc;
    uint32 public immutable destinationDomain;

    // для Ethereum и Arbitrum сейчас одинаковый
    address public constant TOKEN_MESSENGER = 0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d;

    constructor(
        address _caller1,
        address _source2,
        address _usdc,
        uint32 _destinationDomain
    ) {
        require(_caller1 != address(0), "caller1 zero");
        require(_source2 != address(0), "source2 zero");
        require(_usdc != address(0), "usdc zero");

        caller1 = _caller1;
        source2 = _source2;
        usdc = _usdc;
        destinationDomain = _destinationDomain;
    }

    modifier onlyCaller1() {
        require(msg.sender == caller1, "not caller1");
        _;
    }

    /// @notice Allow receiving ETH directly
    receive() external payable {}
    fallback() external payable {}

    /// @notice Withdraw any ERC20 stuck in this contract to source2
    function withdrawERC20(address _token) external onlyCaller1 {
        require(_token != address(0), "zero");
        uint256 bal = IERC20(_token).balanceOf(address(this));
        require(IERC20(_token).transfer(source2, bal), "transfer failed");
    }

    /// @notice Burn USDC via CCTP (bridge)
    /// @param _amount USDC amount (6 decimals)
    /// @param _fast true = fast transfer, false = slow transfer
    function bridgeUSDC(
        uint256 _amount,
        bool _fast
    ) external onlyCaller1 {
        require(IERC20(usdc).transferFrom(source2, address(this), _amount), "pull failed");

        IERC20(usdc).approve(TOKEN_MESSENGER, _amount);

        uint256 maxFee = _fast ? (_amount + 9_999) / 10_000 : 0;
        uint32  minFinalityThreshold = _fast ? 1_000 : 2_000;

        ITokenMessengerV2(TOKEN_MESSENGER).depositForBurn(
            _amount,
            destinationDomain,
            _addressToBytes32(source2),
            usdc,
            bytes32(0),
            maxFee,
            minFinalityThreshold
        );
    }

    function _addressToBytes32(address a) internal pure returns (bytes32) {
        return bytes32(uint256(uint160(a)));
    }
}