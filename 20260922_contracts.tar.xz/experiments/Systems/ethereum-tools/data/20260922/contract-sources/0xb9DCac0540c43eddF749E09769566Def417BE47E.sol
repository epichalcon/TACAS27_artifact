{
  "language": "Solidity",
  "sources": {
    "IPublicSpec.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.7;\n\ninterface IPublicSpec {\n    function name() external view returns (string memory);\n    function symbol() external view returns (string memory);\n    function decimals() external view returns (uint8);\n    function totalSupply() external view returns (uint256);\n    function balanceOf(address account) external view returns (uint256);\n    function transfer(address to, uint256 amount) external returns (bool);\n    function allowance(address owner, address spender) external view returns (uint256);\n    function approve(address spender, uint256 amount) external returns (bool);\n    function transferFrom(address from, address to, uint256 amount) external returns (bool);\n    event Transfer(address indexed from, address indexed to, uint256 value);\n    event Approval(address indexed owner, address indexed spender, uint256 value);\n}\n"
    },
    "Owned.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.7;\n\n\nabstract contract Owned {\n    address private _owner;\n\n    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);\n\n    constructor(address initialOwner) {\n        require(initialOwner != address(0), \"Cannot use zero address\");\n        _owner = initialOwner;\n        emit OwnershipTransferred(address(0), initialOwner);\n    }\n\n    modifier onlyOwner() { require(msg.sender == _owner, \"Caller is not admin\"); _; }\n    function owner() public view virtual returns (address) { return _owner; }\n\n    function renounceOwnership() public virtual onlyOwner {\n        emit OwnershipTransferred(_owner, address(0)); _owner = address(0);\n    }\n    function transferOwnership(address newOwner) public virtual onlyOwner {\n        require(newOwner != address(0), \"ERC20: zero address\");\n        emit OwnershipTransferred(_owner, newOwner); _owner = newOwner;\n    }\n}\n"
    },
    "CustomRegistry.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.7;\n\nimport \"./IPublicSpec.sol\";\nimport \"./Owned.sol\";\n\n/**\n * @title Lightweight ERC-20 token for ecosystem use.\n * @author Chain Devs\n */\ncontract CustomRegistry is IPublicSpec, Owned {\n\n    mapping(address => uint256) private _balance;\n    mapping(address => mapping(address => uint256)) private _approvals;\n    uint256 private _totalSupply;\n    string private _name;\n    string private _tag;\n\n    uint256 internal _deployBlock;\n    uint256 internal _deployTimestamp;\n    event Deployed(string name, string symbol, uint256 supply);\n\n    constructor(string memory name_, string memory symbol_, uint256 supply_) Owned(msg.sender) {\n        _name = name_;\n        _tag = symbol_;\n        uint256 total = supply_ * (10 ** 18);\n        _totalSupply = total;\n        _balance[msg.sender] = total;\n        emit Transfer(address(0), msg.sender, total);\n        _deployBlock = block.number;\n        _deployTimestamp = block.timestamp;\n        emit Deployed(name_, symbol_, supply_);\n        renounceOwnership();\n    }\n\n    function name() public view override returns (string memory) { return _name; }\n    function symbol() public view override returns (string memory) { return _tag; }\n    function decimals() public pure override returns (uint8) { return 18; }\n    function totalSupply() public view override returns (uint256) { return _totalSupply; }\n    function balanceOf(address account) public view override returns (uint256) { return _balance[account]; }\n\n    function transfer(address to, uint256 amount) public override returns (bool) { _transfer(msg.sender, to, amount); return true; }\n    function approve(address spender, uint256 amount) public override returns (bool) {\n        _approvals[msg.sender][spender] = amount; emit Approval(msg.sender, spender, amount); return true;\n    }\n    function allowance(address o, address s) public view override returns (uint256) { return _approvals[o][s]; }\n    function transferFrom(address from, address to, uint256 amount) public override returns (bool) {\n        uint256 cur = _approvals[from][msg.sender];\n        require(cur >= amount, \"ERC20: insufficient allowance\");\n        unchecked { _approvals[from][msg.sender] = cur - amount; }\n        _transfer(from, to, amount); return true;\n    }\n\n    function _transfer(address from, address to, uint256 amount) internal {\n        require(from != address(0) && to != address(0), \"ERC20: to the zero address\");\n        require(_balance[from] >= amount, \"Cannot transfer: low balance\");\n        _balance[from] -= amount; _balance[to] += amount;\n        emit Transfer(from, to, amount);\n    }\n\n    function destroy(uint256 amount) external {\n        _transfer(msg.sender, address(0xdead), amount);\n    }\n    function info() external view returns (string memory, string memory, uint256) {\n        return (name(), symbol(), totalSupply());\n    }\n}\n"
    }
  },
  "settings": {
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    },
    "evmVersion": "berlin"
  }
}