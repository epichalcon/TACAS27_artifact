// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

interface WnsAddressesInterface {
    function owner() external view returns (address);
    function getWnsAddress(string memory _label) external view returns (address);
}

interface WnsERC721Interface {
    function ownerOf(uint256 tokenId) external view returns (address owner);
    function totalSupply() external view returns (uint256);
}

interface WnsResolverInterface {
    function resolveTokenId(uint256 _tokenId) external view returns (string memory);

}

contract SimpleResolver {
    WnsAddressesInterface wnsAddresses;

    constructor(address addresses_) {
        wnsAddresses = WnsAddressesInterface(addresses_);
    }

    function setAddresses(address addresses_) public {
        require(msg.sender == wnsAddresses.owner(), "Not authorized.");
        wnsAddresses = WnsAddressesInterface(addresses_);
    }

    function supportsInterface(bytes4 interfaceID) public pure returns (bool) {
        return true;
    }

    function addr(bytes32 node) public view returns (address) {
        int256 tokenId = findTokenId(node);

        if(tokenId != -1) {
            WnsERC721Interface wnsErc721 =  WnsERC721Interface(wnsAddresses.getWnsAddress("_wnsErc721"));
            return wnsErc721.ownerOf(uint256(tokenId));
        } else {
            return address(0);
        }
        
    }

    function name(bytes32 node) public pure returns (string memory) {
        return "";
    }

    function ABI(bytes32 node, uint256 contentTypes) public pure returns (uint256 contentType, bytes memory data) {
        data = "";
        contentType = 0;
    }

    function pubkey(bytes32 node) public pure returns (bytes32 x, bytes32 y) {
        return ("","");
    }

    function text(bytes32 node, string memory key) public pure returns (string memory text) {
        return "";
    }

    function content(bytes32 node) public pure returns (bytes32 ret) {
        return "";
    }

    function findTokenId(bytes32 node) public view returns (int256) {
        WnsERC721Interface wnsErc721 =  WnsERC721Interface(wnsAddresses.getWnsAddress("_wnsErc721"));
        int256 totalSupply = int256(wnsErc721.totalSupply());

        int256 found = -1;
        for(int256 i=0; i < totalSupply; i++) {
            WnsResolverInterface wnsResolver =  WnsResolverInterface(wnsAddresses.getWnsAddress("_wnsResolver"));
            string memory _name = wnsResolver.resolveTokenId(uint256(i));
            string memory label = extractSubdomain(_name);

            if(computeNamehash(label) == node) {
                found = i;
                break;
            }
        }

        return found;
    }

    function extractSubdomain(string memory domain) public pure returns (string memory) {
        bytes memory domainBytes = bytes(domain);
        uint256 pos = 0;
        for (uint256 i = 0; i < domainBytes.length; i++) {
            if (domainBytes[i] == ".") {
                pos = i;
                break;
            }
        }
        
        bytes memory resultBytes = new bytes(pos);
        for (uint256 i = 0; i < pos; i++) {
            resultBytes[i] = domainBytes[i];
        }
        
        return string(resultBytes);
    }

    function computeNamehash(string memory _name) public pure returns (bytes32 namehash) {
        namehash = 0x0000000000000000000000000000000000000000000000000000000000000000;
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked('red')))
        );
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked('web3')))
        );
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked(_name)))
        );
    }
}