// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
interface IERC20 {
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    function transfer(address recipient, uint256 amount) external returns (bool);
}
contract Treasury404 {
    address public admin;
    mapping(address => bool) public whitelistedTokens;
    mapping(address => uint256) public tokenBalances;

    event TokenDeposit(address token, uint256 amount);
    event TokenWithdrawal(address token, uint256 amount);
    event NewAdmin(address admin);

    modifier onlyAdmin() {
        require(msg.sender == admin, "Only admin can perform this action");
        _;
    }

    constructor() {
        admin = msg.sender;
    }

    function whitelistToken(address _token) external onlyAdmin {
        whitelistedTokens[_token] = true;
    }

    function removeTokenFromWhitelist(address _token) external onlyAdmin {
        whitelistedTokens[_token] = false;
    }

    function depositToken(address _token, uint256 _amount) external {
        require(whitelistedTokens[_token], "Token not whitelisted");
        require(IERC20(_token).transferFrom(msg.sender, address(this), _amount), "Transfer failed");
        tokenBalances[_token] += _amount;
        emit TokenDeposit(_token, _amount);
    }

    function withdrawToken(address _token, uint256 _amount) external onlyAdmin {
        require(tokenBalances[_token] >= _amount, "Insufficient balance");
        tokenBalances[_token] -= _amount;
        require(IERC20(_token).transfer(msg.sender, _amount), "Transfer failed");
        emit TokenWithdrawal(_token, _amount);
    }

    function changeAdmin(address _newAdmin) external onlyAdmin {
        admin = _newAdmin;
        emit NewAdmin(_newAdmin);
    }
}

interface IERC20Metadata is IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function allowance(address owner, address spender) external view returns (uint256);
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
}

contract Staking {
    IERC20Metadata public stakingToken;
    address public admin;
    uint256 public totalStaked;
    mapping(address => uint256) public stakedBalances;
    mapping(address => uint256) public stakingTime;

    event Staked(address indexed user, uint256 amount, uint256 timestamp);
    event Unstaked(address indexed user, uint256 amount, uint256 timestamp);

    modifier onlyAdmin() {
        require(msg.sender == admin, "Staking: Caller is not the admin");
        _;
    }

    constructor(address _stakingToken) {
        stakingToken = IERC20Metadata(_stakingToken);
        admin = msg.sender;
    }

    function stake(uint256 _amount) external {
        require(_amount > 0, "Staking: Cannot stake 0");
        stakedBalances[msg.sender] += _amount;
        totalStaked += _amount;
        stakingTime[msg.sender] = block.timestamp;
        require(stakingToken.transferFrom(msg.sender, address(this), _amount), "Staking: Transfer failed");
        emit Staked(msg.sender, _amount, block.timestamp);
    }

    function unstake(uint256 _amount) external {
        require(_amount > 0, "Staking: Cannot unstake 0");
        require(stakedBalances[msg.sender] >= _amount, "Staking: Insufficient balance to unstake");
        stakedBalances[msg.sender] -= _amount;
        totalStaked -= _amount;
        require(stakingToken.transfer(msg.sender, _amount), "Staking: Transfer failed");
        emit Unstaked(msg.sender, _amount, block.timestamp);
    }

    function changeAdmin(address _newAdmin) external onlyAdmin {
        admin = _newAdmin;
    }

    function getStakedBalance(address _user) external view returns (uint256) {
        return stakedBalances[_user];
    }

    function getTotalStaked() external view returns (uint256) {
        return totalStaked;
    }
}