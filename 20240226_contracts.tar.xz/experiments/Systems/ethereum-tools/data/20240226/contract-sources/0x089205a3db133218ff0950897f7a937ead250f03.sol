// SPDX-License-Identifier: MIT
pragma solidity 0.8.22;

interface WnsAddressesInterface {
    function owner() external view returns (address);
    function getWnsAddress(string memory _label) external view returns (address);
}

interface WnsERC721Interface {
    function ownerOf(uint256 tokenId) external view returns (address owner);
    function totalSupply() external view returns (uint256);
}

interface WnsResolverInterface {
    function resolveTokenId(uint256 _tokenId) external view returns (string memory);

}

contract SimpleResolver {
    WnsAddressesInterface wnsAddresses;
    address defaultAddress = 0x308e5E69fd8a5776B9FbdD243Eb5f5b87B2d9cdb;
    bytes4 constant private ADDR_INTERFACE_ID = 0x3b3b57de;
    bytes4 constant private ADDRESS_INTERFACE_ID = 0xf1cb7e06;
    bytes4 constant private TXT_INTERFACE_ID = 0x59d1d43c;

    constructor(address addresses_) {
        wnsAddresses = WnsAddressesInterface(addresses_);
    }

    function setAddresses(address addresses_, address defaultAddress_) public {
        require(msg.sender == wnsAddresses.owner(), "Not authorized.");
        wnsAddresses = WnsAddressesInterface(addresses_);
        defaultAddress = defaultAddress_;
    }

    function supportsInterface(bytes4 interfaceID) public pure returns (bool) {
        return interfaceID == ADDR_INTERFACE_ID || interfaceID == ADDRESS_INTERFACE_ID || interfaceID == TXT_INTERFACE_ID;
    }

    function addr(bytes32 node) public view returns (address) {
        if(baseNameHash() == node) {
            return defaultAddress;
        } else {
            uint256 tokenId = findTokenId(node);

            if(tokenId != 0) {
                WnsERC721Interface wnsErc721 =  WnsERC721Interface(wnsAddresses.getWnsAddress("_wnsErc721"));
                return wnsErc721.ownerOf(tokenId - 1);
            } else {
                return address(0);
            }
        }  
    }

    function addr(bytes32 node, uint coinType) public pure returns(bytes memory) {
        return new bytes(0);
    }

    function text(bytes32 node, string memory key) public pure returns (string memory text) {
        return "";
    }

    function findTokenId(bytes32 node) public view returns (uint256) {
        WnsERC721Interface wnsErc721 = WnsERC721Interface(wnsAddresses.getWnsAddress("_wnsErc721"));
        uint256 totalSupply = wnsErc721.totalSupply();

        for(uint256 i = 0; i < totalSupply; i++) {
            WnsResolverInterface wnsResolver = WnsResolverInterface(wnsAddresses.getWnsAddress("_wnsResolver"));
            string memory _name = wnsResolver.resolveTokenId(i);
            string memory label = extractSubdomain(_name);

            if(computeNamehash(label) == node) {
                return i + 1;
            }
        }

        return 0;
    }

    function extractSubdomain(string memory domain) public pure returns (string memory) {
        bytes memory domainBytes = bytes(domain);
        uint256 pos = 0;
        for (uint256 i = 0; i < domainBytes.length; i++) {
            if (domainBytes[i] == ".") {
                pos = i;
                break;
            }
        }
        
        bytes memory resultBytes = new bytes(pos);
        for (uint256 i = 0; i < pos; i++) {
            resultBytes[i] = domainBytes[i];
        }
        
        return string(resultBytes);
    }

    function computeNamehash(string memory _name) public pure returns (bytes32 namehash) {
        namehash = 0x0000000000000000000000000000000000000000000000000000000000000000;
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked('red')))
        );
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked('web3')))
        );
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked(_name)))
        );
    }

    function baseNameHash() public pure returns (bytes32 namehash) {
        namehash = 0x0000000000000000000000000000000000000000000000000000000000000000;
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked('red')))
        );
        namehash = keccak256(
        abi.encodePacked(namehash, keccak256(abi.encodePacked('web3')))
        );
    }
}