// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract PaymentGateway3 {
    // Define the owner of the contract
    address public owner;

    // Constructor to set the owner of the contract during deployment
    constructor() {
        owner = msg.sender;
    }

    // Modifier to restrict functions to only the owner of the contract
    modifier onlyOwner() {
        require(msg.sender == owner, "Only the owner can call this function.");
        _;
    }

    // Event to emit when payment is received
    event PaymentReceived(address indexed sender, uint amount, uint timestamp);

    // Function to receive payments. It's 'payable' to allow it to accept ETH.
    receive() external payable {
        require(msg.value > 0, "Payment must be greater than 0 ETH");
        // Emit a PaymentReceived event.
        emit PaymentReceived(msg.sender, msg.value, block.timestamp);
    }

    // Optional: Withdraw function to allow the owner to withdraw funds from the contract
    function withdraw(uint amount) external onlyOwner {
        require(amount <= address(this).balance, "Insufficient funds");
        payable(owner).transfer(amount);
    }

    // Optional: Function to check contract's balance
    function getBalance() external view onlyOwner returns (uint) {
        return address(this).balance;
    }
}