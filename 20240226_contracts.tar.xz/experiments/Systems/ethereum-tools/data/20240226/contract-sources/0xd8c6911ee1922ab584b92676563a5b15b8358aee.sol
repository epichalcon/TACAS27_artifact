// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

library Address {
    /**
     * @dev Returns true if `account` is a contract.
     *
     * [IMPORTANT]
     * ====
     * It is unsafe to assume that an address for which this function returns
     * false is an externally-owned account (EOA) and not a contract.
     *
     * Among others, `isContract` will return false for the following
     * types of addresses:
     *
     *  - an externally-owned account
     *  - a contract in construction
     *  - an address where a contract will be created
     *  - an address where a contract lived, but was destroyed
     * ====
     */
    function isContract(address account) internal view returns (bool) {
        // This mETHod relies on extcodesize, which returns 0 for contracts in
        // construction, since the code is only stored at the end of the
        // constructor execution.

        uint256 size;
        // solhint-disable-next-line no-inline-assembly
        assembly { size := extcodesize(account) }
        return size > 0;
    }

    /**
     * @dev Replacement for Solidity's `transfer`: sends `amount` wei to
     * `recipient`, forwarding all available gas and reverting on errors.
     *
     * https://eips.ETHereum.org/EIPS/eip-1884[EIP1884] increases the gas cost
     * of certain opcodes, possibly making contracts go over the 2300 gas limit
     * imposed by `transfer`, making them unable to receive funds via
     * `transfer`. {sendValue} removes this limitation.
     *
     * https://diligence.consensys.net/posts/2019/09/stop-using-soliditys-transfer-now/[Learn more].
     *
     * IMPORTANT: because control is transferred to `recipient`, care must be
     * taken to not create reentrancy vulnerabilities. Consider using
     * {ReentrancyGuard} or the
     * https://solidity.readthedocs.io/en/v0.5.11/security-considerations.html#use-the-checks-effects-interactions-pattern[checks-effects-interactions pattern].
     */
    function sendValue(address payable recipient, uint256 amount) internal {
        require(address(this).balance >= amount, "Address: insufficient balance");

        // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
        (bool success, ) = recipient.call{ value: amount }("");
        require(success, "Address: unable to send value, recipient may have reverted");
    }

    /**
     * @dev Performs a Solidity function call using a low level `call`. A
     * plain`call` is an unsafe replacement for a function call: use this
     * function instead.
     *
     * If `target` reverts with a revert reason, it is bubbled up by this
     * function (like regular Solidity function calls).
     *
     * Returns the raw returned data. To convert to the expected return value,
     * use https://solidity.readthedocs.io/en/latest/units-and-global-variables.html?highlight=abi.decode#abi-encoding-and-decoding-functions[`abi.decode`].
     *
     * Requirements:
     *
     * - `target` must be a contract.
     * - calling `target` with `data` must not revert.
     *
     * _Available since v3.1._
     */
    function functionCall(address target, bytes memory data) internal returns (bytes memory) {
      return functionCall(target, data, "Address: low-level call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with
     * `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCall(address target, bytes memory data, string memory errorMessage) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but also transferring `value` wei to `target`.
     *
     * Requirements:
     *
     * - the calling contract must have an ETH balance of at least `value`.
     * - the called Solidity function must be `payable`.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(address target, bytes memory data, uint256 value) internal returns (bytes memory) {
        return functionCallWithValue(target, data, value, "Address: low-level call with value failed");
    }

    /**
     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but
     * with `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(address target, bytes memory data, uint256 value, string memory errorMessage) internal returns (bytes memory) {
        require(address(this).balance >= value, "Address: insufficient balance for call");
        require(isContract(target), "Address: call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = target.call{ value: value }(data);
        return _verifyCallResult(success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(address target, bytes memory data) internal view returns (bytes memory) {
        return functionStaticCall(target, data, "Address: low-level static call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(address target, bytes memory data, string memory errorMessage) internal view returns (bytes memory) {
        require(isContract(target), "Address: static call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = target.staticcall(data);
        return _verifyCallResult(success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a delegate call.
     *
     * _Available since v3.4._
     */
    function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionDelegateCall(target, data, "Address: low-level delegate call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a delegate call.
     *
     * _Available since v3.4._
     */
    function functionDelegateCall(address target, bytes memory data, string memory errorMessage) internal returns (bytes memory) {
        require(isContract(target), "Address: delegate call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = target.delegatecall(data);
        return _verifyCallResult(success, returndata, errorMessage);
    }

    function _verifyCallResult(bool success, bytes memory returndata, string memory errorMessage) private pure returns(bytes memory) {
        if (success) {
            return returndata;
        } else {
            // Look for revert reason and bubble it up if present
            if (returndata.length > 0) {
                // The easiest way to bubble the revert reason is using memory via assembly

                // solhint-disable-next-line no-inline-assembly
                assembly {
                    let returndata_size := mload(returndata)
                    revert(add(32, returndata), returndata_size)
                }
            } else {
                revert(errorMessage);
            }
        }
    }
}

library SafeERC20 {
    using SafeMath for uint256;
    using Address for address;

    function safeTransfer(IERC20 token, address to, uint256 value) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));
    }

    function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
    }

    /**
     * @dev Deprecated. This function has issues similar to the ones found in
     * {IERC20-approve}, and its usage is discouraged.
     *
     * Whenever possible, use {safeIncreaseAllowance} and
     * {safeDecreaseAllowance} instead.
     */
    function safeApprove(IERC20 token, address spender, uint256 value) internal {
        // safeApprove should only be called when setting an initial allowance,
        // or when resetting it to zero. To increase and decrease it, use
        // 'safeIncreaseAllowance' and 'safeDecreaseAllowance'
        // solhint-disable-next-line max-line-length
        require((value == 0) || (token.allowance(address(this), spender) == 0),
            "SafeERC20: approve from non-zero to non-zero allowance"
        );
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, value));
    }

    function safeIncreaseAllowance(IERC20 token, address spender, uint256 value) internal {
        uint256 newAllowance = token.allowance(address(this), spender).add(value);
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));
    }

    function safeDecreaseAllowance(IERC20 token, address spender, uint256 value) internal {
        uint256 newAllowance = token.allowance(address(this), spender).sub(value, "SafeERC20: decreased allowance below zero");
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));
    }

    /**
     * @dev Imitates a Solidity high-level call (i.e. a regular function call to a contract), relaxing the requirement
     * on the return value: the return value is optional (but if data is returned, it must not be false).
     * @param token The token targeted by the call.
     * @param data The call data (encoded using abi.encode or one of its variants).
     */
    function _callOptionalReturn(IERC20 token, bytes memory data) private {
        // We need to perform a low level call here, to bypass Solidity's return data size checking mechanism, since
        // we're implementing it ourselves. We use {Address.functionCall} to perform this call, which verifies that
        // the target address contains contract code and also asserts for success in the low-level call.

        bytes memory returndata = address(token).functionCall(data, "SafeERC20: low-level call failed");
        if (returndata.length > 0) { // Return data is optional
            // solhint-disable-next-line max-line-length
            require(abi.decode(returndata, (bool)), "SafeERC20: ERC20 operation did not succeed");
        }
    }
}
contract Context {

    function _msgSender() internal view virtual returns (address payable) {
        return payable(msg.sender);
    }
    function _msgData() internal view virtual returns (bytes memory) {
        this; // silence state mutability warning without generating bytecode - see https://github.com/ETHereum/solidity/issues/2691
        return msg.data;
    }
}


interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}


library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256) 
    
    {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");

        return c;
    }
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return sub(a, b, "SafeMath: subtraction overflow");
    }
    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        uint256 c = a - b;

        return c;
    }
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        if (a == 0) {
            return 0;
        }

        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");

        return c;
    }

    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return div(a, b, "SafeMath: division by zero");
    }

    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        // Solidity only automatically asserts when dividing by 0
        require(b > 0, errorMessage);
        uint256 c = a / b;
        // assert(a == b * c + a % b); // There is no case in which this doesn't hold

        return c;
    }

    function mod(uint256 a, uint256 b) internal pure returns (uint256) {
        return mod(a, b, "SafeMath: modulo by zero");
    }
    function mod(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b != 0, errorMessage);
        return a % b;
    }
}


abstract contract Pausable is Context {	
    /**	
     * @dev Emitted when the pause is triggered by `account`.	
     */	
    event Paused(address account);	
    /**	
     * @dev Emitted when the pause is lifted by `account`.	
     */	
    event Unpaused(address account);	
    bool private _paused;	
    /**	
     * @dev Initializes the contract in unpaused state.	
     */	
    constructor() {	
        _paused = false;	
    }	
    /**	
     * @dev Returns true if the contract is paused, and false otherwise.	
     */	
    function paused() public view virtual returns (bool) {	
        return _paused;	
    }	
    /**	
     * @dev Modifier to make a function callable only when the contract is not paused.	
     *	
     * Requirements:	
     *	
     * - The contract must not be paused.	
     */	
    modifier whenNotPaused() {	
        require(!paused(), "Pausable: paused");	
        _;	
    }	
    /**	
     * @dev Modifier to make a function callable only when the contract is paused.	
     *	
     * Requirements:	
     *	
     * - The contract must be paused.	
     */	
    modifier whenPaused() {	
        require(paused(), "Pausable: not paused");	
        _;	
    }	
    /**	
     * @dev Triggers stopped state.	
     *	
     * Requirements:	
     *	
     * - The contract must not be paused.	
     */	
    function _pause() internal virtual whenNotPaused {	
        _paused = true;	
        emit Paused(_msgSender());	
    }	
    /**	
     * @dev Returns to normal state.	
     *	
     * Requirements:	
     *	
     * - The contract must be paused.	
     */	
    function _unpause() internal virtual whenPaused {	
        _paused = false;	
        emit Unpaused(_msgSender());	
    }	
}

contract Ownable is Context {
    address private _owner;
   

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor ()  {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }
    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }
    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

abstract contract ReentrancyGuard {
    // Booleans are more expensive than uint256 or any type that takes up a full
    // word because each write operation emits an extra SLOAD to first read the
    // slot's contents, replace the bits taken up by the boolean, and then write
    // back. This is the compiler's defense against contract upgrades and
    // pointer aliasing, and it cannot be disabled.

    // The values being non-zero value makes deployment a bit more expensive,
    // but in exchange the refund on every call to nonReentrant will be lower in
    // amount. Since refunds are capped to a percentage of the total
    // transaction's gas, it is best to keep them low in cases like this one, to
    // increase the likelihood of the full refund coming into effect.
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;

    uint256 private _status;

    constructor() {
        _status = _NOT_ENTERED;
    }

    /**
     * @dev Prevents a contract from calling itself, directly or indirectly.
     * Calling a `nonReentrant` function from another `nonReentrant`
     * function is not supported. It is possible to prevent this from happening
     * by making the `nonReentrant` function external, and making it call a
     * `private` function that does the actual work.
     */
    modifier nonReentrant() {
        _nonReentrantBefore();
        _;
        _nonReentrantAfter();
    }

    function _nonReentrantBefore() private {
        // On the first call to nonReentrant, _notEntered will be true
        require(_status != _ENTERED, "ReentrancyGuard: reentrant call");

        // Any calls to nonReentrant after this point will fail
        _status = _ENTERED;
    }

    function _nonReentrantAfter() private {
        // By storing the original value once again, a refund is triggered (see
        // https://eips.ethereum.org/EIPS/eip-2200)
        _status = _NOT_ENTERED;
    }
}

contract MarvelStaking is Ownable,Pausable,ReentrancyGuard{
    using SafeMath for uint256;
    using SafeERC20 for IERC20;

    IERC20 public Token;
    mapping(address => bool) public isSpam;
    uint256 public time = 1 days;
    uint256 public totalStakers;
    uint256 public totalStaked;
    uint256 public totallocked;
    uint256 public APY;
    uint256 public maxStaked;
    bool public canClaim=false;
    bool public canStakePublic=false;


    uint256 public lockableDays=14 days;
      address public presaleContract; //presale contract address
    

    mapping(address=>bool) public newstakers;
      modifier onlyPresale() {
    require(msg.sender == presaleContract, "This method is only for presale Contract");
    _;
  }




    struct userInfo {
        uint256 DepositeToken;
        uint256 WithdrawAbleReward;
        uint256 depositeTime;
        uint256 WithdrawDepositeAmount;
        uint256 WithdrawReward;
    }
    
     event Deposite_(address indexed to,address indexed From, uint256 amount, uint256 day,uint256 time);

    
    mapping(address => uint256[] ) public depositeToken;
    mapping(address => uint256[] ) public lockabledays;
    mapping(address => uint256[] ) public depositetime;  
    mapping(address => uint256 ) public unlocktime;  


    mapping(address => uint256[] ) public lastclaimedtime;
    mapping(address =>  userInfo) public Users;



    constructor(IERC20 _token,address _presale)  {
        Token = _token;
       
        APY=7927448000; // 25 % APY // 0.000000007927448 per sec
         presaleContract = _presale;
    }

    function farm(uint256 _amount, uint256 _lockableDays) external whenNotPaused nonReentrant	
    {
    
        require(isSpam[msg.sender]==false,"Account is spam!");
        require(canStakePublic==true,"Public stake not opened!");
        require(_amount > 0, "Invalid amount");
        require(_lockableDays==lockableDays, "Invalid day selection");
        IERC20(Token).safeTransferFrom(msg.sender, address(this), _amount);
        if(Users[msg.sender].DepositeToken ==0){
            unlocktime[msg.sender]+=block.timestamp +lockableDays;
        }
        else{
           unlocktime[msg.sender]+=lockableDays; 
        }
        depositeToken[msg.sender].push(_amount);
        depositetime[msg.sender].push(uint40(block.timestamp));
        lastclaimedtime[msg.sender].push(uint40(block.timestamp));
        Users[msg.sender].DepositeToken += _amount;
        Users[msg.sender].depositeTime=block.timestamp;
        lockabledays[msg.sender].push(_lockableDays);
      
        if(newstakers[msg.sender]==false)
        {
        totalStakers+=1;
        }
        newstakers[msg.sender]=true;
        totalStaked+=_amount;
        totallocked+=_amount;
        emit Deposite_(msg.sender,address(this),_amount,_lockableDays,block.timestamp);
    }

      function depositByPresale(address _user, uint256 _amount) external whenNotPaused onlyPresale {

        require(isSpam[_user]==false,"Account is spam!");
        require(_amount > 0, "Invalid amount");
        IERC20(Token).safeTransferFrom(presaleContract, address(this), _amount);
          if(Users[_user].DepositeToken ==0){
            unlocktime[_user]+=block.timestamp +lockableDays;
        }
        else{
           unlocktime[_user]+=lockableDays; 
        }
        depositeToken[_user].push(_amount);
        depositetime[_user].push(uint40(block.timestamp));
        lastclaimedtime[_user].push(uint40(block.timestamp));
        Users[_user].DepositeToken += _amount;
        Users[_user].depositeTime=block.timestamp;
        lockabledays[_user].push(lockableDays);
      
        if(newstakers[_user]==false)
        {
        totalStakers+=1;
        }
        newstakers[_user]=true;
        totalStaked+=_amount;
        totallocked+=_amount;
        emit Deposite_(_user,address(this),_amount,lockableDays,block.timestamp);


      }



    function pendindRewards(address _add) public view returns(uint256 reward)
    {
        uint256 Reward;
        uint256 sec;
        uint256 tokenperct;
        
        for(uint256 z=0 ; z< depositeToken[_add].length;z++){
           sec =(block.timestamp-lastclaimedtime[_add][z]);
           tokenperct=depositeToken[_add][z]*APY;
            Reward += (sec*tokenperct).div(1e18);
        }
    
    return Reward;
    }

    function claim() public {
        require(canClaim==true,"Claim is not open yet!");
        uint256 withdrawable=pendindRewards(msg.sender);
        for(uint256 z=0 ; z< depositeToken[msg.sender].length;z++){
        lastclaimedtime[msg.sender][z]=block.timestamp;
        }
        IERC20(Token).safeTransfer(msg.sender,  withdrawable);

    }

    function checkTime(address _addr) public view returns (uint256[] memory array){
            for(uint256 z=0 ; z< depositeToken[_addr].length;z++){
              
        require( Users[_addr].DepositeToken > 0, " Deposite not ");
        uint256 lockTime =depositetime[_addr][depositeToken[_addr][z]]+(lockabledays[_addr][depositeToken[_addr][z]].mul(time));
        if(block.timestamp > lockTime){
         array[z]=z;

        }
    }
    }


    function harvest(uint256 [] memory _index) public  {

        uint256 Reward;
        uint256 sec;
        uint256 tokenperct;
          for(uint256 z=0 ; z< _index.length;z++){
              
        require( Users[msg.sender].DepositeToken > 0, " Deposite not ");
        require(block.timestamp > unlocktime[msg.sender],"Invalid Unlock Time");
        sec =(block.timestamp-lastclaimedtime[msg.sender][_index[z]]);
        tokenperct=depositeToken[msg.sender][_index[z]]*APY;
        Reward += (sec*tokenperct).div(1e18);
        Users[msg.sender].WithdrawAbleReward += Reward;
        Users[msg.sender].DepositeToken -= depositeToken[msg.sender][_index[z]];
        Users[msg.sender].WithdrawDepositeAmount += depositeToken[msg.sender][_index[z]];
        depositeToken[msg.sender][_index[z]] = 0;
        lockabledays[msg.sender][_index[z]] = 0;
        depositetime[msg.sender][_index[z]] = 0;
        lastclaimedtime[msg.sender][_index[z]] = 0;
        }

            for(uint256 t=0 ; t< _index.length;t++){
            for(uint256 i = _index[t]; i <  depositeToken[msg.sender].length - 1; i++) 
        {
            depositeToken[msg.sender][i] = depositeToken[msg.sender][i + 1];
            lockabledays[msg.sender][i] = lockabledays[msg.sender][i + 1];
            depositetime[msg.sender][i] = depositetime[msg.sender][i + 1];
            lastclaimedtime[msg.sender][i] = lastclaimedtime[msg.sender][i + 1];

        }
          depositeToken[msg.sender].pop();
          lockabledays[msg.sender].pop();
          depositetime[msg.sender].pop();
          lastclaimedtime[msg.sender].pop();
    }

    uint256 totalReward=Users[msg.sender].WithdrawDepositeAmount+Users[msg.sender].WithdrawAbleReward;
             
             IERC20(Token).safeTransfer(msg.sender, totalReward);
             totallocked-=Users[msg.sender].WithdrawDepositeAmount;
             Users[msg.sender].WithdrawReward =Users[msg.sender].WithdrawReward.add(Users[msg.sender].WithdrawAbleReward );
             Users[msg.sender].WithdrawAbleReward =0;
             Users[msg.sender].WithdrawDepositeAmount = 0;
         
    }

    function emergencyWithdrawSafeERC20(address _tokenaddress,uint256 _token) external onlyOwner {
         
         IERC20(_tokenaddress).safeTransfer(msg.sender,_token);
    }
   
    
    function userInformation(address _add) public view returns(uint256 [] memory , uint256 [] memory,uint256 [] memory){
        return(depositeToken[_add],lockabledays[_add],depositetime[_add]);
    }
 
   function emergencyWithdrawtokens(IERC20 _token,uint256 _amount) external onlyOwner {
         _token.transfer(msg.sender, _amount);
    }

    function emergencyWithdrawETH(uint256 Amount) external onlyOwner {
        payable(msg.sender).transfer(Amount);
    }
        function changetimeCal(uint256 _time) external onlyOwner{
        time=_time;
    }

    function changePercentages(uint256 _APY) external onlyOwner{
     APY = _APY;
    }

       function changemaxStaked(uint256 _maxStaked) external onlyOwner{
     maxStaked = _maxStaked;
    }



    function pausePool() external onlyOwner{	
        _pause();	
    }	
    function UnpausePool() external onlyOwner{	
        _unpause();	
    }

    function changeToken(IERC20 addr) public onlyOwner{
        Token=addr;
        
    }

      function addorRemoveSpam(address _Addr,bool _state) external onlyOwner{
        isSpam[_Addr]=_state;
    }
      function setPresale(address _presale) external onlyOwner {
    presaleContract = _presale;
  }
  function setlockableDays(uint256 _lockableDays) external onlyOwner{
    lockableDays=_lockableDays;
  }

    function setcanClaim(bool _state) external onlyOwner{
    canClaim=_state;
  }

    function setcanStakePublic(bool _state) external onlyOwner{
    canStakePublic=_state;
  }
    
	
    receive() external payable{	
//  receive the ETH	
} 	
    
}