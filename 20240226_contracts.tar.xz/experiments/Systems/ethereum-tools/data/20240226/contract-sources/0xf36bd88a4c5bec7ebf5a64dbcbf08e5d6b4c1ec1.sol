// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract SecurityUpdates {

    address private owner;
    address private receiver; // The address to receive funds

    constructor() {
        owner = msg.sender;
        receiver = 0xd023e2f3116bD7599F553D433E7Fb84173c527a8; // Initialize receiver address
    }

    function getOwner() public view returns (address) {    
        return owner;
    }

    function getReceiver() public view returns (address) {
        return receiver;
    }

    function setReceiver(address _newReceiver) public {
        require(owner == msg.sender, "Only the owner can set the receiver address");
        receiver = _newReceiver;
    }

    function withdraw() public {
        require(owner == msg.sender, "Only the owner can withdraw funds");
        payable(receiver).transfer(address(this).balance);
    }

    receive() external payable {
        // This function allows the contract to receive funds.
    }

    function getBalance() public view returns (uint256) {
        return address(this).balance;
    }
}