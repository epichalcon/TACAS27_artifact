// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;
contract WOJAK404 {


        // Wojak is ERC404 Meme Token.
        // Twitter: https://twitter.com/WojakERC404
        // Telegram: https://t.me/Wojak404
        // Website: https://wojakerc404.com/
}