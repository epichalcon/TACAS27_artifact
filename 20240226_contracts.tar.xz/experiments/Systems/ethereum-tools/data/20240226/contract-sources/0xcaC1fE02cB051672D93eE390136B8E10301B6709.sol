{
  "language": "Solidity",
  "settings": {
    "evmVersion": "london",
    "libraries": {},
    "metadata": {
      "bytecodeHash": "ipfs",
      "useLiteralContent": true
    },
    "optimizer": {
      "enabled": true,
      "runs": 200
    },
    "remappings": [],
    "outputSelection": {
      "*": {
        "*": [
          "evm.bytecode",
          "evm.deployedBytecode",
          "devdoc",
          "userdoc",
          "metadata",
          "abi"
        ]
      }
    }
  },
  "sources": {
    "@openzeppelin/contracts-sol08/access/Ownable.sol": {
      "content": "// SPDX-License-Identifier: MIT\n// OpenZeppelin Contracts (last updated v4.7.0) (access/Ownable.sol)\n\npragma solidity ^0.8.0;\n\nimport \"../utils/Context.sol\";\n\n/**\n * @dev Contract module which provides a basic access control mechanism, where\n * there is an account (an owner) that can be granted exclusive access to\n * specific functions.\n *\n * By default, the owner account will be the one that deploys the contract. This\n * can later be changed with {transferOwnership}.\n *\n * This module is used through inheritance. It will make available the modifier\n * `onlyOwner`, which can be applied to your functions to restrict their use to\n * the owner.\n */\nabstract contract Ownable is Context {\n    address private _owner;\n\n    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);\n\n    /**\n     * @dev Initializes the contract setting the deployer as the initial owner.\n     */\n    constructor() {\n        _transferOwnership(_msgSender());\n    }\n\n    /**\n     * @dev Throws if called by any account other than the owner.\n     */\n    modifier onlyOwner() {\n        _checkOwner();\n        _;\n    }\n\n    /**\n     * @dev Returns the address of the current owner.\n     */\n    function owner() public view virtual returns (address) {\n        return _owner;\n    }\n\n    /**\n     * @dev Throws if the sender is not the owner.\n     */\n    function _checkOwner() internal view virtual {\n        require(owner() == _msgSender(), \"Ownable: caller is not the owner\");\n    }\n\n    /**\n     * @dev Leaves the contract without owner. It will not be possible to call\n     * `onlyOwner` functions anymore. Can only be called by the current owner.\n     *\n     * NOTE: Renouncing ownership will leave the contract without an owner,\n     * thereby removing any functionality that is only available to the owner.\n     */\n    function renounceOwnership() public virtual onlyOwner {\n        _transferOwnership(address(0));\n    }\n\n    /**\n     * @dev Transfers ownership of the contract to a new account (`newOwner`).\n     * Can only be called by the current owner.\n     */\n    function transferOwnership(address newOwner) public virtual onlyOwner {\n        require(newOwner != address(0), \"Ownable: new owner is the zero address\");\n        _transferOwnership(newOwner);\n    }\n\n    /**\n     * @dev Transfers ownership of the contract to a new account (`newOwner`).\n     * Internal function without access restriction.\n     */\n    function _transferOwnership(address newOwner) internal virtual {\n        address oldOwner = _owner;\n        _owner = newOwner;\n        emit OwnershipTransferred(oldOwner, newOwner);\n    }\n}\n"
    },
    "@openzeppelin/contracts-sol08/utils/Context.sol": {
      "content": "// SPDX-License-Identifier: MIT\n// OpenZeppelin Contracts v4.4.1 (utils/Context.sol)\n\npragma solidity ^0.8.0;\n\n/**\n * @dev Provides information about the current execution context, including the\n * sender of the transaction and its data. While these are generally available\n * via msg.sender and msg.data, they should not be accessed in such a direct\n * manner, since when dealing with meta-transactions the account sending and\n * paying for execution may not be the actual sender (as far as an application\n * is concerned).\n *\n * This contract is only required for intermediate, library-like contracts.\n */\nabstract contract Context {\n    function _msgSender() internal view virtual returns (address) {\n        return msg.sender;\n    }\n\n    function _msgData() internal view virtual returns (bytes calldata) {\n        return msg.data;\n    }\n}\n"
    },
    "@rarible/upgrade-executor/src/actions/SetProtocolFeeAction.sol": {
      "content": "// SPDX-License-Identifier: Apache-2.0\npragma solidity ^0.8.13;\n\nimport \"./interfaces/ExchangeProtocolFee.sol\";\n\ncontract SetProtocolFeeAction {\n    ExchangeProtocolFee public immutable exchangeV2;\n\n    constructor(ExchangeProtocolFee _exchangeV2) {\n        exchangeV2 = _exchangeV2;\n    }\n\n    function perform(address _receiver, uint48 _buyerAmount, uint48 _sellerAmount) external {\n        exchangeV2.setAllProtocolFeeData(_receiver, _buyerAmount, _sellerAmount);\n    }\n}\n"
    },
    "@rarible/upgrade-executor/src/actions/interfaces/ExchangeProtocolFee.sol": {
      "content": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.13;\n\nimport \"@openzeppelin/contracts-sol08/access/Ownable.sol\";\n\ncontract ExchangeProtocolFee is Ownable {\n    ProtocolFeeData public protocolFee;\n\n    /// @dev event that's emitted when ProtocolFeeData buyerAmount changes\n    event BuyerFeeAmountChanged(uint oldValue, uint newValue);\n\n    /// @dev event that's emitted when ProtocolFeeData sellerAmount changes\n    event SellerFeeAmountChanged(uint oldValue, uint newValue);\n\n    /// @dev event that's emitted when ProtocolFeeData receiver changes\n    event FeeReceiverChanged(address oldValue, address newValue);\n\n    /// @dev struct to store protocol fee - receiver address, buyer fee amount (in bp), seller fee amount (in bp)\n    struct ProtocolFeeData {\n        address receiver;\n        uint48 buyerAmount;\n        uint48 sellerAmount;\n    }\n\n    function setPrtocolFeeReceiver(address _receiver) public onlyOwner {\n        emit FeeReceiverChanged(protocolFee.receiver, _receiver);\n        protocolFee.receiver = _receiver;\n    }\n\n    function setPrtocolFeeBuyerAmount(uint48 _buyerAmount) public onlyOwner {\n        emit BuyerFeeAmountChanged(protocolFee.buyerAmount, _buyerAmount);\n        protocolFee.buyerAmount = _buyerAmount;\n    }\n\n    function setPrtocolFeeSellerAmount(uint48 _sellerAmount) public onlyOwner {\n        emit SellerFeeAmountChanged(protocolFee.sellerAmount, _sellerAmount);\n        protocolFee.sellerAmount = _sellerAmount;\n    }\n\n    function setAllProtocolFeeData(address _receiver, uint48 _buyerAmount, uint48 _sellerAmount) public onlyOwner {\n        setPrtocolFeeReceiver(_receiver);\n        setPrtocolFeeBuyerAmount(_buyerAmount);\n        setPrtocolFeeSellerAmount(_sellerAmount);\n    }\n}\n"
    }
  }
}